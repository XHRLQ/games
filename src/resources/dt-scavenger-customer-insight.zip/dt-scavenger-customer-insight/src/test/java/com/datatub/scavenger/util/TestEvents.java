package com.datatub.scavenger.util;

import com.datatub.scavenger.tag.Tagger;
import com.yeezhao.commons.util.Pair;

import java.io.IOException;
import java.util.HashSet;

/**
 * Created by mou on 2017/3/30.
 */
public class TestEvents {
    public static void main(String[] args) {
        Tagger tagger = null;
        try {
            tagger = Tagger.get("event.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }

        Pair<HashSet<String>, HashSet<String>> res = tagger.tag("小程序啊烧豆腐鹅厂阿斯科利点击发货为领先");
        HashSet<String> tags = res.getFirst();
        for (String tag : tags) {
            System.out.println(tag);
        }


    }
}
