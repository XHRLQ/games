package com.datatub.scavenger.tencent;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: SMA
 * @Date: 2017-08-28 12:44
 * @Explain:
 */
public class TxtCreateUtils {
    private static final String PARENT = "D:\\job\\data\\tx\\qysy\\txt";

    public List<Row> readExcelData(String path, int sheetNumber, boolean isReturnHead) {
        // 判断文件是否合理
        File file = new File(path);
        if (!file.exists()
                || !file.isFile()
                || !(file.getName().endsWith(".xlsx") || file.getName().endsWith(".xls"))) {
            System.out.println("无法识别文件: " + path);
            return null;
        }
        List<Row> rows = null;
        try {
            // 创建work
            Workbook workbook = WorkbookFactory.create(file);
            // 获取工作表,默认取第一个
            Sheet sheet = workbook.getSheetAt(sheetNumber);
            // 获取工作表的总行数
            int number = sheet.getLastRowNum();
            // 遍历每一行
            int count = 0;
            if (!isReturnHead) {
                count = 1;
            }
            rows = new ArrayList<Row>(number);
            while (count <= number) {
                rows.add(sheet.getRow(count));
                count++;
            }
        } catch (Exception e) {
            System.out.println("读取Excel文件失败" + e);
        }
        return rows;
    }

    @Test
    public void envent() throws IOException {
        String path = PARENT + "/tmp/envent.xlsx";
        String out = PARENT + "/result/event.txt";
        List<Row> rows = readExcelData(path, 0, false);
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out)));
        StringBuilder sb = new StringBuilder();
        for (Row row : rows) {
            // 事件标签	关键词	事件分类
            String label = row.getCell(2).getStringCellValue();
            String kw = row.getCell(3).getStringCellValue();
            kw = kw.replaceAll("\n", "|");
            String split = row.getCell(4).getStringCellValue();
            // 事件分类^事件标签    关键词
            sb.append(split).append("^").append(label).append("\t").append(kw);
            if (!sb.toString().contains("^")) {
                System.out.println(sb);
            }
            writer.write(sb.toString());
            writer.newLine();
            sb.setLength(0);

        }
        writer.flush();
        writer.close();
    }


    @Test
    public void tag1() throws IOException {
        String path = PARENT + "/tmp/tag1.xlsx";
        String out = PARENT + "/result/tag1-tag2.txt";
        List<Row> rows = readExcelData(path, 0, false);
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out)));
        StringBuilder sb = new StringBuilder();
        for (Row row : rows) {
            // 事件标签	关键词	事件分类
            String kw = row.getCell(0).getStringCellValue();
            // 事件分类^事件标签    关键词
            sb.append("tag").append("\t").append(kw);
            writer.write(sb.toString());
            writer.newLine();
            sb.setLength(0);

        }
        writer.flush();
        writer.close();
    }

    @Test
    public void tag2() throws IOException {
        String path = PARENT + "/tmp/tag2.txt";
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
        String line = "";
        StringBuilder sb = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            sb.append("|").append(line);
        }
        System.out.println(sb);
        reader.close();
    }

    public void tag2_2(){

    }
}
