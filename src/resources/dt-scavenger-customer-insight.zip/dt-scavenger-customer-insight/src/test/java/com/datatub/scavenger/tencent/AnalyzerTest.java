package com.datatub.scavenger.tencent;

import com.google.gson.Gson;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by mou on 2017/6/4.
 */
public class AnalyzerTest {

    @Test
    public void testMkMatchTagTmp() throws Exception {
        List<String> ss = Arrays.asList(
                "腾讯，百度，vs，女上司,2016年越南电子商务报告产品很好：一半网购用户曾进行FB购物品不起态不动，只有霾法，没有说法！罗某笑&原路退回//@土豆姐姐冯小燕:这是严重的违规执法，请政府给我们菜农一个说法？//@红如意软籽石榴园:@土豆姐姐冯小燕遇到过这种情况吗？//@红如意软籽石榴园:@毕慧芳农业@挖挖郝评",
                "@黑手OLdbig@匡铭志@土豆v炖牛腩说不准呢[害羞][二哈]@Misaya若风lol",
                "//@土豆姐姐冯小燕:#跟土豆姐姐去逛集吧#//@耿学生:网红@土豆姐姐冯小燕代言陕西省优质农产品",
                "//@土豆姐姐冯小燕:#跟土姐姐去逛集吧#//@耿学生:网红@土豆姐姐冯小燕代言陕西省优质农产品",
                "@土豆啊烧豆腐 asdfh 阿斯顿开放后土豆",
                "//@Instagram文艺馆:转发微博腾讯",
                "//@instagram优选:[doge]",
                "发布了头条文章：《街坊时代》今天，感谢互联网来到我们身边，整个世界又变小了；准备好了吗？让我们重返“街坊时代”！@杜子建@新张利@食品界姜昆@土豆姐姐冯小燕请老师指正！http://t.cn/Rq0Fmc8"
//                "//@instagram优选:收",
//                "//@发现instagram:*",
//                "//@Instagram热门:+",
//                "//@发现instagram:-",
//                "//@YouTube翻唱精选:大家转起来哦~",
//                "@钟汉良@百度百科明星团@大眼睛黑皮肤@良辰美景xw",
//                "@腾讯视频VIP@扒圈老鬼@六颗糖丫抽我抽我！",
//                "@淡淡等等//@Instagram文艺馆:转发微博",
//                "//@徐XX历险记://@YouTube上的搬运工:[喵喵]",
//                "//@旧事甚歉:关注她@instagram图册有你喜欢的短句和头像",
//                "刚刚在Instagram上了照片",
//                "刚刚在Instagram上了视频",
//                "剛使用Instagram張貼了1段影片",
//                "【百度云盘】",
//                "『腾讯新闻』",
//                "剛使用Instagram張貼了1張相片",
//                "剛使用Instagram發佈了1張相片",
//                "viaInstagram",
//                "viaFacebook",
//                "????Instagram",
//                "CF 牌子怎么养",
//                "真是笑到肚痛啊 lol",
//                "土豆辣椒",
//                "@小马哥and睿",
//                "lol~asdfs",
//                "lol==",
//                "哇哈哈呀哇哈哈~我的脸上笑开了花~ http://t.cn/RUE6bIPlol",
//                "哇哈哈呀哇哈哈~我的脸上笑开了花~ http://t.cn/RUE6bIP",
//                "https://hk.tower.im/projects/9dd190814d3b420c89312325a0385cf83a/todos/faccef8d604c4528b23910c9267dc970/#a1a2582909ff42a3a0e4f9b7d16249e8"
        );

        for (String s : ss) {
            TencentEntity e = new TencentEntity();
            e.content = s;

            TencentEntity res = Analyzer.mkMatchTagTmp(e);;
            System.out.println(s);
            System.out.println(e.tag1);
            System.out.println(e.tag2);
            System.out.println(e.tag3);
            System.out.println(e.tag4);
            System.out.println("");
        }

    }

    @Test
    public void testTriple() throws Exception {
        double i1 = Analyzer.mkTriple("品不起态不动，只有霾法，没有说法！//@土豆姐姐冯小燕:这是严重的违规执法，请");
        double i2 = Analyzer.mkTriple("蒋敦豪爱死你了");

        System.out.println(i1);
        System.out.println(i2);
    }

    @Test
    public void testIsReal() throws Exception {
        assert Analyzer.isReal("1682021450");
        assert !Analyzer.isNullOrEmpty("1");
    }

    @Test
    public void testAnalysisTriple() throws Exception {
        String raw = "{\"tag4\": 0, \"commentnum\": 0, \"tag1\": 0, \"attentionnum\": 0, \"tag3\": 0, \"date\": \"20161108\", \"retweetnum\": 1, \"fansnum\": 0, \"uid\": \"\", \"city\": \"\", \"vtype\": \"\", \"tag2\": 0, \"writer\": \"CAMIA观察\", \"mid\": \"\", \"content\": \"女上司,2016年越南电子商务报告产品很好：一半网购用户曾进行FB购物\", \"platform\": \"微信\", \"fanslevel\": \"\", \"province\": \"\", \"praisenum\": 3, \"company\": \"fb\", \"snt\": \"1.0\", \"device\": \"\", \"name\": \"CAMIA\", \"url\": \"http://mp.weixin.qq.com/s?__biz=MzAxNDIyNjAyOQ==&mid=2650202160&idx=1&sn=3939fc5b14e96f2aca65051d0ca8c541&chksm=8394c732b4e34e241b58bb4bbf7dbce5568bbd5d4494fd44dc443bf4cf02ee5eb88d32bb750c\", \"gender\": \"\", \"readnum\": 246, \"favorite\": \"\", \"birthdate\": \"\", \"citylevel\": \"\", \"platformtype\": \"微信\"}";

        TencentEntity entity = new Gson().fromJson(raw, TencentEntity.class);
        entity = Analyzer.mkMatchTagTmp(entity);
        System.out.println(entity);
    }
}