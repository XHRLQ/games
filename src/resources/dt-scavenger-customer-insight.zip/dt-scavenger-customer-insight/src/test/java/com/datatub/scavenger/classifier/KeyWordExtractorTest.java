package com.datatub.scavenger.classifier;

import com.datatub.scavenger.util.KeyWordLoader;
import com.yeezhao.commons.util.Pair;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by mou on 2016/10/26.
 */
public class KeyWordExtractorTest {
    KeyWordExtractor extractor;

    @Before public void initialize() throws IOException {
        List<String> keys = KeyWordLoader.getFile("childKeyword.txt");
        List<String> filters = KeyWordLoader.getFile("filterWord.txt");
        extractor = new KeyWordExtractor(keys, filters);
    }

    @Test
    public void testMatch1() throws Exception {
        assert extractor.match("参加牛逼少年宫真好");
    }
    @Test
    public void testMatch2() throws Exception {
        assert !extractor.match("参加牛逼少年宫会议");
    }
    @Test
    public void testMatch3() throws Exception {
        assert !extractor.match("参加牛逼少年宫阿斯顿飞开会");
    }
    @Test
    public void testMatch4() throws Exception {
        assert extractor.match("让小胖学跳舞");
    }
    @Test
    public void testMatch5() throws Exception {
        assert !extractor.match("让小胖学跳舞。。现代舞代理");
    }
    @Test
    public void testMatch6() throws Exception {
        assert !extractor.match("让小胖学跳舞。。@一淘网");
    }
    @Test
    public void testMatch7() throws Exception {
        assert !extractor.match("男孩4年级初");
    }
    @Test
    public void testMatch8() throws Exception {
        assert extractor.match("男孩4年级初高");
    }
    @Test
    public void testMatch9() throws Exception {
        assert extractor.match("让我的男孩去上学怎么这么喃");
    }
    @Test
    public void testMatch10() throws Exception {
        assert !extractor.match("让我的男孩去上学怎么这么喃购买地址");
    }

}