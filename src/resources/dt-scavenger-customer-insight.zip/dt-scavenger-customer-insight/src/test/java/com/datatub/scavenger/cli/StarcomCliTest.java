package com.datatub.scavenger.cli;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by mou on 2017/6/16.
 */
public class StarcomCliTest {

    @Test
    public void testAnalysis() throws Exception {
        List<String> lines = FileUtils.readLines(new File("/Users/mou/Downloads/sample.csv"));
        for (String line : lines) {
            String res = StarcomCli.analysis(line);
            System.out.println(res);
        }

    }
}