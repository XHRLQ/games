package com.datatub.scavenger.util;

import com.datatub.scavenger.tag.Tagger;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * Created by mou on 2017/3/20.
 */
public class Runner {

    public static void main(String[] args) throws Exception {
        List<String> files = FileUtils.readLines(new File("/Users/mou/Downloads/tten.txt"));
        Tagger tagger = Tagger.get("pinpai.txt");

        PrintWriter pw = new PrintWriter("resout.txt");

//        for (String file : files) {
//            pw.println(StringUtils.join(tagger.tag(file), ","));
//        }


        HashMap<String, Integer> map = new HashMap<>();

        for (String file : files) {
            Set<String> res = tagger.tag(file).getFirst();
            if (res.size()>0) {
                for (String re : res) {
                    if (map.containsKey(re)) {
                        map.put(re, map.get(re)+1);
                    } else {
                        map.put(re, 1);
                    }
                }

            }
        }

        for (String s : map.keySet()) {
            pw.println(s+"\t"+map.get(s));
        }

        pw.flush();
        pw.close();
    }
}
