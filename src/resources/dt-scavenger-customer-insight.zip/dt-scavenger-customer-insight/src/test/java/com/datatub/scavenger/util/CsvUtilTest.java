package com.datatub.scavenger.util;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by mou on 2017/5/24.
 */
public class CsvUtilTest {

    @Test
    public void testParseLine() throws Exception {
        List<String> lines = FileUtils.readLines(new File("/Users/mou/Desktop/newsforum-mainPost_utf_8/test.csv"));

        for (String line : lines) {
            List<String> res = CsvUtil.parseLine(line, ',');


            System.out.println(res.size());
        }
    }
}