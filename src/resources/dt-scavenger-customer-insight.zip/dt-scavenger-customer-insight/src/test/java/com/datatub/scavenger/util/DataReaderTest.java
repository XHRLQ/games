package com.datatub.scavenger.util;

import org.junit.Test;
import scala.Tuple2;

import static org.junit.Assert.*;

/**
 * Created by mou on 2016/10/28.
 */
public class DataReaderTest {

    @Test
    public void testTupleStringParser() throws Exception {
        Tuple2<String, String> a = DataReader.tupleStringParser("asdfas,1234812349");
        System.out.println(a);
    }
}