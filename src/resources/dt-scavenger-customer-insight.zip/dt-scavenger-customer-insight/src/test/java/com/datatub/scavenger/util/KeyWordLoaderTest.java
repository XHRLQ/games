package com.datatub.scavenger.util;


import com.yeezhao.commons.util.Pair;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by mou on 2016/10/26.
 */
public class KeyWordLoaderTest {

    @Test
    public void testGetKeywordMap() throws Exception {
        List<String> res = KeyWordLoader.getFile("tmp.txt");
        Map<String,List<Pair<LinkedList<String>, Set<String>>>> keyWordMap = KeyWordLoader.getKeywordMap(res);
        System.out.println(keyWordMap.size());
    }

    @Test
    public void testGetFilterWords() throws Exception {
        List<String> res = KeyWordLoader.getFile("filterWord.txt");
        Set<String> aa = KeyWordLoader.getFilterWords(res);

        System.out.println(aa.size());
    }
}