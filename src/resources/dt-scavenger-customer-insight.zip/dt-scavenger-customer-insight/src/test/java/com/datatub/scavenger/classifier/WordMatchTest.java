package com.datatub.scavenger.classifier;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by mou on 2017/3/1.
 */
public class WordMatchTest {

    @Test
    public void testGetInstance() throws Exception {

    }

    @Test
    public void testGetMatchedWords() throws Exception {
        List<String> arras = Arrays.asList("洁面", "开心", "洁净");
        WordMatch wm = WordMatch.getInstance(arras);
        List<String> a = wm.getMatchedWords("asdlkfas阿斯顿发阿斯顿发哪里看开心阿斯顿开发哪受得了洁面阿斯顿发速度发掘撒度持续走 i洁净f");
        for (String s : a) {
            System.out.println(s);
        }

    }
}