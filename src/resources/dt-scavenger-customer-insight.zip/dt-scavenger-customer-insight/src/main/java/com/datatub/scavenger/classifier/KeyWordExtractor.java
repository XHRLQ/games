package com.datatub.scavenger.classifier;

import com.datatub.scavenger.util.KeyWordLoader;
import com.yeezhao.commons.util.Pair;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.DicAnalysis;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by mou on 2016/10/25.
 */
public class KeyWordExtractor {

    private static Map<String,List<Pair<LinkedList<String>, Set<String>>>> keywordsMap;
    private static Set<String> filterWords;

    public KeyWordExtractor(List<String> keyWords, List<String> filterWords) {
        this.keywordsMap = KeyWordLoader.getKeywordMap(keyWords);
        this.filterWords = KeyWordLoader.getFilterWords(filterWords);
    }

    /**
     * 检查是否满足，关键词表和过滤词表的规范
     *
     *
     * @param raw
     * @return true: yes; false: no
     */
    public boolean match(String raw) {
        List<Term> terms = DicAnalysis.parse(raw).getTerms();
        int size = terms.size();

        int current = 0;
        boolean isContainKeyword = false;

        for (int i=0; i<size; i++) {
            current = i;
            Term term = terms.get(i);
            String word = term.getName();

            // 如果包含关键词，直接返回false
            if (filterWords.contains(word)) {
                return false;
            }

            // 如果不在关键词列表里面，则跳过
            if (!keywordsMap.containsKey(word)) {
                continue;
            }

            boolean isComplexMath = complexMath(keywordsMap.get(word), terms, current+1);

            // 满足条件，跳过循环
            if (isComplexMath) {
                isContainKeyword = true;
                current++;
                break;
            } else {
                continue;
            }
        }

        if (isContainKeyword) {
            // 如果满足条件，需要检查第一个关键词后面的是否包含过滤词
            if (current < size) {
                for (int i=current; i<size; i++) {
                    String word = terms.get(i).getName();
                    if (filterWords.contains(word)) {
                        return false;
                    }
                }
            }

            // 不包含全局过滤词，则返回正确
            return true;
        } else {
            // 为满足关键词需求
            return false;
        }
    }


    /**
     * 递归来解决
     *
     * @param list
     * @param terms
     * @param start
     * @return
     */
    private boolean complexMath(List<Pair<LinkedList<String>, Set<String>>> list, List<Term> terms, int start) {
        if (start > terms.size()) {
            return false;
        }

        for (Pair<LinkedList<String>, Set<String>> linkedListSetPair : list) {
            LinkedList<String> subKeys = linkedListSetPair.getFirst();
            Set<String> subFilter = linkedListSetPair.getSecond();

            // 满足了首要关键词，而不包含后继关键词和过滤词
            if (subKeys.size()==0 && subFilter.size()==0) {
                return true;
            }

            boolean isSubFilterMatch = false;
            // 判断子句中是否包含这一个分支的过滤词
            for (int i=start; i<terms.size(); i++) {
                String word = terms.get(i).getName();
                if (subFilter.contains(word)) {
                    isSubFilterMatch = true;
                    break;
                }
            }

            // 如果包含这一分支的过滤词，则跳出这个分支
            if (isSubFilterMatch) {
                continue;
            }

            // 如果没有后继词，则返回true
            if (subKeys.size() == 0) {
                return true;
            }

            int successorSize = 0;
            String currentSuccessor = subKeys.get(0);
            for (int i=start; i<terms.size(); i++) {
                String word = terms.get(i).getName();

                if (word.equals(currentSuccessor)) {
                    // 当前后继词满足
                    successorSize++;

                    // 取下一个后继词，如果没有下一个后继词，如果没有下一个后继词，则判断完成，并且正确

                    // 无后继词
                    if (successorSize == subKeys.size()) {
                        return true;
                    } else { // 有后继词则继续
                        currentSuccessor = subKeys.get(successorSize);
                    }
                } else {
                    // 不满足下一个后继，继续判断
                    continue;
                }
            }
        }

        return false;
    }
}
