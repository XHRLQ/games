package com.datatub.scavenger.tag;

import com.yeezhao.commons.util.CollectionUtil;
import com.yeezhao.commons.util.Pair;

import java.io.IOException;
import java.util.*;

/**
 * com.datastory.banyan.tools.Tagger
 *
 * @author lhfcws
 * @since 2017/3/3
 */
public class Tagger {

    private TagModel tagModel;

    protected Tagger(TagModel tagModel) {
        this.tagModel = tagModel;
    }

    private Pair<HashSet<String>, HashSet<String>> getTags(String text, char[] cs, Trie<List<SingleWordTag>> trie, HashMap<String, List<Set<String>>> andMap) {
        List<List<SingleWordTag>> list = new LinkedList<>();
        if (trie != null)
            for (int i = 0; i < cs.length; i++) {
                List<List<SingleWordTag>> l = trie.greedyFind(cs, i);
                list.addAll(l);
            }
        Pair<HashSet<String>, HashSet<String>> pair = extractTagsFromResultList(list);
        HashSet<String> tags = pair.getFirst();
        HashSet<String> keys = pair.getSecond();

        // & tag
        if (andMap != null && !andMap.isEmpty())
            for (Map.Entry<String, List<Set<String>>> e : andMap.entrySet()) {
                String t = e.getKey();

                if (!tags.contains(t))
                    for (Set<String> andSet : e.getValue()) {
                        int cnt = 0;
                        for (String word : andSet) {
                            if (text.contains(word)) {
                                cnt++;
                            } else
                                break;
                        }
                        if (cnt == andSet.size()) {
                            tags.add(t);
                            for (String s : andSet) {
                                keys.add(s);
                            }
                            break;
                        }
                    }
            }

        return new Pair<>(tags, keys);
    }

    public Pair<HashSet<String>, HashSet<String>> tag1(String text) {
        HashSet<String> tags=new HashSet<>();
        HashSet<String> keys=new HashSet<>();

        HashMap<String, List<Set<String>>> filter = tagModel.getFilter();
        HashMap<String, List<Set<String>>>word = tagModel.getWord();

        if (filter != null && !filter.isEmpty())
            for (Map.Entry<String, List<Set<String>>> e : andMap.entrySet()) {
                String t = e.getKey();

                if (!tags.contains(t))
                    for (Set<String> andSet : e.getValue()) {
                        int cnt = 0;
                        for (String word : andSet) {
                            if (text.contains(word)) {
                                cnt++;
                            } else
                                break;
                        }
                        if (cnt == andSet.size()) {
                            tags.add(t);
                            for (String s : andSet) {
                                keys.add(s);
                            }
                            break;
                        }
                    }
            }


        return new Pair<>(tags,keys);

    }

    public Pair<HashSet<String>, HashSet<String>> tag(String text) {
        text = text.toLowerCase();
        char[] cs = text.toCharArray();

        Pair<HashSet<String>, HashSet<String>> tt = getTags(text, cs, tagModel.getSingleWord(), tagModel.getAndWord());
        HashSet<String> tags = tt.getFirst();


        boolean needFilter = false;
        for (String tag : tagModel.getHasFilterTags()) {
            if (tags.contains(tag)) {
                needFilter = true;
                break;
            }
        }

        if (needFilter) {
            Set<String> filters = getTags(text, cs, tagModel.getSingleFilter(), tagModel.getAndFilter()).getFirst();
            tags.removeAll(filters);
        }

        return new Pair<>(tags, tt.getSecond());
    }

    private Pair<HashSet<String>,HashSet<String>> extractTagsFromResultList(List<List<SingleWordTag>> list) {
        HashSet<String> set = new HashSet<>();
        HashSet<String> words = new HashSet<>();
        for (List<SingleWordTag> l : list)
            if (CollectionUtil.isNotEmpty(l))
                for (SingleWordTag s : l) {
                    set.add(s.getTag());
                    words.add(s.getWord());
                }
        return new Pair<>(set, words);
    }

    private static volatile HashMap<String, Tagger> taggers = new HashMap<>();

    public static Tagger get(String rname) throws IOException {
        if (!taggers.containsKey(rname)) {
            synchronized (Tagger.class) {
                if (!taggers.containsKey(rname)) {
//                    taggers.put(rname, new Tagger(Dict.load(rname)));
                    taggers.put(rname, new Tagger(Dict.load1(rname)));
                }
            }
            return taggers.get(rname);
        } else
            return taggers.get(rname);
    }

    public static void main(String[] args) throws Exception {
        Tagger tagger = Tagger.get("gainian.txt");
        Pair<HashSet<String>, HashSet<String>> set = tagger.tag("天然无添加，纯真酸牛奶，好味道，还可以作为护肤品。黄桃、木瓜任你选！");
        System.out.println(set.getFirst());
        System.out.println(set.getSecond());
        Set<String> set1 = tagger.tag("源于自然，草本食物！理想的ph值！").getFirst();
        System.out.println(set1);
        Set<String> set2 = tagger.tag("源于自然，有机食物！理想的ph值！").getFirst();
        System.out.println(set2);
        Set<String> set3 = tagger.tag("天然无添加，纯真酸牛奶，好味道，还可以作为护肤品,绿色风。黄桃、木瓜任你选！").getFirst();
        System.out.println(set3);
    }
}
