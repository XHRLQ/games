package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.Tag;
import com.datatub.scavenger.util.SparkUtil;
import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.broadcast.Broadcast;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by mou on 2017/3/6.
 */
public class FilterData implements CliRunner, Serializable {

    private static final String PARAM_IMPORT_CORE = "cores";

    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {
        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "P&G tagging process");

        JavaRDD<String> data = jsc.textFile("/tmp/mouhao/PGtag");

        File file = new File("/home/mouhao/commons.txt");

        List<String> lines = null;
        try {
            lines = Files.readLines(file, Charsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Set<String> keys = new HashSet<>();
        keys.addAll(lines);

        final Broadcast<Set<String>> bv = jsc.broadcast(keys);

        data.map(new Function<String, Tag>() {
            @Override
            public Tag call(String v1) throws Exception {
                Gson gson = new Gson();
                Tag tag = gson.fromJson(v1, Tag.class);
                return tag;
            }
        }).filter(new Function<Tag, Boolean>() {
            @Override
            public Boolean call(Tag v1) throws Exception {
                Set<String> s = bv.getValue();
                if (s.contains(v1.getUid())) {
                    return true;
                } else {
                    return false;
                }
            }
        }).map(new Function<Tag, String>() {
            @Override
            public String call(Tag v1) throws Exception {
                return new Gson().toJson(v1);
            }
        }).saveAsTextFile("/tmp/mouhao/PG-yeezhao-res");



        System.out.println("success!");
        jsc.stop();

    }

    public static void main(String[] args) throws IOException {
        AdvCli.initRunner(args, "customer insight data prepare", new FilterData());
    }


}
