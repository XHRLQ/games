package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.AnaTag;
import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.base.Tag;
import com.datatub.scavenger.tag.Tagger;
import com.datatub.scavenger.util.SparkUtil;
import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.broadcast.Broadcast;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by mou on 2017/3/6.
 */
public class MkData implements CliRunner, Serializable {

    private static final String PARAM_IMPORT_CORE = "cores";
    volatile static int delete = 0;

    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {


//        try {
//            delete = 1;
//            FileSystem fs = FileSystem.get(CustomeConfiguration.getInstance());
//            fs.deleteOnExit(new Path("/tmp/mouhao/PG-yeezhao-split-res"));
//            Thread.sleep(5000);
//            if (delete == 1) {
//                System.out.println("delete:" + delete);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "P&G tagging process");

        JavaRDD<String> data = jsc.textFile("/tmp/mouhao/pg_new_res.txt");

        // 重打标签
        data.map(new Function<String, String>() {
            @Override
            public String call(String v1) throws Exception {
                Gson GSON = new Gson();
                Tag tag = GSON.fromJson(v1, Tag.class);
                String content = tag.getContent();
                Set<String> gainianSet = mkTag(content);
                tag.setGainiantag(gainianSet);
                return GSON.toJson(tag);
            }
        }).repartition(50).saveAsTextFile("/tmp/mouhao/pg/new_res");


        JavaRDD<String> res = jsc.textFile("/tmp/mouhao/pg/new_res");

        res.map(new Function<String, Tag>() {
            @Override
            public Tag call(String v1) throws Exception {
                return new Gson().fromJson(v1, Tag.class);
            }
        }).flatMap(new FlatMapFunction<Tag, AnaTag>() {
            @Override
            public Iterable<AnaTag> call(Tag tag) throws Exception {
                List<AnaTag> li = new ArrayList<AnaTag>();

                for (String hufu : tag.getHufutag()) {
                    if (tag.getGainiantag().size()>0) {
                        for (String gainian : tag.getGainiantag()) {
                            li.add(new AnaTag(
                                    tag.getUid(),
                                    tag.getDate(),
                                    hufu,
                                    gainian,
                                    tag.getContent()));
                        }
                    } else {
                        li.add(new AnaTag(tag.getUid(),
                                tag.getDate(),
                                hufu,
                                "",
                                tag.getContent()));
                    }

                }

                return li;
            }
        }).map(new Function<AnaTag, String>() {
            @Override
            public String call(AnaTag v1) throws Exception {
                return new Gson().toJson(v1);
            }
        }).saveAsTextFile("/tmp/mouhao/pg/new_res_split");

        System.out.println("success!");
        jsc.stop();

    }

    private static Set<String> mkTag(String content) throws IOException {
        Tagger gainianTagger = Tagger.get("gainian.txt");
        Set<String> gainianTag = gainianTagger.tag(content).getFirst();
        return gainianTag;
    }


    public static void main(String[] args) throws IOException {
        AdvCli.initRunner(args, "customer insight data prepare", new MkData());
    }
}
