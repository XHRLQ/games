package com.datatub.scavenger.util;


import com.datatub.scavenger.base.CustomeConfiguration;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.ILineParser;
import com.yeezhao.commons.util.Pair;
import com.yeezhao.commons.util.StringUtil;
import com.yeezhao.hornbill.analyz.nlp.seg.Seg;
import org.apache.commons.collections.ArrayStack;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by mou on 2016/10/25.
 */
public class KeyWordLoader {
    private static final Log LOG = LogFactory.getLog(KeyWordLoader.class);

    public static List<String> getFile(String path) throws IOException {
        final List<String> lines = new ArrayList<String>();
        try {
            InputStream in = CustomeConfiguration.getInstance().getConfResourceAsInputStream(path);
            AdvFile.loadFileInDelimitLine(in, new ILineParser() {
                @Override
                public void parseLine(String line) {
                    if (StringUtil.isNullOrEmpty(line) || line.startsWith("#")) {

                    } else {
                        lines.add(line.trim());
                    }
                }
            });
            return lines;
        } catch (IOException e) {
            LOG.error("load file error " + path, e);
            throw e;
        }
    }


    /**
     * 传入一行码表，解析为固定格式
     *
     *  关键词1.1 | 关键词1.2 # 过滤词1 & 过滤词2.1 | 关键词2.2
     *  女儿#丈母娘&女婿
     *  儿子|小学#初|年级
     *
     * @param keywords
     * @return
     */
    public static Map<String,List<Pair<LinkedList<String>, Set<String>>>> getKeywordMap(List<String> keywords) {
        if (keywords == null || keywords.size() == 0) {
            throw new RuntimeException("卧槽码表是空的搞个毛线啊");
        }

        Map<String,List<Pair<LinkedList<String>, Set<String>>>> keywordMap = new HashMap<>();

        for (String keyword : keywords) {
            if (StringUtil.isNullOrEmpty(keyword)) {
                continue;
            }

            String[] words = keyword.trim().split("#");
            if (words.length < 1 || words.length > 2) {
                LOG.error("keywords formatting error : " + keyword);
                continue;
            }

            String[] keys = words[0].split("\\|");

            if (keys.length < 1) {
                LOG.error("keywords should more than one : " + keyword);
                continue;
            }

            String key = keys[0].toLowerCase();
            Seg.insertUserDefine(key);

            LinkedList<String> continueKeys = new LinkedList<String>();
            if (keys.length > 1) {
                for (int i=1; i<keys.length; i++) {
                    continueKeys.add(keys[i].toLowerCase());
                    Seg.insertUserDefine(keys[i].toLowerCase());
                }
            }

            Set<String> filterList = new HashSet<>();

            if (words.length == 2) {
                if (!StringUtil.isNullOrEmpty(words[1])) {

                    String[] filter = words[1].split("&");

                    for (int i=0; i<filter.length; i++) {
                        filterList.add(filter[i].toLowerCase());
                        Seg.insertUserDefine(filter[i].toLowerCase());
                    }
                }
            }

            if (keywordMap.containsKey(key)) {
                keywordMap.get(key).add(new Pair(continueKeys, filterList));
            } else {
                List<Pair<LinkedList<String>, Set<String>>> tmp = new ArrayList<>();
                tmp.add(new Pair<LinkedList<String>, Set<String>>(continueKeys, filterList));
                keywordMap.put(key, tmp);
            }
        }

        return keywordMap;
    }

    public static Set<String> getFilterWords(List<String> raw) {
        Set<String> set = new HashSet<>();

        if (raw==null || raw.size()==0) {
            return set;
        }

        for (String s : raw){
            set.add(s.trim().toLowerCase());
            Seg.insertUserDefine(s.trim().toLowerCase());
        }

        return set;
    }
}
