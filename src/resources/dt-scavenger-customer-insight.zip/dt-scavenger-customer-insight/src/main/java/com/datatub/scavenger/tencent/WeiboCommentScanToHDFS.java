package com.datatub.scavenger.tencent;

import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.util.SparkUtil;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.io.Serializable;

/**
 * Created by mou on 2017/5/25.
 */
public class WeiboCommentScanToHDFS implements CliRunner, Serializable {
    public static final String HBASE_TABLE = "dt.rhino.tecent.allsite.weibo";

    @Override
    public Options initOptions() {
        Options options = new Options();
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return true;
    }

    @Override
    public void start(CommandLine cmdLine) {
        run();
    }

    public static void main(String[] args) {
        AdvCli.initRunner(args, "customer insight data prepare", new WeiboCommentScanToHDFS());
    }


    public static void run() {
        JavaSparkContext jsc = SparkUtil.createSparkContext("50");

        CustomeConfiguration conf = CustomeConfiguration.getInstance();

        conf.set(TableInputFormat.INPUT_TABLE, HBASE_TABLE);
        conf.set(TableInputFormat.SCAN, HBaseUtils.createHBaseScan("c4c"));
        conf.setLong(HConstants.HBASE_CLIENT_SCANNER_TIMEOUT_PERIOD, 600000);

        JavaPairRDD<ImmutableBytesWritable, Result> data = jsc.newAPIHadoopRDD(conf, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

        JavaRDD<String> result = HBaseUtils.scanAllToJson(data);

        result.saveAsTextFile("/tmp/tencent/raw_data/section2/weibo_comment_0526");

        jsc.stop();
    }

}
