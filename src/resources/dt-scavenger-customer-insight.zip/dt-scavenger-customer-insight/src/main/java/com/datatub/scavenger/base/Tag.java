package com.datatub.scavenger.base;

import java.io.Serializable;
import java.util.Set;

/**
 * Created by mou on 2017/3/3.
 */
public class Tag implements Serializable{

    private String uid;
    private String date;
    private Set<String> hufutag;
    private Set<String> gainiantag;
    private String content;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Set<String> getHufutag() {
        return hufutag;
    }

    public void setHufutag(Set<String> hufutag) {
        this.hufutag = hufutag;
    }

    public Set<String> getGainiantag() {
        return gainiantag;
    }

    public void setGainiantag(Set<String> gainiantag) {
        this.gainiantag = gainiantag;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Tag(String uid, String date, Set<String> hufutag, Set<String> gainiantag, String content) {
        this.uid = uid;
        this.date = date;
        this.hufutag = hufutag;
        this.gainiantag = gainiantag;
        this.content = content;
    }
}
