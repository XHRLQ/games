package com.datatub.scavenger.tencent;

import java.io.Serializable;

/**
 * Created by mou on 2017/3/27.
 */
public class TencentEntity implements Serializable {

    public String dimension1="";
    public String dimension2="";
    public String description="";

    public String neodimension1="";
    public String neodimension2="";

    public String keywords="";

    public String events="";
    public String eventtype="";


    public String url = "";
    public String date=""; //yyyymmdd
    public String platform="";
    public String platformtype="";
    public String snt="";
    public String mid = "";
    public String writer="";
    public String ismainpost = "";
    public String isreal = "";

    public int readnum;
    public int praisenum;
    public int retweetnum;
    public int commentnum;
    public int attentionnum;
    public int fansnum;
    public double influence;

    public String company="";
    public String birthdate="";
    public String province="";
    public String city="";
    public String citylevel="";
    public String fanslevel="";
    public String gender="";
    public String favorite="";
    public String uid="";
    public String name="";
    public String device="";
    public String vtype="";
    public String content="";

    public int tag1 = 0;
    public int tag2 = 0;
    public int tag3 = 0;
    public int tag4 = 0;
    public int tag5 = 0;
    public int tag6 = 0;

    public int companycompare = 0;

    public int getCompanycompare() {
        return companycompare;
    }

    public void setCompanycompare(int companycompare) {
        this.companycompare = companycompare;
    }

    public String id;  // for elasticsearch use

    public String getEventtype() {
        return eventtype;
    }

    public void setEventtype(String eventtype) {
        this.eventtype = eventtype;
    }

    public String getIsreal() {
        return isreal;
    }

    public void setIsreal(String isreal) {
        this.isreal = isreal;
    }

    public int getTag6() {
        return tag6;
    }

    public void setTag6(int tag6) {
        this.tag6 = tag6;
    }

    public int getTag5() {
        return tag5;
    }

    public void setTag5(int tag5) {
        this.tag5 = tag5;
    }

    public int getTag1() {
        return tag1;
    }

    public void setTag1(int tag1) {
        this.tag1 = tag1;
    }

    public int getTag2() {
        return tag2;
    }

    public void setTag2(int tag2) {
        this.tag2 = tag2;
    }

    public int getTag3() {
        return tag3;
    }

    public void setTag3(int tag3) {
        this.tag3 = tag3;
    }

    public int getTag4() {
        return tag4;
    }

    public void setTag4(int tag4) {
        this.tag4 = tag4;
    }

    public String getIsmainpost() {
        return ismainpost;
    }

    public void setIsmainpost(String ismainpost) {
        this.ismainpost = ismainpost;
    }

    public String getDimension1() {
        return dimension1;
    }

    public void setDimension1(String dimension1) {
        this.dimension1 = dimension1;
    }

    public String getDimension2() {
        return dimension2;
    }

    public void setDimension2(String dimension2) {
        this.dimension2 = dimension2;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEvents() {
        return events;
    }

    public void setEvents(String events) {
        this.events = events;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getPlatformtype() {
        return platformtype;
    }

    public void setPlatformtype(String platformtype) {
        this.platformtype = platformtype;
    }

    public String getSnt() {
        return snt;
    }

    public void setSnt(String snt) {
        this.snt = snt;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public int getReadnum() {
        return readnum;
    }

    public void setReadnum(int readnum) {
        this.readnum = readnum;
    }

    public int getPraisenum() {
        return praisenum;
    }

    public void setPraisenum(int praisenum) {
        this.praisenum = praisenum;
    }

    public int getRetweetnum() {
        return retweetnum;
    }

    public void setRetweetnum(int retweetnum) {
        this.retweetnum = retweetnum;
    }

    public int getCommentnum() {
        return commentnum;
    }

    public void setCommentnum(int commentnum) {
        this.commentnum = commentnum;
    }

    public int getAttentionnum() {
        return attentionnum;
    }

    public void setAttentionnum(int attentionnum) {
        this.attentionnum = attentionnum;
    }

    public int getFansnum() {
        return fansnum;
    }

    public void setFansnum(int fansnum) {
        this.fansnum = fansnum;
    }

    public double getInfluence() {
        return influence;
    }

    public void setInfluence(double influence) {
        this.influence = influence;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitylevel() {
        return citylevel;
    }

    public void setCitylevel(String citylevel) {
        this.citylevel = citylevel;
    }

    public String getFanslevel() {
        return fanslevel;
    }

    public void setFanslevel(String fanslevel) {
        this.fanslevel = fanslevel;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFavorite() {
        return favorite;
    }

    public void setFavorite(String favorite) {
        this.favorite = favorite;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getVtype() {
        return vtype;
    }

    public void setVtype(String vtype) {
        this.vtype = vtype;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNeodimension1() {
        return neodimension1;
    }

    public void setNeodimension1(String neodimension1) {
        this.neodimension1 = neodimension1;
    }

    public String getNeodimension2() {
        return neodimension2;
    }

    public void setNeodimension2(String neodimension2) {
        this.neodimension2 = neodimension2;
    }

    @Override
    public String toString() {
        return "TencentEntity{" +
                "dimension1='" + dimension1 + '\'' +
                ", dimension2='" + dimension2 + '\'' +
                ", description='" + description + '\'' +
                ", keywords='" + keywords + '\'' +
                ", events='" + events + '\'' +
                ", eventtype='" + eventtype + '\'' +
                ", url='" + url + '\'' +
                ", date='" + date + '\'' +
                ", platform='" + platform + '\'' +
                ", platformtype='" + platformtype + '\'' +
                ", snt='" + snt + '\'' +
                ", mid='" + mid + '\'' +
                ", writer='" + writer + '\'' +
                ", ismainpost='" + ismainpost + '\'' +
                ", isreal='" + isreal + '\'' +
                ", readnum=" + readnum +
                ", praisenum=" + praisenum +
                ", retweetnum=" + retweetnum +
                ", commentnum=" + commentnum +
                ", attentionnum=" + attentionnum +
                ", fansnum=" + fansnum +
                ", influence=" + influence +
                ", company='" + company + '\'' +
                ", birthdate='" + birthdate + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", citylevel='" + citylevel + '\'' +
                ", fanslevel='" + fanslevel + '\'' +
                ", gender='" + gender + '\'' +
                ", favorite='" + favorite + '\'' +
                ", uid='" + uid + '\'' +
                ", name='" + name + '\'' +
                ", device='" + device + '\'' +
                ", vtype='" + vtype + '\'' +
                ", content='" + content + '\'' +
                ", tag1=" + tag1 +
                ", tag2=" + tag2 +
                ", tag3=" + tag3 +
                ", tag4=" + tag4 +
                ", tag5=" + tag5 +
                ", tag6=" + tag6 +
                ", companycompare=" + companycompare +
                ", id='" + id + '\'' +
                '}';
    }
}

