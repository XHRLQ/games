package com.datatub.scavenger.pg;

import com.datatub.scavenger.util.SparkUtil;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;

import com.yeezhao.hornbill.analyz.common.util.TweetFormatUtil;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.ToAnalysis;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by mou on 2017/3/23.
 */
public class WordCountCli implements CliRunner, Serializable {


    @Override
    public Options initOptions() {
        Options options = new Options();
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return true;
    }

    @Override
    public void start(CommandLine cmdLine) {
        JavaSparkContext jsc = SparkUtil.createSparkContext("50");

        JavaRDD<String> data = jsc.textFile("/apps/hive/warehouse/db_datastory_algo.db/allcontent/");

        data.flatMapToPair(new PairFlatMapFunction<String, String, Integer>() {
            @Override
            public Iterable<Tuple2<String, Integer>> call(String s) throws Exception {
                List<Tuple2<String, Integer>> li = new ArrayList<Tuple2<String, Integer>>();
                s = TweetFormatUtil.rmEmoji(s);
                s = TweetFormatUtil.rmLoc(s);
                s = TweetFormatUtil.rmMention(s);
                s = TweetFormatUtil.rmUrl(s);
                for (Term term : ToAnalysis.parse(s).getTerms()) {
                    li.add(new Tuple2<String, Integer>(term.getName(), 1));
                }

                return li;
            }
        }).reduceByKey(new Function2<Integer, Integer, Integer>() {
            @Override
            public Integer call(Integer v1, Integer v2) throws Exception {
                return v1 + v2;
            }
        }).map(new Function<Tuple2<String,Integer>, String>() {

            @Override
            public String call(Tuple2<String, Integer> v1) throws Exception {
                return v1._1 + "\t" + v1._2;
            }
        }).saveAsTextFile("/tmp/mouhao/pg_word_count");
    }

    public static void main(String[] args) {
        AdvCli.initRunner(args, "customer insight data prepare", new WordCountCli());
    }
}
