package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.BaseConsts;
import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.classifier.KeyWordExtractor;
import com.datatub.scavenger.util.DataReader;
import com.datatub.scavenger.util.HBaseUtil;
import com.yeezhao.commons.util.StringUtil;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaPairRDD;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.*;
import org.apache.spark.broadcast.Broadcast;


import scala.Tuple2;

import java.util.*;

/**
 * Created by mou on 2016/10/26.
 */
public class InsightRunner {
    public static final String HBASE_TABLE = "yeezhao.user.info";

    public static void run(
            JavaSparkContext jsc,
            List<String> keyWords,
            List<String> filterWords,
            List<String> kolList,
            String projectName,
            boolean isHBase) {

        String PATH1 = "/tmp/mouhao/" + projectName + "-keywordsResult";
        String PATH2 = "/tmp/mouhao/" + projectName + "-kolResult";
        String PATH3 = "/tmp/mouhao/" + projectName + "-finalResult";


        System.out.println("\n开始broadcast数据");
        final Broadcast<List<String>> keywordsBO = jsc.broadcast(keyWords);
        final Broadcast<List<String>> filterWordsBO= jsc.broadcast(filterWords);
        final Broadcast<HashSet<String>> kolListBO = jsc.broadcast(new HashSet<String>(kolList));


        // 判断从哪里获取数据
        JavaPairRDD<String, String> weiboRDD;
        if (isHBase) {
            CustomeConfiguration conf = CustomeConfiguration.getInstance();

            // 扫微博
            conf.set(TableInputFormat.INPUT_TABLE, HBASE_TABLE);
            conf.set(TableInputFormat.SCAN, HBaseUtil.createWeiboWeiboScan());
            conf.setLong(HConstants.HBASE_CLIENT_SCANNER_TIMEOUT_PERIOD, 600000);

            System.out.println("\n关键词扫描开始");

            // 判断是否有关键词
            JavaPairRDD<ImmutableBytesWritable, Result> hBaseRDD = HBaseUtil.getHbaseRdd(jsc, conf);
//            weiboRDD = DataReader.getWeiboFromHBase(hBaseRDD);
        } else {
            JavaRDD<String> raw = jsc.textFile(BaseConsts.WEIBO_HDFS_PATH);
            weiboRDD = DataReader.getWeiboFromHdfs(raw);
        }

//        assert weiboRDD != null;

        // 判断微博文本是否满足关键词条件
        // 对id进行聚合，统计单个id满足关键词的次数
//        JavaPairRDD<String,Integer> kwRDD = weiboRDD.mapPartitionsToPair(new PairFlatMapFunction<Iterator<Tuple2<String, String>>, String, Integer>() {
//            @Override
//            public Iterable<Tuple2<String, Integer>> call(Iterator<Tuple2<String, String>> tuple2Iterator) throws Exception {
//                List<Tuple2<String, Integer>> resultList = new ArrayList<Tuple2<String, Integer>>();
//
//                List<String> kw = keywordsBO.getValue();
//                List<String> fw = filterWordsBO.getValue();
//
//                KeyWordExtractor kwExtractor = new KeyWordExtractor(kw, fw);
//                while (tuple2Iterator.hasNext()) {
//                    Tuple2<String, String> res = tuple2Iterator.next();
//
//                    boolean flag = kwExtractor.match(res._2);
//
//                    if (flag) {
//                        resultList.add(new Tuple2<String, Integer>(res._1, 1));
//                    }
//                }
//                return resultList;
//            }
//        }).reduceByKey(new Function2<Integer, Integer, Integer>() {
//            @Override
//            public Integer call(Integer v1, Integer v2) throws Exception {
//                return v1 + v2;
//            }
//        });

//        kwRDD.cache();
//
//        System.out.println("\n所有满足关键词要求的用户数量为：" + kwRDD.count());
//
//        kwRDD.map(new Function<Tuple2<String, Integer>, String>() {
//            @Override
//            public String call(Tuple2<String, Integer> v1) throws Exception {
//                return v1._1 + "," + v1._2;
//            }
//        }).saveAsTextFile(PATH1);


        System.out.println("开始构建微博用户KOL关注");
        // 创建微博用户RDD
        JavaPairRDD<String, List<String>> userRDD;
        if (isHBase) {
            CustomeConfiguration conf = CustomeConfiguration.getInstance();

            // 扫微博
            conf.set(TableInputFormat.INPUT_TABLE, HBASE_TABLE);
            conf.set(TableInputFormat.SCAN, HBaseUtil.createWeiboUserFollowScan());
            conf.setLong(HConstants.HBASE_CLIENT_SCANNER_TIMEOUT_PERIOD, 600000);

            // 判断是否有关键词
            JavaPairRDD<ImmutableBytesWritable, Result> hBaseRDD = HBaseUtil.getHbaseRdd(jsc, conf);
            userRDD = DataReader.getUserFromHBase(hBaseRDD);
        } else {
            JavaRDD<String> raw = jsc.textFile(BaseConsts.WEIBO_USER_HDFS_PATH);
            userRDD = DataReader.getUserFromHdfs(raw);
        }

        assert userRDD != null;
        JavaPairRDD<String,Integer> followRDD = userRDD.flatMapToPair(new PairFlatMapFunction<Tuple2<String, List<String>>, String, Integer>() {
            @Override
            public Iterable<Tuple2<String, Integer>> call(Tuple2<String, List<String>> stringListTuple2) throws Exception {
                HashSet<String> kols = kolListBO.getValue();

                int count = 0;
                for (String s : stringListTuple2._2()) {
                    if (kols.contains(s)) {
                        count++;
                    }
                }

                if (count > 0) {
                    return Arrays.asList(new Tuple2<String, Integer>(stringListTuple2._1, count));
                } else {
                    return Arrays.asList();
                }
            }
        });

        followRDD.cache();
        System.out.println("\n满足Follower的用户数量为: " + followRDD.count());

        followRDD.map(new Function<Tuple2<String,Integer>, String>() {
            @Override
            public String call(Tuple2<String, Integer> v1) throws Exception {
                return v1._1+","+v1._2;
            }
        }).saveAsTextFile(PATH2);

//        kwRDD.join(followRDD).map(new Function<Tuple2<String,Tuple2<Integer,Integer>>, String>() {
//            @Override
//            public String call(Tuple2<String, Tuple2<Integer, Integer>> v1) throws Exception {
//                return v1._1 + "," + v1._2._1 + "," + v1._2._2;
//            }
//        }).saveAsTextFile(PATH3);

        jsc.stop();
    }
}
