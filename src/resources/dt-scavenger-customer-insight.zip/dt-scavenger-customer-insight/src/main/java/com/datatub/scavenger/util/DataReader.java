package com.datatub.scavenger.util;

import com.datatub.scavenger.base.BaseConsts;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import com.yeezhao.commons.util.StringUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import scala.Tuple2;

import java.util.*;

/**
 * Created by mou on 2016/10/27.
 */
public class DataReader {

    public static Tuple2<String, String> tupleStringParser(String s) {
        try {
            int i = s.indexOf(",");
            String id = s.substring(0, i);
            String content = s.substring(i+1);
            return new Tuple2<String, String>(id, content);
        } catch (Exception e) {
            System.out.println(s);
            return null;
        }
    }

    public static JavaPairRDD<String, String> getWeiboFromHdfs(JavaRDD<String> rawRDD) {
        System.out.println("读取Weibo数据，HDFS");
        return rawRDD.flatMapToPair(new PairFlatMapFunction<String, String, String>() {
            @Override
            public Iterable<Tuple2<String, String>> call(String s) throws Exception {
                List<Tuple2<String,String>> res = new ArrayList<Tuple2<String, String>>();
                Tuple2<String, String> tu = tupleStringParser(s);
                if (tu == null) {
                    return res;
                } else {
                    res.add(tu);
                    return res;
                }
            }
        });
    }

    public static JavaPairRDD<String, List<String>> getUserFromHdfs(JavaRDD<String> rawRDD) {
        System.out.println("读取WeiboUser数据，HDFS");

        return rawRDD.mapPartitionsToPair(new PairFlatMapFunction<Iterator<String>, String, List<String>>() {
            @Override
            public Iterable<Tuple2<String, List<String>>> call(Iterator<String> stringIterator) throws Exception {
                List<Tuple2<String, List<String>>> res = new ArrayList<Tuple2<String, List<String>>>();
                Gson GSON = new Gson();
                while (stringIterator.hasNext()) {
                    String ne = stringIterator.next();
                    try {
                        Tuple2<String, List<String>> entity = GSON.fromJson(ne, new TypeToken<Tuple2<String, List<String>>>() {
                        }.getType());
                        res.add(entity);
                    } catch (Exception e) {

                    }
                }

                return res;
            }
        });
    }

    public static JavaRDD<String> getWeiboFromHBase(JavaPairRDD<ImmutableBytesWritable, Result> rawRDD) {
        System.out.println("读取Weibo数据，HBase");
        return rawRDD.flatMap(new FlatMapFunction<Tuple2<ImmutableBytesWritable, Result>, String>() {
            @Override
            public Iterable<String> call(Tuple2<ImmutableBytesWritable, Result> immutableBytesWritableResultTuple2) throws Exception {
                List<String> resultList = new ArrayList<String>();

                Result usrRow = immutableBytesWritableResultTuple2._2();
                String rowKey = Bytes.toString(usrRow.getRow());
                String arr[] = rowKey.split(StringUtil.STR_DELIMIT_1ST);
                String uid = arr[1];



                String content = com.yeezhao.commons.hbase.HBaseUtil.getColumnValue(usrRow, "crawl:fp_content", new String[0]);


                if (StringUtil.isNullOrEmpty(uid)) {
                    return resultList;
                }

                if (content == null || StringUtil.isNullOrEmpty(content)) {
                    return resultList;
                }

                try {
                    String date;
                    date = WeiboHbaseUtil.parseTime(arr[3]);
                    String res = uid + "," + date + "," + content;
                    resultList.add(res);
                } catch (Exception e) {
                    return resultList;
                }

                return resultList;
            }
        });
    }



    public static JavaPairRDD<String, List<String>> getUserFromHBase(JavaPairRDD<ImmutableBytesWritable, Result> rawRDD) {
        System.out.println("读取WeiboUser数据，HBase");
        return rawRDD.flatMapToPair(new PairFlatMapFunction<Tuple2<ImmutableBytesWritable,Result>, String, List<String>>() {
            @Override
            public Iterable<Tuple2<String, List<String>>> call(Tuple2<ImmutableBytesWritable, Result> immutableBytesWritableResultTuple2) throws Exception {
                Result row = immutableBytesWritableResultTuple2._2();
                String rowKey = Bytes.toString(row.getRow());

                String arr[] = rowKey.split(StringUtil.STR_DELIMIT_1ST);
                String uid = arr[1];

                // 僵尸
                String userType = Bytes.toString(row.getValue(BaseConsts.FMLY_ANALYZ, BaseConsts.QUA_USERTYPE));
                int zombie = 1;
                if (userType != null) {
                    if (Integer.valueOf(userType) == BaseConsts.USER_TYPE.UNK.getCode()
                            || Integer.valueOf(userType) == BaseConsts.USER_TYPE.NORMAL.getCode()) {
                        zombie = 0;
                    }
                }

                if (zombie == 1) {
                    return Arrays.asList();
                }

                if (StringUtil.isNullOrEmpty(uid)) {
                    return Arrays.asList();
                }

                // follow
                NavigableMap<byte[], byte[]> allFollowsMap = row.getFamilyMap(BaseConsts.FMLY_FOLLOW);
                List<String> followers = new ArrayList<String>();

                if (allFollowsMap != null) {
                    Set<Map.Entry<byte[], byte[]>> entryAllFollowSet = allFollowsMap.entrySet();

                    for (Map.Entry<byte[], byte[]> entry : entryAllFollowSet) {
                        String qualifierStr = Bytes.toString(entry.getKey());
                        if (qualifierStr != null && !qualifierStr.isEmpty()) {
                            followers.add(qualifierStr);
                        }
                    }

                    return Arrays.asList(new Tuple2<String, List<String>>(uid, followers));
                } else {
                    return Arrays.asList();
                }
            }
        });
    }
}
