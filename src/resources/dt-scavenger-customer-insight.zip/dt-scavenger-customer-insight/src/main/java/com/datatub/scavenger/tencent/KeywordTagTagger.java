package com.datatub.scavenger.tencent;

import com.datatub.scavenger.tag.Tagger;

/**
 * @Author: SMA
 * @Date: 2017-08-28 21:03
 * @Explain:
 */
public class KeywordTagTagger {
    public static Tagger kwTagger = null;

    private KeywordTagTagger() {

    }

    public static Tagger getInstance() {
        if (kwTagger == null) {
            synchronized (KeywordTagTagger.class) {
                if (kwTagger == null) {
                    try {
                        kwTagger = Tagger.get("tencent_mabiao_0826.txt");
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new RuntimeException("KeywordTagTagger Initial Error!!");
                    }

                }
            }
        }
        return kwTagger;
    }
}
