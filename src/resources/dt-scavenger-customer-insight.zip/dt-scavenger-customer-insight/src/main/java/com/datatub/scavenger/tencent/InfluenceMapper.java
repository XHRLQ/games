package com.datatub.scavenger.tencent;

import com.datatub.scavenger.base.CustomeConfiguration;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.ClassUtil;
import com.yeezhao.commons.util.ILineParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mou on 2017/3/26.
 */
public class InfluenceMapper {
    private static Map<String, Double> map;

    public static double get(String date, String platformtype) {
        if (map==null) {
            synchronized (InfluenceMapper.class) {
                if (map==null) {
                    final Map<String, Double> map1 = new HashMap<>();

                    InputStream inputStream = ClassUtil.getResourceAsInputStream("index1.txt");
                    try {
                        AdvFile.loadFileInLines(inputStream, new ILineParser() {
                            @Override
                            public void parseLine(String line) {
                                if (line == null || line.equals("")) {
                                    return;
                                } else {
                                    String[] seg = line.split("\t");
                                    String date = seg[0];
                                    double weibo = Double.parseDouble(seg[1]);
                                    double wechat = Double.parseDouble(seg[2]);
                                    double news = Double.parseDouble(seg[3]);
                                    double forum = Double.parseDouble(seg[4]);

                                    map1.put(date+"微博", weibo);
                                    map1.put(date+"微信", wechat);
                                    map1.put(date+"新闻", news);
                                    map1.put(date+"论坛", forum);
                                }

                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    map = map1;
                }
            }
        }
        String key = date+platformtype;
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        System.out.println(get("20160925", "论坛"));
    }
}
