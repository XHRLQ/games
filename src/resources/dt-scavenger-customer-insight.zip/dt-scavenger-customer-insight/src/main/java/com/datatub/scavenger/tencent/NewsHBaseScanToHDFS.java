package com.datatub.scavenger.tencent;

import com.datatub.scavenger.base.BaseConsts;
import com.datatub.scavenger.base.CustomeConfiguration;

import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.hbase.HBaseUtil;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.protobuf.ProtobufUtil;
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos;
import org.apache.hadoop.hbase.util.Base64;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.util.Pair;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import scala.Tuple2;

import java.io.IOException;
import java.io.Serializable;
import java.util.*;

/**
 * Created by mou on 2017/5/22.
 */
public class NewsHBaseScanToHDFS implements CliRunner, Serializable {
    public static final String HBASE_TABLE = "dt.rhino.app.mig.article";



    @Override
    public Options initOptions() {
        Options options = new Options();
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return true;
    }

    @Override
    public void start(CommandLine cmdLine) {
        prefixRun();
    }

    public static void main(String[] args) {
        AdvCli.initRunner(args, "customer insight data prepare", new NewsHBaseScanToHDFS());
    }

    public static void prefixRun() {
        JavaSparkContext jsc = SparkUtil.createSparkContext("50");
        run("2fe\\|tx_pinpai_20170520145353_211_29", jsc);
        run("e78\\|tx_pinpai_20170520145403_554_68", jsc);
        run("902\\|tx_pinpai_20170520145410_537_50", jsc);
        run("2f7\\|tx_pinpai_20170520145457_218_62", jsc);
        run("ff5\\|tx_pinpai_20170520145506_875_2", jsc);
        run("916\\|tx_pinpai_20170520145511_236_68", jsc);
        run("7a3\\|tx_pinpai_20170520145516_463_37", jsc);
        run("d0d\\|tx_pinpai_20170520145522_776_25", jsc);
        run("f9d\\|tx_pinpai_20170520145527_228_69", jsc);

        jsc.stop();
    }

    public static void run(String prefix, JavaSparkContext jsc) {

        CustomeConfiguration conf = CustomeConfiguration.getInstance();

        conf.set(TableInputFormat.INPUT_TABLE, HBASE_TABLE);
        conf.set(TableInputFormat.SCAN, HBaseUtils.createHBaseScan(prefix));
        conf.setLong(HConstants.HBASE_CLIENT_SCANNER_TIMEOUT_PERIOD, 600000);

        System.out.println("\n关键词扫描开始");


        JavaPairRDD<ImmutableBytesWritable, Result> data = jsc.newAPIHadoopRDD(conf, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

        JavaRDD<String> result = HBaseUtils.scanAllToJson(data);
        result.saveAsTextFile("/tmp/tencent/raw_data/section2/raw_data_newsforum_section2_"+prefix);

        jsc.stop();

    }



    public static final List<Pair<byte[], byte[]>> INFO_FMLYCOLS = HBaseUtil.getColsInBytes(new String[]{
            "raw:item_id",
            "raw:unique_id",
            "raw:unique_parent_id",
            "raw:is_main_post",
            "raw:keyword",
            "raw:site",
            "raw:title",
            "raw:content",
            "raw:url",
            "raw:author",
            "raw:view_count",
            "raw:review_count",
            "raw:like_count",
            "raw:dislike_count",
            "raw:category",
            "raw:province",
            "raw:city",
            "raw:other_data",
            "raw:guess_date",
            "raw:publish_date",
            "raw:update_date",
            "raw:sourceCrawlerId"
    });
}
