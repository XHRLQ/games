package com.datatub.scavenger.util.es;

import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.ActionRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.update.UpdateRequestBuilder;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.transport.TransportAddress;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * com.datastory.banyan.es.SimpleEsBulkClient
 *
 * @author lhfcws
 * @since 2017/2/10
 */
public class SimpleEsBulkClient  {
    protected String indexName = null;
    protected String indexType = null;
    protected int bulkActions;

    protected TransportClient client;
    protected volatile BulkRequest bulkRequest;

    public SimpleEsBulkClient(String clusterName, String indexName, String indexType,
                              String[] hosts, int bulkActions) {
        this(ImmutableSettings.settingsBuilder()
                        .put("cluster.name", clusterName)
                        .put("client.transport.ping_timeout", "60s")
                        .build(),
                indexName, indexType, hosts, bulkActions);
    }

    protected SimpleEsBulkClient(Settings settings, String indexName, String indexType,
                                 String[] esHosts, int bulkActions) {
        this.indexName = indexName;
        this.indexType = indexType;
        this.bulkActions = bulkActions;
        TransportAddress[] transportAddresses = new InetSocketTransportAddress[esHosts.length];
        for (int i = 0; i < esHosts.length; i++) {
            String[] parts = esHosts[i].split(":");
            int port = 9300;
            if (parts.length > 1)
                port = Integer.parseInt(parts[1]);
            try {
                InetAddress inetAddress = InetAddress.getByName(parts[0]);
                transportAddresses[i] = new InetSocketTransportAddress(inetAddress, port);
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
        }


        client = new TransportClient(settings).addTransportAddresses(transportAddresses);
        bulkRequest = new BulkRequest();
    }


    public String getIndexName() {
        return indexName;
    }

    public String getIndexType() {
        return indexType;
    }

    public Client getClient() {
        return client;
    }

    public void addDoc(YZDoc doc) {
        if (doc.getId() == null) {
            addWithNoneIdDoc(doc);
        } else {
            addDoc(doc, "");
        }
    }

    public void addWithNoneIdDoc(YZDoc doc) {
        if (doc == null) {
            return;
        }

        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType);
        indexRequest.source(doc.toJson());
        bulkRequest.add(indexRequest);
    }

    public void addDoc(YZDoc doc, String parent) {
        if (doc == null || doc.getId() == null)
            return;

        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType);

        String id = doc.getId();
        if (null != id) {
            indexRequest.id(id);
        }

        if (!StringUtils.isEmpty(parent)) {
            indexRequest.parent(parent);
        }

        indexRequest.source(doc.toJson());
        bulkRequest.add(indexRequest);
    }

    public boolean deleteDoc(String id) {
        this.deleteDoc(id, null);
        return true;
    }

    public boolean deleteDoc(String id, String parent) {
        if (StringUtils.isEmpty(id))
            return false;

        DeleteRequest deleteRequest = Requests.deleteRequest(indexName).type(indexType).id(id);

        if (!StringUtils.isEmpty(parent)) {
            deleteRequest.parent(parent);
        }

        bulkRequest.add(deleteRequest);
        return true;
    }

    public void updateDoc(YZDoc doc) {
        this.updateDoc(doc, null);
    }

    public void updateDoc(YZDoc doc, String parent) {
        if (doc == null || doc.getId() == null)
            return;

        String id = doc.getId();

        UpdateRequestBuilder updateRequestBuilder = client.prepareUpdate(indexName, indexType, id);

        if (!StringUtils.isEmpty(parent)) {
            updateRequestBuilder.setParent(parent);
        }
        updateRequestBuilder.setDoc(doc.toJson()).execute().actionGet();
    }

    public void addDoc(YZDoc doc, IndexRequest.OpType opType) {
        addDoc(doc, opType, null);
    }

    public void addDoc(YZDoc doc, IndexRequest.OpType opType, String parent) {
        if (doc == null || doc.getId() == null)
            return;
        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType).opType(opType);
        String id = doc.getId();
        if (null != id) {
            indexRequest.id(id);
        }

        if (!StringUtils.isEmpty(parent)) {
            indexRequest.parent(parent);
        }
        indexRequest.source(doc.toJson());

        bulkRequest.add(indexRequest);
    }

    public void add(ActionRequest ar) {
        bulkRequest.add(ar);
    }

    public void close() throws InterruptedException {
        client.close();
    }

    public void flushNClose() throws InterruptedException {
        flush();
        close();
    }

    public void flush() {
        if (!bulkRequest.requests().isEmpty())
            synchronized (this) {
                if (!bulkRequest.requests().isEmpty()) {
                    final BulkRequest br = bulkRequest;
                    bulkRequest = new BulkRequest();
                    client.bulk(br, new ActionListener<BulkResponse>() {
                        @Override
                        public void onResponse(BulkResponse bulkItemResponses) {
                        }

                        @Override
                        public void onFailure(Throwable e) {

                        }
                    });
                }
            }
    }

}
