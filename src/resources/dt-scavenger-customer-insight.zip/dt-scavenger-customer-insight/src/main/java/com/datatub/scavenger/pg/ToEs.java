package com.datatub.scavenger.pg;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.util.es.ESWriter;
import com.mysql.jdbc.StringUtils;
import com.yeezhao.commons.util.*;
import com.yeezhao.commons.util.Entity.Params;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.*;

/**
 * Created by mou on 2017/5/4.
 */
public class ToEs implements CliRunner, Serializable {

    final static List<String> to = Arrays.asList(
            "date","fans_cnt","bi_follow_cnt","city","vtype",
            "yearmonth","content","uid","user_type","wb_cnt",
            "follow_cnt","verified_type","name","gainiantag",
            "hufutag","activeness","desc","target"
    );

    final static List<String> to1 = Arrays.asList(
            "user_classification", "content_classification1",
            "content_classification2", "retweetFrom",
            "topics", "at", "mentions"
    );


    @Override
    public Options initOptions() {
        Options options = new Options();
        options.addOption("input", true, "input path, can be a directory");
        options.addOption("index", true, "es index name");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine commandLine) {
        return commandLine.hasOption("input") && commandLine.hasOption("index");
    }

    @Override
    public void start(CommandLine commandLine) {
        String esIndex = commandLine.getOptionValue("index");
        String input = commandLine.getOptionValue("input");

        run(esIndex, input);
    }

    public static void run(String index, String path) {


        InputStream in = CustomeConfiguration.getInstance().getConfResourceAsInputStream(path);
        final ESWriter esWriter = ESWriter.getInstance(index, "t");
        final Map<String, Integer> count = new HashMap<>();

        try {
            AdvFile.loadFileInLines(in, new ILineParser() {
                @Override
                public void parseLine(String s) {
                    Analysis.inc(count, "count");
                    if (count.get("count") % 50000 == 0) {
                        System.out.println("current: " + count);
                    }

                    Params p = new Params();

                    if (StringUtils.isNullOrEmpty(s)) {
                        return;
                    }

                    JSONObject obj = JSONObject.parseObject(s);

                    for (String s1 : to) {
                        p.put(s1, obj.getString(s1));
                    }

                    for (String s1 : to1) {
                        JSONArray arr = obj.getJSONArray(s1);
                        ArrayList<String> li = new ArrayList<String>();
                        for (int i=0; i<arr.size(); i++) {
                            li.add(arr.getString(i));
                        }
                        p.put(s1, li);
                    }

                    p.put("id", String.valueOf(count.get("count")));

                    esWriter.write(p);
                }
            });

            esWriter.flush();
            esWriter.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("write es success:" + index);

    }

    public static void main(String[] args) throws Exception {
        AdvCli.initRunner(args, "ImportHdfsCsv2Es", new ToEs());
    }
}
