package com.datatub.scavenger.classifier;

import com.yeezhao.hornbill.analyz.algo.sentiment.tweets.MigSntmntClassifier;
import com.yeezhao.hornbill.analyz.algo.sentiment.tweets.TwtSntmntClassifier;
import com.yeezhao.hornbill.analyz.common.util.TweetFormatUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * For starcom sentiment analysis project.
 *
 * 针对影视节目的情感判断
 *
 * Created by mou on 2017/6/15.
 */
public class StarcomSntmntClassifier {
    private static Log LOG = LogFactory.getLog(StarcomSntmntClassifier.class);

    private static TwtSntmntClassifier twtSntmntClassifier = null;
    private static MigSntmntClassifier migSntmntClassifier = null;

    private static StarcomSntmntClassifier instance = null;
    public static StarcomSntmntClassifier getInstance() {

        if (null==instance) {
            synchronized (StarcomSntmntClassifier.class) {
                if (null==instance) {
                    try {
                        twtSntmntClassifier = new TwtSntmntClassifier();
                        migSntmntClassifier = new MigSntmntClassifier();

                        instance = new StarcomSntmntClassifier();
                    } catch (Exception e) {
                        LOG.error("Init sentiment model fail", e);
                    }

                }
            }
        }
        return instance;
    }

    public String reweetRemoveRegex = "\\/\\/@.+:.+";
    public List<String> neuralString = Arrays.asList(
            "→","二等奖","亲自采购","使用#秒拍#录制","健康频道","全集","分享自","加v","娱乐频道","密码",
            "广东频道","广告频道","开播倒计时","快抽奖","抢名额","抽送","抽选","播出时间","整片","更新到",
            "最新一期","来自@网易云音乐","生活频道","电视剧频道","电视预告在线","综艺频道","获得精美礼物",
            "营销教程","认证教程","请点击登陆","转福利","阅读全文","音乐频道","约吗",">>>","红包","未播花絮",
            "转发此微博","重返校园赛"
    );

    public static final String regexTopicStr = "#(.+?)#|【(.+?)】";
    public static Pattern regexTopic = Pattern.compile(regexTopicStr);
    public static String rmTopic(String ln) {
        Matcher matcher = regexTopic.matcher(ln);
        return matcher.replaceAll(" ").replaceAll("\\s+", " ").trim();
    }

    public String classify(String content) {


        // remove 表情、转发
        content = content.replaceAll(reweetRemoveRegex, "");
        content = TweetFormatUtil.rmEmoji(content);
        content = TweetFormatUtil.rmMention(content);
        content = TweetFormatUtil.rmLoc(content);
        content = rmTopic(content);

        if (content.length() <= 2) {
            return "0";
        }

        for (String s : neuralString) {
            if (content.contains(s)) {
                return "0";
            }
        }

        int migRes = Integer.parseInt(migSntmntClassifier.classify(content));
        if (migRes==-1) {
            return "-1";
        }

        int result = 0;
        try {
            result = (int) twtSntmntClassifier.sentiment(content);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // filter by generat features


        return String.valueOf(result);
    }



}
