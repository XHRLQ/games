package com.datatub.scavenger.util;

/**
 * Created by mou on 2017/2/28.
 */
public class Weibo {
    public String date;
    public String uid;
    public String content;

    public Weibo(String date, String uid, String content) {
        this.date = date;
        this.uid = uid;
        this.content = content;
    }

}
