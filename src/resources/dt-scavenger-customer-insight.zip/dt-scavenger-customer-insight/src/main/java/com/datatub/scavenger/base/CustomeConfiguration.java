package com.datatub.scavenger.base;

import com.yeezhao.commons.config.ConfigUtil;
import org.apache.hadoop.conf.Configuration;

import java.io.Serializable;

/**
 * Created by mou on 2016/10/25.
 */
public class CustomeConfiguration extends Configuration implements Serializable {

//    public static final String[] DEFAULT_PARAM_CONFIGS = new String[]{};
//    private static final String[] DEFAULT_COMMON_PARAM_CONFIGS = new String[]{"spark.master.url"};

    public CustomeConfiguration() {
        this.addResource("config.xml");
        this.addResource("core-site.xml");
        this.addResource("hdfs-site.xml");
        this.addResource("mapred-site.xml");
        this.addResource("yarn-site.xml");
        this.addResource("hbase-site.xml");

//        try {
//            ConfigUtil.fastLoadConfig(this, "yeezhao", "commons", DEFAULT_COMMON_PARAM_CONFIGS, new String[0]);
//        } catch (Exception var4) {
//            var4.printStackTrace();
//        }
    }

    private static CustomeConfiguration _config = null;

    public static CustomeConfiguration getInstance() {
        if (_config==null) {
            synchronized (CustomeConfiguration.class) {
                if (_config==null) {
                    _config = new CustomeConfiguration();
                }
            }
        }
        return _config;
    }

}
