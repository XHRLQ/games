package com.datatub.scavenger.tencent;

import com.datatub.scavenger.tag.Tagger;
import com.datatub.scavenger.util.SparkUtil;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;

import com.yeezhao.commons.util.Pair;
import com.yeezhao.hornbill.analyz.algo.sentiment.tweets.MigSntmntClassifier;
import com.yeezhao.hornbill.analyz.algo.text.ad.tweet.TwtAdClassifier;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.*;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;

/**
 * Created by mou on 2017/3/21.
 */
public class FuckingShitCli implements CliRunner, Serializable {



    @Override
    public Options initOptions() {
        Options options = new Options();
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return true;
    }

    @Override
    public void start(CommandLine cmdLine) {
        mkSecicalTag();
    }

    public static void mkSecicalTag() {

        JavaSparkContext jsc = SparkUtil.createSparkContext("50");

        getWechat(jsc)
                .union(getNewsForums(jsc))
                .union(getWeiboData(jsc))
                .flatMap(new FlatMapFunction<TencentEntity, String>() {
                    @Override
                    public Iterable<String> call(TencentEntity entity) throws Exception {

                        List<String> res = new ArrayList<String>();
                        TencentEntity entity1 = Analyzer.parseEntity(entity);

                        if (entity1==null) {
                            return res;
                        }

                        Analyzer.mkMatchTagTmp(entity1);

                        res.add(new Gson().toJson(entity1));
                        return res;
                    }
                })
                .saveAsTextFile("/tmp/tencent/result/middle/0707");
    }




    public static JavaRDD<TencentEntity> getWechat(JavaSparkContext jsc) {

        // 一期
        // /tmp/tencent/raw_data/wechat_tencent.csv
        JavaRDD<TencentEntity>  wechat1 = parse(jsc.textFile("/tmp/tencent/raw_data/wechat_tencent.csv"), 2);

        // 二期
        // /tmp/tencent/raw_data/section2/wechat/*
        JavaRDD<TencentEntity>  wechat2 = parse(jsc.textFile("/tmp/tencent/raw_data/section2/wechat_convert/*"), 2);

        return wechat1.union(wechat2);
    }


    public static JavaRDD<TencentEntity> getNewsForums(JavaSparkContext jsc) {

        // 一期
        // xiaohui的数据
        JavaRDD<TencentEntity>  newforum = parse(jsc.textFile("/tmp/tencent/raw_data/newsforum_tencent.csv"), 3);

        // zhihangnews
        JavaRDD<TencentEntity>  zhihangnews1 = parse(jsc.textFile("/tmp/tencent/raw_data/tx_pinpai_news_after_11.csv"), 5);
        JavaRDD<TencentEntity>  zhihangnews2 = parse(jsc.textFile("/tmp/tencent/raw_data/tx_pinpai_news_before_11.csv"), 5);

        // zhihangforum
        JavaRDD<TencentEntity>  zhihangfourm1 = parse(jsc.textFile("/tmp/tencent/raw_data/tx_pinpai_post_after_11.csv"), 4);
        JavaRDD<TencentEntity>  zhihangfourm2 = parse(jsc.textFile("/tmp/tencent/raw_data/tx_pinpai_post_before_11.csv"), 4);


        // 二期
        // /tmp/tencent/raw_data/section2/raw_data_newsforum_section2 Hangs
        JavaRDD<TencentEntity> hangsNewsForums = parse(jsc.textFile("/tmp/tencent/raw_data/section2/raw_data_newsforum_section2"), 6);

        // xiaohui
        // /tmp/tencent/raw_data/section2/newsforum-mainPost
        JavaRDD<TencentEntity> xiaohuiNewsFourms = parse(jsc.textFile("/tmp/tencent/raw_data/section2/newsforum_convert/*"), 3);


        return newforum
                .union(zhihangfourm1)
                .union(zhihangfourm2)
                .union(zhihangnews1)
                .union(zhihangnews2)
                .union(hangsNewsForums)
                .union(xiaohuiNewsFourms);
    }


    public static JavaRDD<TencentEntity> getWeiboData(JavaSparkContext jsc) {

        // 一期
        JavaRDD<TencentEntity> weiboSection1 = parse(jsc.textFile("/tmp/tencent/raw_data/weibo_tencent.csv"), 1);

        // 二期
        JavaRDD<TencentEntity> weiboSection2 = parse(jsc.textFile("/tmp/tencent/raw_data/section2/weibo_utf8/*"), 1);

        return weiboSection1.union(weiboSection2);
    }



    public static JavaRDD<TencentEntity> parse(JavaRDD<String> data, final int i) {
        return data.flatMap(new FlatMapFunction<String, TencentEntity>() {
            @Override
            public Iterable<TencentEntity> call(String s) throws Exception {
                List<TencentEntity> li = new ArrayList<TencentEntity>();
                try {
                    TencentEntity entity = null;

                    switch (i) {
                        case 1:
                            entity = CsvParser.weiboParse(s);
                            break;
                        case 2:
                            entity = CsvParser.wechatParse(s);
                            break;
                        case 3:
                            entity = CsvParser.newforumsParse(s);
                            break;
                        case 4:
                            entity = CsvParser.zhihangForumParse(s);
                            break;
                        case 5:
                            entity = CsvParser.zhihangnewsParse(s);
                            break;
                        case 6:
                            entity = CsvParser.zhihangNewsForumSection2(s);
                            break;
                    }

                    if (entity != null) {
                        li.add(entity);
                    }
                    return li;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return li;
            }
        });
    }

    public static void main(String[] args) throws Exception {
        AdvCli.initRunner(args, "customer insight data prepare", new FuckingShitCli());
    }
}
