package com.datatub.scavenger.tag;

import java.util.*;

/**
 * com.datastory.banyan.tools.TagModel
 *
 * @author lhfcws
 * @since 2017/3/3
 */
public class TagModel {
    private Trie<List<SingleWordTag>> singleWord;
    private Trie<List<SingleWordTag>> singleFilter;
    private HashMap<String, List<Set<String>>> andWord;
    private HashMap<String, List<Set<String>>> andFilter;
    private HashSet<String> hasFilterTags = new HashSet<>();

    private HashMap<String, HashMap<List<Set<String>>,List<Set<String>>>> wordAndFilter;

    public TagModel() {
        andWord = new HashMap<>();
        andFilter = new HashMap<>();
    }

    public HashSet<String> getHasFilterTags() {
        return hasFilterTags;
    }

    public void setHasFilterTags(HashSet<String> hasFilterTags) {
        this.hasFilterTags = hasFilterTags;
    }

    public Trie<List<SingleWordTag>> getSingleWord() {
        return singleWord;
    }

    public void setSingleWord(Trie<List<SingleWordTag>> singleWord) {
        this.singleWord = singleWord;
    }

    public Trie<List<SingleWordTag>> getSingleFilter() {
        return singleFilter;
    }

    public void setSingleFilter(Trie<List<SingleWordTag>> singleFilter) {
        this.singleFilter = singleFilter;
    }

    public HashMap<String, List<Set<String>>> getAndWord() {
        return andWord;
    }

    public void setAndWord(HashMap<String, List<Set<String>>> andWord) {
        this.andWord = andWord;
    }

    public HashMap<String, List<Set<String>>> getAndFilter() {
        return andFilter;
    }

    public void setAndFilter(HashMap<String, List<Set<String>>> andFilter) {
        this.andFilter = andFilter;
    }

    public HashMap<String, List<Set<String>>> getFilter() {
        return filter;
    }

    public HashMap<String, List<Set<String>>> getWord() {
        return word;
    }


}
