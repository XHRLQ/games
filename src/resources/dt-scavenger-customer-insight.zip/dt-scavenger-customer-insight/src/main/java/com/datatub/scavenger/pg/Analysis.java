package com.datatub.scavenger.pg;

import com.alibaba.fastjson.JSONObject;
import com.datatub.scavenger.tag.Tagger;
import com.mysql.jdbc.StringUtils;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.ILineParser;
import com.yeezhao.commons.util.Pair;
import com.yeezhao.hornbill.analyz.algo.text.ad.tweet.TwtAdClassifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by mou on 2017/5/3.
 */
public class Analysis {

    static Map<String, String> kolMap = null;

    static {
        try {
            kolMap = Util.kolUtil();
        } catch (Exception e) {
            throw new RuntimeException("load kol map error", e);
        }
    }

    /**
     * parsing entity from content
     *
     * @param content
     * @return
     * @throws Exception
     */
    public static Set<String> mkTag(String content) throws Exception {

        Set<String> tags = new HashSet<>();

        // 明星
        // 综艺节目和电视剧
        // 时间7410
        Tagger tag = Tagger.get("pg_triple.txt");
        Pair<HashSet<String>, HashSet<String>> res = tag.tag(content);
        HashSet<String> starRes = res.getFirst();
        tags.addAll(starRes);


        // 新品上市
        // 代购海淘
        // 促销
        // 抽奖互动
        Tagger tag2 = Tagger.get("pg_tuple.txt");
        HashSet<String> otherres = tag2.tag(content).getFirst();
        tags.addAll(otherres);

        return tags;

    }

    public static Set<String> mkKolTag(String verifReason) throws Exception {
        Set<String> tags = new HashSet<>();

        // KOL 类别
        Tagger tag = Tagger.get("pg_kol.txt");
        HashSet<String> res = tag.tag(verifReason).getFirst();
        tags.addAll(res);

        return res;
    }

    public static String mkKolCategories(String vtype) throws Exception {

        int v = Integer.parseInt(vtype);

        if (v==1) {
            return "用户分类#蓝V";
        } else if (v==2){
            return "用户分类#黄V";
        } else {
            return "用户分类#普通";
        }
    }

    public static Pattern regexMention = Pattern.compile("@([0-9a-zA-Z一-龥_-]+)( |$)");
    public static Pattern retweetMention = Pattern.compile("//@([0-9a-zA-Z一-龥_-]+):");
    public static Pattern regexTopic = Pattern.compile("#([0-9a-zA-Z一-龥_-]{1,15})#");

    /**
     * [爱你][爱你]wuli曼春用的同款产品是：【兰芝气垫bb霜，兰芝水滴唇釉 ，兰芝双色立体唇膏】，时光不仅惊艳了美人，更是沉淀了对兰芝产>       品的打磨，好产品，值得信赖。[爱你][爱你][爱你] @兰芝中国
     *  => 兰芝中国
     *
     * @param content
     * @return
     * @throws Exception
     */
    public static Set<String> parseMention(String content) throws Exception {

        Matcher matcher = regexMention.matcher(content);
        Set<String> set = new HashSet<>();
        while (matcher.find()) {
            String s = matcher.group(1);
            set.add(s);
        }

        return set;
    }

    /**
     *  我不喜欢气垫可是我喜欢ysl的粉底，所以我还是有点想买！ //@陳兔夏:我不服
     *
     *  => 陳兔夏
     *
     * @param content
     * @return
     * @throws Exception
     */
    public static Set<String> parseRetweet(String content) throws Exception {
        Matcher matcher = retweetMention.matcher(content);
        Set<String> set = new HashSet<>();
        while (matcher.find()) {
            String s = matcher.group(1);
            set.add(s);
        }

        return set;
    }

    /**
     *  parse topic
     *
     * @param content
     * @return
     * @throws Exception
     */
    public static Set<String> parseTopic(String content) throws Exception {
        Matcher matcher = regexTopic.matcher(content);
        Set<String> set = new HashSet<>();
        while (matcher.find()) {
            String s = matcher.group(1);
            set.add(s);
        }

        return set;
    }



    public static void main(String[] args) throws Exception {
        run();
    }



    /**
     * {
     "uid": "1746409083",
     "date": "20150823",
     "hufutag": "收敛水",
     "gainiantag": "",
     "content": "🐎 //@momo酱也是徐老师:城野医生的毛孔收敛水还有最后9瓶http://t.cn/RLFtgzb",
     "yearmonth": "201508",
     "target": "城野医生",
     "activeness": "2",
     "bi_follow_cnt": "55",
     "city": "1",
     "desc": "人生如戏，全靠演技",
     "fans_cnt": "224",
     "fnames": null,
     "follow_cnt": "100",
     "meta_group": "0$114|时尚$16$0.731|街拍$9$0.577|广州$3$0.553|韩国街拍$2$0.429|旅游$6$0.301|希澈$1$0.231|littlething$1$0.214|星云$1$0.199|美瞳$1$0.166|方大同$1$0.155|hccn$1$0.154|花瓣$1$0.154|公主殿$1$0.154|金希澈$1$0.154|美白$2$0.154|我们$1$0.151|搭配$2$0.148|恋物志$1$0.143|招聘$1$0.141|korea$3$0.137|甜品$1$0.127|美食$12$0.122|吃货$3$0.121|韩国旅游发展局$1$0.118|bigbang$1$0.097|搭配日记$1$0.095|exo$1$0.094|首尔$1$0.090|安米娜$1$0.087|文艺$2$0.086|电影$10$0.078|首站$1$0.077|mafiaqiu$1$0.077|kimheechul$1$0.077|杂志$2$0.073|创意$1$0.071|订阅地址$1$0.071|女性$1$0.071|清新$1$0.071|音乐$7$0.069|2ne1$1$0.068|mali$1$0.059|兼职$1$0.059|dodolook$1$0.057|牛尔$1$0.056|彩妆$5$0.055|设计师$3$0.055|安娜$1$0.052|淘宝$7$0.052|soulboy$1$0.052|midayo$1$0.051|代购$1$0.051|狼宝$1$0.051|流行$1$0.041|naning9$1$0.041|韩国$2$0.041|化妆$3$0.040|优惠$1$0.039|购物$3$0.039|superjunior$1$0.039|mimius$1$0.038|芒果$1$0.038|免税$1$0.036|自由行$1$0.036|酒店$1$0.036|innisfree$1$0.034|笋野$2$0.033|恩彩$1$0.032|支持大同$1$0.031|同盟会$1$0.031|2pm$1$0.029|tomato$1$0.029|晚安冻膜$1$0.028|superman$1$0.028|护肤$5$0.025|原创$2$0.025|香水$2$0.024|美容护肤$3$0.024|vintage$3$0.023|绘本$1$0.022|北京$1$0.021|khalil$1$0.021|nichkhun$1$0.019|top$1$0.019|化妆品$2$0.019|白玉兰$1$0.019|美容$4$0.019|书$1$0.019|淘宝店主$6$0.018|拖$1$0.018|网络$2$0.018|美味$1$0.017|柯基$1$0.017|淘宝掌柜$4$0.016|处女座$3$0.016|網購$1$0.016|明星$1$0.016|偶像$1$0.016|插画$2$0.016|时尚博主$4$0.016|ulzzang$2$0.015|就是这样长大的$1$0.014|听歌$2$0.014|人气博主$1$0.014|韩国服饰$1$0.014|旅行$5$0.013|漫画$3$0.013|餐饮美食$1$0.013|班戟$1$0.013|炖品$1$0.013|布丁$1$0.013|懒$1$0.012|好性格$1$0.012|飞机票$1$0.012|海淘$1$0.012|平常心$1$0.012|飞行$1$0.012|宇宙$1$0.011|宅$5$0.011|餐饮$1$0.011|食评$1$0.011|彩妆达人$2$0.011|隐形眼镜$1$0.011|星座$1$0.011|网络红人推荐$1$0.011|中岛美嘉$1$0.011|服饰$2$0.011|攝影$2$0.011|80后$6$0.011|学生$3$0.011|广州美食$1$0.011|扮靚$1$0.011|保養$1$0.011|重庆$1$0.011|奢侈品$1$0.011|精致$1$0.011|品质生活$1$0.011|优雅$1$0.011|拥抱太阳的月亮$1$0.010|韩国综艺节目$1$0.010|李敏镐$1$0.010|酒窝夫妇$1$0.010|韩剧$1$0.010|张根硕$1$0.010|khalilfans$1$0.010|方大同歌迷會$1$0.010|世界大同$1$0.010",
     "name": "hello同同",
     "tags": null,
     "user_type": "0",
     "verified_reason": null,
     "verified_type": "-1",
     "vtype": "0",
     "wb_cnt": "938"
     }
     *
     * @throws Exception
     */
    public static void run() throws Exception {
        File file = new File("/Users/mou/tempProject/pg/analysis/pg_target.json");
        FileInputStream fis = new FileInputStream(file);

        final Map<String, Integer> count = new HashMap<>();
        count.put("count", 0);

        final Map<String, Integer> for_content = new HashMap<>();
        final Map<String, Integer> for_user = new HashMap<>();
        final Map<String, Integer> for_at = new HashMap<>();
        final Map<String, Integer> for_topic = new HashMap<>();

        final PrintWriter pw = new PrintWriter("/Users/mou/tempProject/pg/analysis/pg_target_res0510.json");

        AdvFile.loadFileInLines(fis, new ILineParser() {
            @Override
            public void parseLine(String s) {

                if (StringUtils.isNullOrEmpty(s)) {
                    return;
                }

                // 获取 INFORMATION
                JSONObject obj = JSONObject.parseObject(s);
                String content = obj.getString("content");
                String vtype = obj.getString("vtype");
                String reason = obj.getString("verified_reason");


                try {

                    // 解析内容分类
                    // 将内容分为一级分类和二级分类
                    if (!StringUtils.isNullOrEmpty(content)) {
                        Set<String> tags1 = mkTag(content);
                        ArrayList<String> firstLi = new ArrayList<String>();
                        ArrayList<String> secondLi = new ArrayList<String>();

                        // add into result
                        for (String s1 : tags1) {

                            String[] tokens = s1.split("#");
                            if (tokens.length == 1) {
                                // 只有一级维度
                                firstLi.add(s1);
                            } else {
                                // 有二级维度
                                firstLi.add(tokens[0]);
                                secondLi.add(s1);
                            }

                            inc(for_content, s1);
                        }
                        obj.put("content_classification1", listUniq(firstLi));
                        obj.put("content_classification2", secondLi);
                    }


                    // 解析用户类别
                    if (!StringUtils.isNullOrEmpty(vtype)) {

                        // 用户标准类型
                        ArrayList<String> li2 = new ArrayList<String>();
                        String cate = mkKolCategories(vtype);
                        li2.add(cate);
                        inc(for_user, cate);

                        // 用户分类
                        if (!StringUtils.isNullOrEmpty(reason)) {
                            Set<String> tags2 = mkKolTag(reason);
                            li2.addAll(tags2);
                            for (String s1 : tags2) {
                                inc(for_user, s1);
                            }
                        }
                        obj.put("user_classification", li2);
                    }


                    // 解析转发、@的人、话题
                    Set<String> mentions = parseMention(content);
                    Set<String> retweetFrom = parseRetweet(content);
                    Set<String> topics = parseTopic(content);

                    List<String> mens = new ArrayList<String>();
                    List<String> rets = new ArrayList<String>();
                    List<String> tops = new ArrayList<String>();
                    List<String> ats = new ArrayList<String>();
                    for (String mention : mentions) {
                        if (kolMap.containsKey(mention)) {
                            mens.add(mention+"#"+kolMap.get(mention));
                            ats.add(mention+"#"+kolMap.get(mention));

                            inc(for_at, "提及#"+mention);
                        }
                    }
                    for (String ret : retweetFrom) {
                        if (kolMap.containsKey(ret)) {
                            rets.add(ret+"#"+kolMap.get(ret));
                            ats.add(ret+"#"+kolMap.get(ret));

                            inc(for_at, "转发#"+ret);
                        }
                    }
                    for (String topic : topics) {
                        tops.add(topic);

                        inc(for_topic, topic);
                    }


                    obj.put("topics", tops);
                    obj.put("at", ats);
                    obj.put("mentions", mens);
                    obj.put("retweetFrom", rets);


                } catch (Exception e) {
                    e.printStackTrace();
                }

                obj.remove("meta_group");

                pw.println(obj.toJSONString());

                int c = count.get("count");
                c++;
                if (c % 50000==0) {
                    System.out.println("current:"+c);
                }
                count.put("count", c);
            }
        });

        pw.flush();
        pw.close();

        System.out.println(count);
        for (Map.Entry<String, Integer> s : for_content.entrySet()) {
            System.out.println(s.getKey()+":"+s.getValue());
        }
        for (Map.Entry<String, Integer> s : for_user.entrySet()) {
            System.out.println(s.getKey()+":"+s.getValue());
        }
        for (Map.Entry<String, Integer> s : for_at.entrySet()) {
            System.out.println(s.getKey()+":"+s.getValue());
        }
        for (Map.Entry<String, Integer> s : for_topic.entrySet()) {
            System.out.println(s.getKey()+":"+s.getValue());
        }
    }



    public static void inc(Map<String, Integer> map, String s) {
        if (!map.containsKey(s)) {
            map.put(s, 0);
        }
        map.put(s, map.get(s)+1);
    }

    public static List<String> listUniq(List<String> li) {
        Set<String> set = new HashSet<>();
        for (String s : li) {
            set.add(s);
        }
        List<String> res = new ArrayList<>();
        for (String s : set) {
            res.add(s);
        }

        return res;
    }

}
