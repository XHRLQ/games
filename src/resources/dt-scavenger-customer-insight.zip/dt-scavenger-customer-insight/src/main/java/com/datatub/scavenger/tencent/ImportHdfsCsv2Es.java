package com.datatub.scavenger.tencent;


import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.util.es.ESWriter;
import com.google.gson.Gson;
import com.yeezhao.commons.mrepo.util.ModelRepository;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.CliRunner;
import com.yeezhao.commons.util.Entity.Params;
import com.yeezhao.commons.util.ILineParser;
import com.yeezhao.hornbill.analyz.nlp.seg.Seg;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.ToAnalysis;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


/**
 * com.datastory.datatools.mouhao.ImportHdfsCsv2Es
 *
 * @author lhfcws
 * @since 2017/3/21
 */
public class ImportHdfsCsv2Es implements CliRunner, Serializable {
    static Logger LOG = Logger.getLogger(ImportHdfsCsv2Es.class);

    static String icon = null;

    public static List<String> wordSeg(String content) {
        if (icon==null) {
            synchronized (ImportHdfsCsv2Es.class) {
                try {
                    InputStream in = ModelRepository.getModelAsInputStream("keywordExtr_corpus.txt");

                    AdvFile.loadFileInLines(in, new ILineParser() {
                        @Override
                        public void parseLine(String s) {
                            Seg.insertUserDefine(s.trim());
                        }
                    });

                    icon = "haha";

                } catch (Exception e) {
                    throw new RuntimeException("asdf");
                }
            }
        }

        List<String> res = new ArrayList();
        for (Term term : ToAnalysis.parse(content).getTerms()) {
            res.add(term.getName());
        }
        return res;
    }

    public static Params processParams(String line) {
        Params p = new Params();

        TencentEntity entity = new Gson().fromJson(line, TencentEntity.class);
        p.put("company", entity.getCompany());
        p.put("dimension1", Arrays.asList(entity.getDimension1().split("\\|")));
        p.put("dimension2", Arrays.asList(entity.getDimension2().split("\\|")));
        p.put("description", Arrays.asList(entity.getDescription().split("\\|")));
        p.put("keywords", Arrays.asList(entity.getKeywords().split("\\|")));
        p.put("events", Arrays.asList(entity.getEvents().split("\\|")));
        p.put("url", entity.getUrl());
        p.put("date", entity.getDate());
        p.put("platform", entity.getPlatform());
        p.put("platformtype", entity.getPlatformtype());
        p.put("snt", entity.getSnt());
        p.put("writer", entity.getWriter());
        p.put("readNum", entity.getReadnum());
        p.put("praisenum", entity.getPraisenum());
        p.put("retweetnum", entity.getRetweetnum());
        p.put("commentnum", entity.getCommentnum());
        p.put("birthdate", entity.getBirthdate());
        p.put("province", entity.getProvince());
        p.put("city", entity.getCity());
        p.put("citylevel", entity.getCitylevel());
        p.put("fanslevel", entity.getFanslevel());
        p.put("attentionnum", entity.getAttentionnum());
        p.put("gender", entity.getGender());

        p.put("favorite", entity.getFavorite());
        p.put("uid", entity.getUid());
        p.put("name", entity.getName());
        p.put("fansnum", entity.getFansnum());
        p.put("device", entity.getDevice());
        p.put("vtype", entity.getVtype());
        p.put("influence", entity.getInfluence());

        p.put("content", entity.getContent());
        p.put("contentseg", wordSeg(entity.getContent()));

        p.put("tag1", entity.tag1);
        p.put("tag2", entity.tag2);
        p.put("tag3", entity.tag3);
        p.put("tag4", entity.tag4);
        p.put("tag5", entity.tag5);
        p.put("tag6", entity.tag6);

//        p.put("id", entity.getId());

        return p;
    }

    public void createSparkJob(String input, final String esIndex) {

        SparkConf sparkConf = new SparkConf()
                .setMaster(new CustomeConfiguration().get("spark.master.url"))
                .setAppName(this.getClass().getSimpleName() + "-" + input)
                .setJars(JavaSparkContext.jarOfClass(this.getClass()))
                .set("spark.akka.timeout", "600")
                .set("spark.driver.memory", "8g")
                .set("spark.executor.memory", "4g")
                .set("spark.cores.max", "50");
        String sparkHome = System.getenv("SPARK_HOME");
        if (sparkHome != null) {
            sparkConf.setSparkHome(sparkHome);
        }

        JavaSparkContext jsc = new JavaSparkContext(sparkConf);
        final Accumulator<Integer> totalAcc = jsc.accumulator(0);
        final Accumulator<Integer> writeAcc = jsc.accumulator(0);
        jsc
                .textFile(input)
                .repartition(100)
                .foreachPartition(new VoidFunction<Iterator<String>>() {
                    @Override
                    public void call(Iterator<String> iter) throws Exception {
                        ESWriter esWriter = ESWriter.getInstance(esIndex, "t");
                        int totalSize = 0;
                        int writeSize = 0;
                        while (iter.hasNext()) {
                            try {
                                totalSize++;
                                String line = iter.next().trim();
                                if (StringUtils.isEmpty(line))
                                    continue;
                                Params p = processParams(line);
                                writeSize++;
                                esWriter.write(p);
                            } catch (Exception e) {
                                LOG.error(e.getMessage(), e);
                            }
                        }

                        esWriter.flush();

                        totalAcc.add(totalSize);
                        writeAcc.add(writeSize);
                    }
                })
        ;

        System.out.println("");
        System.out.println("[TOTAL] " + totalAcc.value());
        System.out.println("[WRITE] " + writeAcc.value());

        jsc.stop();
        jsc.close();
    }

    public static void fuckLocal() throws Exception {
        ESWriter esWriter = ESWriter.getInstance("ds-tencent-mouhao-20170613", "t");

        Params p = processParams("{\"dimension1\":\"\",\"dimension2\":\"\",\"description\":\"\",\"events\":\"\",\"keywords\":\"\",\"url\":\"http://mp.weixin.qq.com/s?__biz\\u003dMzIwNTAzNzMzNg\\u003d\\u003d\\u0026mid\\u003d2650224622\\u0026idx\\u003d1\\u0026sn\\u003d1b4b7d8a260f869c7ec2701f04fa2976\\u0026chksm\\u003d8f349d99b843148f1366063663a0ab2eba7f02e8925f93652d4038264b3bfed08e11a8ae1c5a\",\"date\":\"20170224\",\"platform\":\"微信\",\"platformtype\":\"微信\",\"snt\":\"0.0\",\"mid\":\"\",\"writer\":\"PandaGuidesOfficial\",\"ismainpost\":\"\",\"title\":\"\",\"readnum\":7675,\"praisenum\":22,\"retweetnum\":0,\"commentnum\":0,\"attentionnum\":0,\"fansnum\":0,\"influence\":0.0,\"company\":\"阿里\",\"birthdate\":\"\",\"province\":\"\",\"city\":\"\",\"citylevel\":\"\",\"fanslevel\":\"\",\"gender\":\"\",\"favorite\":\"\",\"uid\":\"\",\"name\":\"Jude\",\"device\":\"\",\"vtype\":\"\",\"content\":\"5languagesthatthemostsuccessfulspeak(otherthanEnglish)\",\"tag1\":0,\"tag2\":0,\"tag3\":0,\"tag4\":0,\"tag5\":0,\"tag6\":0,\"id\":\"\"}");

        esWriter.write(p);
        esWriter.flush();
    }

    public static void main(String[] args) throws Exception {
        AdvCli.initRunner(args, "ImportHdfsCsv2Es", new ImportHdfsCsv2Es());
//        fuckLocal();
    }

    @Override
    public Options initOptions() {
        Options options = new Options();
        options.addOption("input", true, "hdfs input path, can be a directory");
        options.addOption("index", true, "es index name");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmd) {
        return cmd.hasOption("input") && cmd.hasOption("index");
    }

    @Override
    public void start(CommandLine cmd) {
        createSparkJob(cmd.getOptionValue("input"), cmd.getOptionValue("index"));
    }
}
