package com.datatub.scavenger.cli;

import com.datatub.scavenger.classifier.StarcomSntmntClassifier;
import com.datatub.scavenger.util.SparkUtil;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

import java.io.Serializable;

/**
 * Created by mou on 2017/6/15.
 */
public class StarcomCli implements CliRunner, Serializable {

    @Override
    public boolean validateOptions(CommandLine cmd) {
        return cmd.hasOption("input") && cmd.hasOption("output");
    }

    @Override
    public void start(CommandLine cmd) {
        createSparkJob(cmd.getOptionValue("input"), cmd.getOptionValue("output"));
    }


    public static void createSparkJob(String input, String output) {
        JavaSparkContext jsc = SparkUtil.createSparkContext("50");

        jsc
                .textFile(input)
                .map(new Function<String, String>() {
                    @Override
                    public String call(String v1) throws Exception {
                        // v1.split
                        return analysis(v1);
                    }
                })
                .saveAsTextFile(output);

        jsc.stop();
    }

    public static String analysis(String text) {

        try {
            String[] t = text.split("\\t");
            String content = t[21];
            String res = StarcomSntmntClassifier.getInstance().classify(content);

            text = text + "\t" + res;

            return text;
        } catch (Exception e) {
            return text + "\t0";
        }

    }

    public static void main(String[] args) {
//        String res = analysis("中国好声音第四季\t中国好声音\t新浪微博\tWEIBO_38546550524111281163678068\t3509351151\t潘圣琳晖\t普通用户\t女\t\t四川\t成都\t二线城市\t689.0\t500-999\t1114.0\t343.0\t2078.0\t2015/06/17 09:34:03\thttp://weibo.com/3509351151/CmVPja7fa\tWEIBO_3854655052411128\t\t【褚乔最新798现场再唱与吴莫愁pk神曲《cometogether》】信誓旦旦的他还在微博留言：“中国好声音没赢过你，但我又比[鄙视]你音乐大棚更拉风的神奇。来吧来吧”。\t0\t原创\t1.0\t\t7.0\t0.0\t0.0\t\t7\t微博 weibo.com\t\t\t\t\t");
//        System.out.println(res);
        AdvCli.initRunner(args, "ImportHdfsCsv2Es", new StarcomCli());
    }


    @Override
    public Options initOptions() {
        Options options = new Options();
        options.addOption("input", true, "hdfs input path, can be a directory");
        options.addOption("output", true, "es index name");
        return options;
    }


}
