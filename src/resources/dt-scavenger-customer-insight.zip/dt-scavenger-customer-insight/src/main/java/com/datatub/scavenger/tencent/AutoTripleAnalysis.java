package com.datatub.scavenger.tencent;

import com.datatub.hornbill.triple.base.TripleResult;
import com.datatub.hornbill.triple.client.TripleAutoExtractorClient;
import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mou on 2017/8/16.
 */
public class AutoTripleAnalysis implements CliRunner, Serializable {
    @Override
    public Options initOptions() {
        return new Options();
    }

    @Override
    public boolean validateOptions(CommandLine commandLine) {
        return true;
    }

    @Override
    public void start(CommandLine commandLine) {
        try {
            run1();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void run() {
        JavaSparkContext jsc = SparkUtil.createSparkContext("20");

        String input = "/tmp/tencent/result/middle/0801";
        String outuot = "/tmp/tencent/result/triplekey";
        jsc
                .textFile(input)
                .map(new Function<String, TencentEntity>() {
                    @Override
                    public TencentEntity call(String s) throws Exception {
                        return new Gson().fromJson(s, TencentEntity.class);
                    }
                })
                .map(new Function<TencentEntity, String>() {
                    @Override
                    public String call(TencentEntity entity) throws Exception {
                        return entity.content;
                    }
                })
                .flatMap(new FlatMapFunction<String, TripleResult>() {
                    @Override
                    public Iterable<TripleResult> call(String s) throws Exception {
                        List<TripleResult> a = new ArrayList<TripleResult>();
                        try {
                            a = TripleAutoExtractorClient.extract(s);
                        } catch (Exception e) {

                        }
                        return a;
                    }
                })
                .mapToPair(new PairFunction<TripleResult, String, Integer>() {
                    @Override
                    public Tuple2<String, Integer> call(TripleResult tripleResult) throws Exception {
                        String key = tripleResult.getFeature()+"#"+tripleResult.getSentiment()+"#"+tripleResult.getPolarity();
                        return new Tuple2<String, Integer>(key, 1);
                    }
                })
                .reduceByKey(new Function2<Integer, Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer, Integer integer2) throws Exception {
                        return integer+integer2;
                    }
                })
                .map(new Function<Tuple2<String,Integer>, String>() {
                    @Override
                    public String call(Tuple2<String, Integer> stringIntegerTuple2) throws Exception {
                        return stringIntegerTuple2._1+"\t"+stringIntegerTuple2._2;
                    }
                })
                .saveAsObjectFile(outuot);

        jsc.stop();
    }

    public static void run1() {
        JavaSparkContext jsc = SparkUtil.createSparkContext("20");
        JavaRDD<Object> data = jsc.objectFile("/tmp/tencent/result/triplekey");
        data.saveAsTextFile("/tmp/tencent/result/triplekey1");
    }

    public static void main(String[] args) throws Exception {
        AdvCli.initRunner(args, "customer insight data prepare", new AutoTripleAnalysis());
    }
}
