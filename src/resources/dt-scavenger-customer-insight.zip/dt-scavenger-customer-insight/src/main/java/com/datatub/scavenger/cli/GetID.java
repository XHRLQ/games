package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.Tag;
import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by mou on 2017/3/3.
 */
public class GetID implements CliRunner, Serializable {

    private static final String PARAM_IMPORT_CORE = "cores";

    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {
        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "P&G tagging process");

        JavaRDD<String> res = jsc.textFile("/tmp/mouhao/PGtag").map(new Function<String, String>() {

            @Override
            public String call(String v1) throws Exception {
                Gson gson = new Gson();
                Tag tag = gson.fromJson(v1, Tag.class);
                return tag.getUid();
            }
        }).repartition(20).distinct();

        res.saveAsTextFile("/tmp/mouhao/PGuid-tmp1");

        jsc.stop();

//        List<String> tmp = res.collect();
//        jsc.stop();
//
//        try {
//            PrintWriter pw = new PrintWriter("result.txt");
//
//            for (String s : tmp) {
//                pw.println(s);
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//
//        res.cache();
//        long count = res.count();
//        System.out.println(count);
//
//        res.saveAsTextFile("/tmp/mouhao/PGuid-tmp");
//        System.out.println("write success!");

        System.out.println("success!");
    }

    public static void main(String[] args) throws IOException {
        AdvCli.initRunner(args, "customer insight data prepare", new GetID());
    }

}
