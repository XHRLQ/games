package com.datatub.scavenger.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by mou on 2017/2/28.
 */
public class WeiboHbaseUtil {

    private static final long MAX_TIME = 1000 * 365 * 24 * 60 * 60L;

    public static String parseTime(String hbaseTime) {
        long createAt = (MAX_TIME - Long.parseLong(hbaseTime)) * 1000;
        Date time = new Date(createAt);
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String res = format.format(time);
        return res;
    }

    public static void main(String[] args) {
        System.out.println(parseTime("30114289398"));

    }
}
