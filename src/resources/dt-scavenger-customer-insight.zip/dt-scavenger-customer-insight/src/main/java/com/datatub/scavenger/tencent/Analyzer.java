package com.datatub.scavenger.tencent;

import com.datatub.hornbill.triple.base.TripleConsts;
import com.datatub.hornbill.triple.base.TripleResult;
import com.datatub.hornbill.triple.extractor.mgr.TripleManager;
import com.datatub.scavenger.tag.Tagger;
import com.google.gson.Gson;
import com.yeezhao.commons.mrepo.util.ModelRepository;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.Entity.Document;
import com.yeezhao.commons.util.ILineParser;
import com.yeezhao.commons.util.Pair;
import com.yeezhao.hornbill.analyz.algo.sentiment.tweets.MigSntmntClassifier;
import com.yeezhao.hornbill.analyz.algo.sentiment.tweets.TwtSntmntClassifier;
import com.yeezhao.hornbill.analyz.algo.text.ad.tweet.TwtAdClassifier;
import org.apache.commons.lang3.StringUtils;
//import org.junit.Test;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by mou on 2017/3/21.
 */
public class Analyzer {

    public static Pattern pattern1 = Pattern.compile("招聘|招募|职位描述|兼职|全职|社招|急招|联系电话|加下小号|代购|海外购|海淘|总代|代理|团购|预购|现货|包邮|直邮|特价|低价|领劵|原价|开团|店铺名|正品|团价|http:\\/\\/s\\.click\\.taobao\\.com|http:\\/\\/item\\.taobao\\.com|h5\\.m\\.taobao\\.com|咨询电话|转让|支付宝账号:|支付宝号|支付宝：|长按以下二维码|早间分享|运费|邮费|新品上市|新货|现金红包|下单|微信小编|微信同号|微信添加公众号|微信扫码|微信号|微信广告|微信关注|微信公众号|微信：|微商|童叟无欺|特惠|特别声明|抢券|淘宝头条|手机淘宝|私信|扩散周知|加微信|官方微信|关注微信公众号|关注官方微信|返现|发货|二维码|领个券|促销|诚信待人|报酬|￥|股票|概念股|个股|牛股|薪酬|券后|先领后拍|出租|招租|抢购|加V|厂家|热价|面议|简历|来源|转载|投稿|链接|最新自然款|最新消息|现金券|@一淘网|转租|众酬|薇信|授权|自营|征集|无效退款|奖品|今日特饮|热线|等你来抢|有奖转发|预约喝1元星巴克|有奖竞猜|丰厚大奖|0元试用|免费送|中奖|获赠|下载地址|开业送福利|震撼上市|0元抽|中奖名单|做推广|正品低价|抽奖|免费获取|免费领取|买一送一券|重磅推|重磅套餐|开业当天|开业期间|只卖正品|选择原装|\\（来自|分享自|链接：|购买地址|分享给你|\\$|活动立减|发福利|地址|应聘者|免费赠送|订购|体验券|福利来了|欢迎各位|福利|积分5折兑|抽个红包|发红包啦|wei-xin：|欢迎来到|欢迎光临|WeChat：|徽x1n|QQ：|加V找我|转出|转发抽送|货到付款");
    public static Pattern pattern2 = Pattern.compile("春晚|我是红军|深圳卫视跨年2016|痴恋三十天|峨眉传奇|心理罪|孤芳不自赏|蓝色大海的传说|一路繁花相送|诛仙|摔跤吧！爸爸|驴得水|虫鸣漫录|辟邪剑谱|孤芳不自赏|三傻大闹宝莱坞|锦绣未央|真正男子汉|爸爸去哪儿|从你的全世界路过|耳边疯|釜山行|摆渡人|漂亮的李慧珍|奇异博士|28岁未成年|还珠格格|神奇动物在哪里|血战钢锯岭|老九门|赛车总动员|平凡的世界|西游记|青云志|九州天空城|诛仙青云志|W两个世界|东北赌王|如果男人怀孕|心机girl梨妹|识汝不识丁|重生之名流巨星|一起同过窗|极道校园|幻城头条爆料周四见|来！吻我！|青春记忆里的那个她|930我不是潘金莲|我的奇妙男友|东方战场|富贵逼人|上瘾网络剧|十五六岁时交的朋友|等你爱我|青云志连看三天|电视剧幻城|欢乐颂|如果蜗牛有爱情|怒江之战|大嫁风尚|她才是潘金莲|鬼吹灯|麻雀|风铃|老九门|旋风十一人|老板来了|大仙衙门|槑头槑脑|缘来幸福|电视剧六扇门|寂寞空庭春欲晚|我在看重生|六扇门|吉祥天宝|怒江之战野人山|信号signal|昙花梦|老炮儿|天空城|陈二狗的妖孽人生|大熔炉之热血青春|女医明妃传|爱的阶梯|择天记|一觉醒来|南派三叔|任意依恋|五鼠闹东京|幻城|青丘狐传说|不二土夫子0923开盗|Doctors|半妖倾城|wuli少年啊超星星学园特辑|铁蛋勇闯上海滩9\\.21|一人之下|大话青楼|女不强大天不容|有黄景瑜的第一夏|勇者大冒险|0905麻雀一飞冲天|那年青春我们正好|秀丽江山之长歌行|校草的正确打开方式|MBC韩剧W|邻家英雄|心疼张小凡|Rain郑智薰回来吧大叔|好先生|微微一笑很倾城|爱情上上签|蝙蝠侠大战超人|我的吸血鬼男友|打架吧鬼神|最好的我们|隐形的翅膀|电视剧胭脂|一念向北|遇见你之前|青云三萌|幸福又见彩虹|快来吸我|终极一班4|我耳边的糖果|非正常女友|W-两个世界|大熔炉|我是杜拉拉|警花与警犬|吻我加仙气|在世界中心呼唤爱|超少年密码|因为爱情有幸福|三时三餐|惊天大逆转|独立日|旋风少女|山海经之赤影传说|樱空释来了|卜案|北京遇上西雅图|遇见王沥川|电影三人行|电视剧小别离|守望先锋|致敬独自战斗的你|爵迹|重生之名流巨星|心理罪|重生|爱的阶梯|魔怔世界|王者荣耀|狐妖小红娘|英雄联盟|奇迹暖暖|三生三世十里桃花|左眼诡事|电影Real|古剑奇谭|关于汉服的纪录片|小鞋子|爱乐之城|营救飞虎队|长城|一代妖精|月光男孩|不可能完成的任务|三少爷的剑|海边的曼彻斯特|大英雄|三好差生|不得不爱|湄公河行动|追踪|七月与安生|我不是潘金莲|霍去病|魔法一点灵|疯狂动物城|东北往事之破马张飞|铁道飞虎|魔弦传说|武动乾坤|鬼乡|航海王之黄金城|放弃我抓紧我|斗破苍穹|守护丽人|青云大战|女法医手记|大唐荣耀|鹿精灵动画|西游伏妖篇|聊斋|愉此一生|遇见爱情的利先生|北上广依然相信爱情|从前有座灵剑山|乡村爱情|奇星记|乌镇遇见你|维密内衣大秀|小猪佩奇|西游伏妖|爱情珠宝|我不是潘金莲|浙江卫视跨年演唱会|使徒行者|北上广依然相信爱情|寒战|大话西游|最强大脑|新白娘子传奇|美国队长|谎言西西里|那件疯狂的小事叫爱情|乘风破浪|危城|绝地逃亡|台湾电影金马奖|超级王爷|我不是潘金莲|霍去病|老公们的私房钱|铁道飞虎|西游伏妖篇|合伙人|霍比特人|红楼梦");
    public static Pattern pattern3 = Pattern.compile("贾玲|青宇|王青|冯建宇|Rhapsody|朴灿烈|张艺兴|鹿晗|王源|李易峰|Mars毒药|金钟国|李宇春|王嘉尔|陈伟霆|吴磊|金晨|郑恺|宁泽涛|李颖|许魏洲|王源|黄景瑜|白举纲|石小蛮|孙坚|郑恺|伍嘉成|刘涛|钟汉良|田柾国|董明珠|魏晨|易烊千玺|炎亚纶|赵丽颖|彭于晏|余文乐|易峰|吴亦凡|BIGBANG|马天宇|TFBOYS|权志龙|黄景瑜|bigbang|赵丽颖|张根硕|科比|李宇春|胡歌|李钟硕|徐海乔|千玺|王凯|林峯|艺兴|王嘉尔|宋茜|宋仲基|宁泽涛|马可|薛之谦|明道|魏晨|金泰焕|鹿晗|吴海英|林允儿|Winner|凯源|罗晋|Jessica|王源|郑爽|王俊凯|姜昇润|TFBOYS|欧豪|刘诗诗|赵薇|陈伟霆|张杰|Johnny|黄景瑜|林峰|贾青|霍建华|Kobe|杨洋|宋旻浩|SNH48|华晨宇|靳东|乔振宇|董子健|张继科|杨幂|杨紫|陈晓|朴灿烈|G-DRAGON|张若昀|伍嘉成|宋智孝|崔胜铉|Henry|郑秀妍|王青|张一山|迪丽热巴|X-FIRE|黄礼格|于湉|防弹少年团|孙杨|刘宪华|鞠婧祎|袁姗姗|应昊茗|陈赫|吴世勋|陈昱霖|白举纲|郑秀晶|胜利|周杰伦|韩孝周|张睿|吴倩|黄致列|好妹妹|张鲁一|伊嘉凡|沐磊|文晸赫|Eric|金泰亨|黄子韬|蒋劲夫|汪睿|金秀贤|EXO|朴宝剑|周笔畅|关晓彤|孙艺洲|Rain|靳東|唐嫣|井柏然|曾艳芬|snh48|iKON|陈汉典|陈乔恩|RAIN|李晨|肖战|林更新|陈奕迅|张碧晨|金明洙|南柱赫|彭楚粤|王智|林俊杰|陈学冬|韩庚|乔政委|边伯贤|汪东城|黄磊|超女|沈煜伦|于朦胧|徐璐|邓紫棋|蔡照|CAY-Z|张天爱|刘昊然|金秦禹|冯薪朵|安宰贤|金泫雅|张贤胜|刘忻|大张伟|冯绍峰|李准基|吴磊|朴施厚|潘玮柏|俞灏明|张国荣|黄汐源|王金金|都暻秀|张晓钰|袁子仪|赤世代|俞灏明|幺蛾子|张国荣|林志杰|刘亦菲|金雯昕|汪苏泷|侯明昊|王金金|徐良|樊振东|田馥甄|郁可唯|林宥嘉|吴奇隆|苏醒|郁可唯|张国荣|李炜|俞灏明|李治廷|徐良|陈嘉桦|刘诗雯|汪苏泷|李俊昊|谢娜|王菲|姚笛|罗志祥|李小璐|朱婷|贾乃亮|郝景芳|余枫|袁腾飞|许琦|李炜|刘逸云|李光洙|乔任梁|牛鹿|武艺|谷嘉诚|赵磊|蒋梓乐|李宏毅|林子闳|邱泽|李昇勋|范冰冰|景甜|胡冰卿|李艺彤|金希澈|蒋梓乐|黄轩|袁弘|陈键锋|蔡依林|花木兰|海浪|焉栩嘉|周冬雨|李晟|秦俊杰|孙燕姿|李晟|陈震|朱亚文|张馨予|费玉清|河东勋|赵磊|张靓颖|周立波|任贤齐|张译|姚笛|刘恺威|黄伟晋|余枫|詹姆斯骑士|白浅|夜华");
    public static Pattern pattern4 = Pattern.compile("拜拜啦肉肉|耳边疯|舅舅说|王牌对王牌|快乐大本营|国民大生活|放开我北鼻|疯狂天后|Hello女神|网红齐刷爆款神剧|现在转学还来得及|你正常吗|约吧大明星|作战吧偶像|我是你的TFphone|星空演讲|冰火盛典|Happy818GDay|明道呛声A-Lin|最强女团|燃烧吧少年|拜托了冰箱|我们15个这一年|中国偶像|奔跑吧兄弟|超能星学园|最好约的女神都在这里|昔日宿敌首同台|中国新歌声|再不舍也要分别|明星势力榜|因为遇见你|女子为爱换脸|我是你的咩咩phone|我要上热门|拜托了粉丝|明道工作室最强女团|姐姐好饿|撩动你心|兴趣部落|小鲜肉拿走不谢|学妹快跑|菜鸟阎王|网剧女娲成长日记|深井食堂|充电5分钟咩咩2小时|超越不可能|超星星学园|派对之王无码不欢|VIP粉丝季偶像等你撩|不一样的视角|特种兵王|守护添福守护家|SNH48年度总决选|新西游记2|守护家|七只约你看跑男|和添福宝TFBOYS一起闹猴年|国家欠我一个马哥哥|拜托了衣橱|我们战斗吧|ZICO作战吧偶像|史上第一超能力乐队|扑通！扑通！花少年|爸爸去哪儿4|跨界歌王|最高颜值男明星|2016NBA全明星周末|bigbang十周年首尔演唱会|而且你的还带字幕|拜托了冰箱第二季|拜託了冰箱|和TFBOYS一起来上课|柯凡滚出解说界|阿怡代打|NBA总决赛|春晚|一路风景，瑜你同行|三时三餐高敞篇|全景NBA|三好儿童添福宝|饭局的诱惑|大牌蜜聊|小鲜肉出道前都长什么样|跨界喜剧王|电影乒乓小将燃爆奥运季|大事发声|CVIP|冰箱心理学|欧洲杯|二次元奥运会|少年24|吐槽大会|惊喜旅程|大家都爱乡村爱情|大牌驾到|就要玩在一起|找回最初的快感|饭团一周年生日快乐|孜然夫妇欢乐不散场|美颜课堂|花样青春|Bobby爸爸和我|我从新疆来|凤凰天使剧评社|梦想岛|花様年華YoungForever|安徽卫视超级大首映|孩次元大冒险|森林联萌|一条能拉出钻石的狗|iKON盖世英雄|活酵母教父|秀美胸大赛|活酵母女神|基督教主日讲道分享|王宝强离婚|今日看盘|今日贴纸打卡|ONSTYLE微博活动|华谊道歉|爱在涪陵|中国一点都不能少|全职高手|315曝光台|中国四大美男|iChuk|中国四大美女|里约|梦想再大也要回家|世界辣么大|娱乐圈四大女神评选|晒最爱的一张偶像照|美妆试用|北京实习信息|活肤酵母|资本控制舆论|nubia无边框Z11|华谊兄弟过河拆桥|充电5分钟元气2小时|和颐酒店女生遇袭|制片人被女演员潜？|魏则西百度推广事件|TST活酵母|努比亚黑金传奇|600多亿捐款去哪儿了|晒偶像大比拼|iPhone7第一人|看你往哪跑|微能力者|奇葩诡探|哎哟辣么美|恶魔少爷别吻我|天籁之战|金立M2017|见字如面|爱情保卫战|地球脉动|不服来战|我是创始人|天天快报|无限挑战|我们结婚了|养生堂|欢乐集结号|歌手2017|鲁豫有约|喜剧总动员|如果爱|欢乐中国人|天籁之战");
    public static Pattern pattern5 = Pattern.compile("@腾讯净莲|@腾讯不信青史尽成灰3|@李成腾讯|@腾讯的飘飘河边柳|@腾讯不信青史尽成灰|@腾讯廉政公暑|@腾讯的大头007|@腾讯周金和|@腾讯微博年费会员|@腾讯吴冰|@还是腾讯仇术新|@腾讯鹿晗部落|@腾讯那时代丶宋立忠小小号|@腾讯微博的王嘉|@腾讯神话饭团|@腾讯视频TFBOYS饭团|@腾讯---盼天明|@腾讯honey|@腾讯朴海镇部落|@林子闳腾讯部落|@华晨宇腾讯部落|@华晨宇腾讯饭团|@腾讯-寒心蒲公英|@ParkBomTribe腾讯朴春部落|@头条新闻哥-腾讯|@腾讯双溪2|@腾讯视频王俊凯饭团|@腾讯视频陈晓饭团|@张哲瀚腾讯部落|@腾讯游戏推广|@腾讯张杰部落|@腾讯新闻中心_|@TaylorSwift腾讯微博|@腾讯EXO部落|@双溪腾讯3|@唐青腾讯|@池昌旭腾讯兴趣部落官博|@腾讯张艺兴部落|@垃圾腾讯早日倒闭|@腾讯微博匿名用户|@李晟腾讯部落|@腾讯小舞|@腾讯朴灿烈部落|@陈翔吧腾讯网宣|@腾讯--杜全才|阿里拳王|拳王阿里|@阿里海牙科维奇|@蹦蹦跳跳阿里阿|@阿里阿姨|@阿里兰牛肉面|@ram阿里|@阿里_32680|@阿里丰丰|@阿里丁丁与四十节操|@阿里阿姨|@阿里马马掌门人|@阿里_哩黎里丽|@阿里个米|@阿里众包|@Almas-阿里|阿里河|@阿里波硕的BANANA辉|@阿里路亚哇咿呀|阿里郎家园|2017NBA全明星投票|阿里扎|阿里小喵喵的红包|阿西里西|阿里搭|阿里路亚|阿里郎|哈曼阿里尔镇|阿里音乐排行榜|@腾讯Angela|@栀子花开腾讯莫名被封|（腾讯财经）|#NFL比赛日# |#历史上的今天#|阿里札|巴利阿里群岛|#微博橱窗#|@乌卡卡阿里波特小人书|@腾讯自选股");
    public static Pattern pattern6 = Pattern.compile("全球歌迷|全球后援|全球粉丝|全球华人新秀香港区选拔赛|全球华语榜|全球g官方歌迷|全球最大的正版流媒体音乐服务平台|国际影城|全球首唱|后援会|全球应援|专辑全球总销量|全球中文音乐榜|全球最性感");

    private static TwtSntmntClassifier classifier = null;
    private static TwtAdClassifier adClassifier = null;
    private static TripleManager tripleManager = null;
    private static Tagger kwTagger = null;

    public static final String ENTERTAINMENT_DOMAIN = "tencentEntertainment";

    public static Set<String> realWeiboUid = null;

    public static boolean isReal(String uid) {
        if (realWeiboUid == null) {
            synchronized (Analyzer.class) {
                if (realWeiboUid == null) {
                    final Set<String> tmpWeiboUidSet = new HashSet<>();
                    try {
                        AdvFile.loadFileInLines(ModelRepository.getModelAsInputStream("tencent", "tencent_real_uid.txt"), new ILineParser() {
                            @Override
                            public void parseLine(String s) {
                                if (!isNullOrEmpty(s)) {
                                    tmpWeiboUidSet.add(s.trim());
                                }

                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    realWeiboUid = tmpWeiboUidSet;
                }
            }
        }

        return realWeiboUid.contains(uid);
    }


    public static void initTripleManager() {
        if (tripleManager == null) {
            synchronized (Analyzer.class) {
                if (tripleManager == null) {
                    try {
                        tripleManager = new TripleManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new RuntimeException("Triple Initial Error!!");
                    }
                }
            }
        }
    }

    public static void initKwTagger() {
        if (kwTagger == null) {
            synchronized (Analyzer.class) {
                if (kwTagger == null) {
                    try {
                        kwTagger = Tagger.get("tencent_mabiao_0826.txt");
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new RuntimeException("KeywordTagTagger Initial Error!!");
                    }

                }
            }
        }
    }

    public static int mkTriple(String content) {
        initTripleManager();


        Document document = new Document();
        document.putField(Document.Field.Text, content);
        document.setDocumentType(Document.DocumentType.WEIBO);

        HashMap<String, String> addInfo = new HashMap<String, String>();
        addInfo.put(TripleConsts.TWT_SOURCE_PARAM, TripleConsts.WEIBO_SOURCE_PARAM);
        addInfo.put(TripleConsts.TERM_DOMAIN_PARAM, ENTERTAINMENT_DOMAIN);

        List<TripleResult> resultList = null;
        try {
            resultList = tripleManager.extract(document, ENTERTAINMENT_DOMAIN, addInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (TripleResult tripleResult : resultList) {
            String dimension = tripleResult.getDimension();
            switch (dimension) {
                case "腾讯视频":
                    return 1;
                case "节目":
                    return 2;
                case "明星":
                    return 3;
                default:
                    return 0;
            }
        }

        return 0;
    }

    public static TencentEntity mkAnalysisTriple(TencentEntity entity) {
        initTripleManager();

        Document document = new Document();
        document.putField(Document.Field.Text, entity.getContent());

        document.setDocumentType(Document.DocumentType.WEIBO);

        HashMap<String, String> addInfo = new HashMap<String, String>();
        addInfo.put(TripleConsts.TWT_SOURCE_PARAM, TripleConsts.WEIBO_SOURCE_PARAM);
        addInfo.put(TripleConsts.TERM_DOMAIN_PARAM, "tencentAnalysis");

        List<TripleResult> resultList = null;
        try {
            resultList = tripleManager.extract(document, "tencentAnalysis", addInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (TripleResult tripleResult : resultList) {

            if (tripleResult.getProperty().equals("提供高品质的产品")) {
                entity.dimension1 = "产品和技术";
                entity.dimension2 = "提供高品质的产品";
                entity.description = "提供很好的产品";

                entity.neodimension1 = "产品和技术";
                entity.neodimension2 = "提供高品质的产品和服务";
            } else if (tripleResult.getProperty().equals("是一家科技领先的公司")) {
                entity.dimension1 = "产品和技术";
                entity.dimension2 = "是一家科技领先的公司";

                entity.neodimension1 = "产品和技术";
                entity.neodimension2 = "是一家科技领先的公司";
            }
        }
        return entity;
    }

    public static double mksnt(String content) {
        if (classifier == null) {
            synchronized (Analyzer.class) {
                if (classifier == null) {
                    try {
                        TwtSntmntClassifier classifier1 = new TwtSntmntClassifier();
                        classifier = classifier1;
                    } catch (Exception e) {
                        throw new RuntimeException("fuck!");
                    }

                }
            }
        }

        try {
            return classifier.sentiment(content);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public static TwtAdClassifier.WB_TYPE mkAD(String content) {
        if (null == adClassifier) {
            synchronized (Analyzer.class) {
                if (null == adClassifier) {
                    try {
                        adClassifier = new TwtAdClassifier();
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new RuntimeException("广告过滤器初始化失败");
                    }
                }
            }
        }

        return adClassifier.classify(content);
    }

    public static void mkTag(TencentEntity entity, String restext) {

        Tagger tag = null;
        try {
            tag = Tagger.get("mabiao0707.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }

        Pair<HashSet<String>, HashSet<String>> res1 = tag.tag(restext);
        Set<String> a = new HashSet<>();
        Set<String> b = new HashSet<>();
        Set<String> c = new HashSet<>();
        Set<String> d = new HashSet<>();

        if (res1.getFirst().size() == 0) {

        } else {
            for (String s1 : res1.getFirst()) {
                String[] w = s1.split(":");
                a.add(w[0]);
                b.add(w[1]);
                if (w.length > 2) {
                    d.add(w[2]);
                }
            }

            for (String s1 : res1.getSecond()) {
                c.add(s1);
            }

            if (entity.dimension1.length() > 0) {
                a.add(entity.dimension1);
                b.add(entity.dimension2);
            }
            entity.setDimension1(StringUtils.join(a, '|'));
            entity.setDimension2(StringUtils.join(b, '|'));

            entity.setKeywords(StringUtils.join(c, '|'));

            if (entity.description.length() > 0) {
                entity.setDescription(entity.getDescription() + "|" + StringUtils.join(d, "|"));
            } else {
                entity.setDescription(StringUtils.join(d, "|"));
            }

        }
    }

    public static TencentEntity mkTag2(TencentEntity entity) {
        initKwTagger();

        String text = entity.content;

        String textRest = text.replaceAll(reweetS, "").replaceAll(mentionS, "").replaceAll(urlS, "");

//        try {
//            tag = Tagger.get("tencent_mabiao_0826.txt");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        Pair<HashSet<String>, HashSet<String>> res1 = kwTagger.tag(textRest);
        Set<String> a = new HashSet<>();
        Set<String> b = new HashSet<>();
        Set<String> c = new HashSet<>();
        Set<String> d = new HashSet<>();
        Set<String> neo1 = new HashSet<>();
        Set<String> neo2 = new HashSet<>();

        if (res1.getFirst().size() != 0) {
            for (String s1 : res1.getFirst()) {

                String[] pp = s1.split("\\^");

                String[] w = pp[0].split(":");
                a.add(w[0]);
                b.add(w[1]);
                if (w.length > 2) {
                    d.add(w[2]);
                }

                String[] oo = pp[1].split(":");
                neo1.add(oo[0]);
                neo2.add(oo[1]);
            }

            for (String s1 : res1.getSecond()) {
                c.add(s1);
            }

            if (entity.dimension1.length() > 0) {
                a.add(entity.dimension1);
                b.add(entity.dimension2);
            }

            if (entity.description.length() > 0) {
                d.add(entity.description);
            }

            if (entity.neodimension1.length() > 0) {
                neo1.add(entity.neodimension1);
                neo2.add(entity.neodimension2);
            }

            entity.setDimension1(StringUtils.join(a, '|'));
            entity.setDimension2(StringUtils.join(b, '|'));
            entity.setKeywords(StringUtils.join(c, '|'));
            entity.setDescription(StringUtils.join(d, "|"));

            entity.neodimension1 = StringUtils.join(neo1, "|");
            entity.neodimension2 = StringUtils.join(neo2, "|");
        }

        return entity;
    }


    public static boolean isNullOrEmpty(String s) {
        return s == null || s.equals("");
    }

    public static TencentEntity parseEntity(TencentEntity entity) {

        // 如果有title就直接用title，做所有的抽取
        String text = entity.getContent();

        if (isNullOrEmpty(text)) {
            return null;
        }

        // 情感
        double res = 0;
        try {
            res = mksnt(text);
        } catch (Exception e) {
        }

        if (res > -0.1 && res < 0.1) {
            String newsnt = MigSntmntClassifier.getInstance().classify(text);
            if (newsnt.equals("0")) {
                res = 0;
            }
        }

        entity.setSnt(String.valueOf(res));

        String company = getCompany(entity.getContent());

        if (isNullOrEmpty(company)) {
            return null;
        }

        entity.setCompany(company);

        if (entity.getPlatformtype().equals("新闻") ||
                entity.getPlatformtype().equals("论坛") ||
                entity.getPlatformtype().equals("微信")) {
            if (daigouFilter(text)) {
                return null;
            }
        } else {
            if (mkAD(text) != TwtAdClassifier.WB_TYPE.NORMAL || daigouFilter(text)) {
                return null;
            }
        }

        if (entity.getPlatformtype().equals("微博")) {
            String uid = entity.uid;
            if (!isNullOrEmpty(uid)) {
                entity.isreal = isReal(uid) ? "1" : "0";
            } else {
                entity.isreal = "0";
            }
        }

        return entity;
    }


    public static String reweetS = "\\/\\/@[0-9a-zA-Z一-龥_-]{1,28}:";
    public static Pattern reweet = Pattern.compile(reweetS);

    public static final String mentionS = "(@[0-9a-zA-Z一-龥_-]{1,28})+([^:0-9a-zA-Z一-龥_-]|$)";
    public static Pattern mention = Pattern.compile(mentionS);

    // 第二行为第二期添加过滤词
    public static final String exactlymentionS = "(?i)刚刚在Instagram上了(照片|视频)|剛使用Instagram張貼了1段影片|【百度云盘】|『腾讯新闻』|剛使用Instagram張貼了1張相片|剛使用Instagram發佈了1張相片|viaInstagram|viaFacebook|\\?+Instagram|转自Facebook|\\?\\?+Facebook|@土豆订阅我的自频道|JustpostedaphotowithInstagram|Instagram comment update|Just posted a video with Instagram|Vient de publier une photo avec Instagram|Instagram:|#玩图Android版#|#美图秀秀Android版#|#美图GIFAndroid版#|来自谷歌|发Instagram|在Facebook发|_百度知道|_百度文库|_科技_腾讯网|_虎扑网|_腾讯网|_腾讯新闻|Instagram更新|#每日instagram#|百度.{2,6}吧|『QQ音乐』|分享自@虾米音乐|分享自@宝宝知道APP|百度一下 http://|分享自@百度手机浏览器|来自@手机百度|分享自@百度地图|分享自@百度文库|看电影资讯，就来百度百科|_百度百科』|我在看[百度一下]|分享自百度搜索|_百度百科】|_百度百科』|百度@手机QQ浏览器|来自@百度糯米|【百度网盘：|来自@全民K歌| - 百度文库】| - 百度|来自:百度百家|分享自@百度手机浏览器|_百度|我已在百度阅读看完| - 百度文库|分享自 百度HD|百度文库http|分享自@百度手机浏览器 |#全民K歌#|分享自@虾米音乐|来自@QQ音乐|来自Mac版@QQ音乐|来优酷看我更多精彩视频|分享自 @优酷|分享自优酷Android客户端|我在优酷客户端截了一个炫酷的动图|我在看【腾讯新闻】|我在 #腾讯文学# 的作品|腾讯新闻 http|『腾讯新闻』http|更多精彩，尽在优酷视频|我刚刚用#微录客#Android版拍了一段视频|尽在QQ浏览器 http|我正在 @百度视频 看|来自@腾讯新闻客户端 |#QQ看点#|来自@手机百度|来自@腾讯视频| 我参与了@优酷会员 发起的投票| 我参与了@优酷 发起的投票 |来自@腾讯新闻客户端 \u200B|我正在看#|分享自@百度贴吧|[百度网盘资源]|[百度净化]|百度网盘|_百度贴吧|我正在@百度文库 阅读|#高德地图# |#天天快报# |分享 QQ空间|#instagram#| 【Instagram】| via Instagram|Just posted a video with Instagram|#兴趣部落#|百度贴吧-|我在看【腾讯新闻】|我在百度阅读坚持看书|#UC头条#|#QQ阅读#";
    public static Pattern exactlymention = Pattern.compile(exactlymentionS);

    public static final String noiseS = "(?i)wechat：|qq:|tel:|加Q|加好友|加微|有意电联|帮转|求关注|人品爆发|lol...|Lol～|[^a-zA-Z]*lol[^a-zA-Z]|笑到肚痛.*lol|送手机壳|阿里嘎多|CF.*牌子|CF.*火花塞|神厨.*小马哥|马天宇.*好听|@张继科|管鹏.*腾讯科技|lol.*@@尼克杨SwaggyP|小马哥.*@守护者-Ma|小马哥.*@ZhangRong1007|小马哥.*@MARCJACOBS中国|lol.*@Clifford周恩来|lol.*转发|cf.*@破阎阎|小马哥.*@乐天双王派|小马哥.*@花逝千寻chl|小马哥.*@波杰克马男|小马哥.*@Y-ang肥羊|众里寻.*百度|吃.*土豆|土豆.*吃法|土豆.*做法|烤.*土豆|土豆.*辣椒|土豆.*米饭|土豆.*美食|土豆.*泥|土豆.*发芽|土豆.*猪脚饭|土豆.*食欲|土豆.*厨子|土豆.*薯片|土豆.*沙拉|土豆.*米粉|刨.*土豆|土豆.*油炸|土豆.*好吃|土豆.*想吃|@三七SQ_.*土豆|@小智guoguo.*土豆|@关关哟i.*土豆|@三七SQ_.*土豆|@马建勋.*土豆|@何娟和淑芬是我的宠物.*土豆|@只是被风吹了下.*土豆|@海马体照相馆.*土豆|@勤劳的鲁小二.*土豆|.*土豆@allenbao|@DaLaLee.*土豆|@願大胖.*土豆|@心藏-高天宇.*土豆|@大锅只是喝醉.*土豆|@洁姐育儿信箱.*土豆|@我的偶像叫蒙面小王子.*土豆|@珊珊不迟的.*土豆|@宝曦M.*土豆|@Dipsy迪西.*土豆|@爱微拍.*土豆|@吃葡萄不吐葡萄皮的柠檬.*土豆|@来一屉鲜肉小笼.*土豆|@肉华不打诳语.*土豆|@夏至的瞎子.*土豆|@赶尾人.*土豆|@Stab_hi.*土豆|@阿蘇Suyii.*土豆|@志龙爸爸哟.*土豆|@吴小惠_.*土豆|@張信哲JeffChang.*土豆|@yc.*土豆|@追星星的影子.*土豆|@小马达答滴答滴答.*土豆|@林弯路.*土豆|@公子清颜.*土豆|@-闫雪卿.*土豆|@无与伦比的小彬哥.*土豆|@小新_lhb.*土豆|@晏-yan.*土豆|@TTTOP彭彭彭芳.*土豆|@Esu|土豆丝|刷单|wechat:|QQ星|一百度|胡萝卜.{0,8}土豆|切碎的土豆|来个土豆|阿里里|#泰妍instagram#|阿拉阿里|盘子.{0,8}土豆|加我微信|【图片】土豆|美美团|炸土豆|微信:|我分享了|#土豆迷妹李浩菲#|微xin：|古巴阿里|炖土豆|削土豆|旋风土豆|胡萝卜|(买|買)个土豆|(卖|賣)个土豆|孜然土豆|戳这里|选我|徽.信：|二百度|阿里山|马云龙|大土豆|土豆皮|土豆粉|土豆泥|土豆片|小土豆|土豆条|土豆丝|土豆饼|土豆块|土豆粒|土豆花|土豆儿|土豆芽|土豆腐脑|土豆汁|阿里.{0,8}拳王|阿里兰|阿里呀|阿里里|阿里班公湖|西藏阿里地区|阿里汉|阿里汗|阿里斯顿|阿里什|阿里亚娜|阿里郎|阿里山|巴利阿里|阿里亚斯|阿里卡|阿里奥|祖阿里|阿里马|阿里桑那|阿里亞|阿里亚|阿里斯蒂德|阿里地区|阿里安|阿里河|阿里斯|阿里斯托|阿里木|逆战歌手|姜丝.{0,8}土豆|张杰.{0,8}逆战|土豆姐姐|穆罕默德.{0,8}阿里|阿里.{0,8}卡普宫|赚钱.{0,8}方法|土豆.{0,8}焖饭|土豆.{0,8}红薯|土豆.{0,8}玉米|土豆.{0,8}美食|土豆.{0,8}美味|土豆.{0,8}排骨|土豆.{0,8}金针菇|土豆.{0,8}西红柿|土豆.{0,8}青椒|土豆.{0,8}翻炒|土豆.{0,8}洗净|土豆.{0,8}牛肉|土豆.{0,8}炖牛肉|土豆.{0,8}一颗|土豆.{0,8}早餐|土豆.{0,8}切块|土豆.{0,8}切丝|土豆.{0,8}切条|土豆.{0,8}洋葱|土豆.{0,8}番茄|土豆.{0,8}韭菜|土豆.{0,8}牛肉|土豆.{0,8}茄子|土豆.{0,8}豆角|土豆.{0,8}黄瓜|土豆.{0,8}去皮|土豆.{0,8}马铃薯|土豆.{0,8}鸡蛋|土豆.{0,8}地瓜|土豆.{0,8}切片|阿里阿可|酒业.{0,8}英雄联盟|lol.{0,8}@罗套套|笑.{0,8}LOL|LOL.{0,8}目目|LOL.{0,8}IBJNY_G|LOL.{0,8}王武莫虫之|lol.{0,8}可爱|丢脸.{0,8}捡回来.{0,8}lol|LOL.{0,8}微笑|貴圈真亂.{0,8}LOL|crayneton.{0,8}LOL|英语口语精华.{0,8}LOL|喵.{0,8}LOL|电影.{0,8}LOL|偷笑.{0,8}LOL|大声.{0,8}lol|英雄联盟.{0,8}老婆|英雄联盟.{0,8}中牧绿色|代刷|有意者|QQ群号码：|加我QQ|加入QQ群|请备注|找我QQ|加我卫星|QQ私聊|＋QQ|联系方式QQ|QQ联系我|有意联系|微信.{0,8}购买|微信.{0,8}購買|加我微信|求好友|Wechat微信:|微信：|微信.{0,8}询价|微博.{0,8}询价|QQ.{0,8}询价|扣我|Q我|@故宫淘宝|淘宝贝|V信号：|命运.{0,8}逆战|命运逆战.{0,8}吴亦凡|逆战.{0,8}@Mr_凡先生|逆战.{0,8}@张杰|逆战.{0,8}杰哥|逆战.{0,8}唱|逆战.{0,8}狂野|逆战.{0,8}中秋夜|戴尔.{0,8}逆战|哥哥.{0,8}逆战|歌曲.{0,8}逆战|下腰.{0,8}逆战|老张.{0,8}逆战|逆战.{0,8}@老张的小北斗|星空.{0,8}逆战|登场.{0,8}逆战|逆战.{0,8}这就是爱|逆战.{0,8}全场|逆战.{0,8}李健|逆战.{0,8}月亮|逆战.{0,8}星星|逆战.{0,8}回归|请打备注|诚招|妻子脑胶质瘤三年了，开个贴。说说我们冶疗胶质瘤的汗泪历程吧！|-腾讯分享|我就是桥花，桥边的一枝花，你娶我吗？|八卦闲聊，花痴吐槽，推书追剧，开心最好|这会在民政局门口等着离婚";
    public static Pattern noise = Pattern.compile(noiseS);

    public static final String numberS = "^[0-9]{3,20}$";
    public static Pattern number = Pattern.compile(numberS);

    public static final String strS = "^[A-Za-z]{3,20}$";
    public static Pattern strPattern = Pattern.compile(strS);


    public static final String urlS = "http[s]?:\\/\\/([\\w-]+\\.)+[\\w-]+([0-9a-zA-Z-./?%&*=]*)";
    public static Pattern url =
            Pattern.compile(urlS);

    //    public static Pattern urlMentions = Pattern.compile("(?i)qq|lol|cf|dnf");
    // 二期
    public static Pattern urlMentions = Pattern.compile("(?i)qq|lol|cf|dnf|fb|uc");

   // @Test
    public void test() {
        String text = "一个";
        String res2 = StringUtils.join(getMacherList(mention.matcher(text)), '\t');
        TencentEntity entity = new TencentEntity();
        entity.tag2 = getCompany(res2).equals("") ? 0 : 1;
        // 如果去除这些
        String textRest = text.replaceAll(reweetS, "").replaceAll(mentionS, "").replaceAll(urlS, "");
        if (!getCompany(textRest).equals("")) {
            entity.tag1 = 0;
            entity.tag2 = 0;
        }
        // 过滤词
        if (entity.tag2 == 0 && exactlymention.matcher(text).find()) {
            entity.tag2 = 1;
        }
        System.out.println(entity.tag2);
    }

    /**
     * tag1 --> tag6
     *
     * @param entity
     * @return
     * @throws IOException
     */
    public static TencentEntity mkMatchTagTmp(TencentEntity entity) throws IOException {
        String text = entity.getContent();

//        text = "";
        // 解析转发的人 "//@asdfasd "
        // res1 : 截取 "//@**:" 内容
        String res1 = StringUtils.join(getMacherList(reweet.matcher(text)), '\t');
        entity.tag1 = getCompany(res1).equals("") ? 0 : 1;

        // 存粹@了一下
        String res2 = StringUtils.join(getMacherList(mention.matcher(text)), '\t');
        entity.tag2 = getCompany(res2).equals("") ? 0 : 1;

        // 如果去除这些
        String textRest = text.replaceAll(reweetS, "").replaceAll(mentionS, "").replaceAll(urlS, "");
        if (!getCompany(textRest).equals("")) {
            entity.tag1 = 0;
            entity.tag2 = 0;
        }
        // 过滤词
        if (entity.tag2 == 0 && exactlymention.matcher(text).find()) {
            entity.tag2 = 1;
        }

        // 噪音，这里会有一个码表
        entity.tag3 = noise.matcher(text).find() ? 1 : 0;
        // 出现 lol|lol...|Lol~
        if (entity.tag3 == 0) {
            if (text.equals("lol") || text.equals("lol...") || text.equals("Lol~")) {
                entity.tag3 = 1;
            }
        }
        // 微信+数字| 微信+英文
        if (entity.tag3 == 0) {
            if (text.startsWith("微信")) {
                String res3Tmp = StringUtils.join(getMacherList(number.matcher(text.substring(2))), '\t');
                String res4Tmp = StringUtils.join(getMacherList(strPattern.matcher(text.substring(2))), '\t');
                entity.tag3 = "".equals(res3Tmp) && "".equals(res4Tmp) ? 0 : 1;
            }
        }
        // tag3的限定词
        if (entity.tag3 == 0) {
            entity.tag3 = filterTag3(text).equals("") ? 0 : 1;
        }

        // 链接命中
        String res4 = StringUtils.join(getMacherList(url.matcher(text)), '\t');
        entity.tag4 = urlMentions.matcher(res4).find() ? 1 : 0;

        // 命中腾讯
        entity.tag5 = Tagger.get("tencent_activity.txt").tag(textRest).getFirst().size() > 0 ? 1 : 0;

        entity.tag6 = mkTriple(textRest);

        // 三元组维度标签
        mkAnalysisTriple(entity);

        // 码表维度标签
//        mkTag(entity, textRest);
        // todo 时间太慢,取消,单独打
//        mkTag2(entity);

        // 事件
        mkEventTag(entity);

        // 企业对比
        entity.companycompare = getCompanyVs(textRest) ? 1 : 0;

        return entity;
    }

    public static void main(String[] args) {
        try {
            String raw = "{\"tag4\": 0, \"commentnum\": 0, \"tag1\": 0, \"attentionnum\": 0, \"tag3\": 0, \"date\": \"20161108\", \"retweetnum\": 1, \"fansnum\": 0, \"uid\": \"\", \"city\": \"\", \"vtype\": \"\", \"tag2\": 0, \"writer\": \"CAMIA观察\", \"mid\": \"\", \"content\": \"2016年越南电子商务报告：一半网购用户曾进行FB购物\", \"platform\": \"微信\", \"fanslevel\": \"\", \"province\": \"\", \"praisenum\": 3, \"company\": \"fb\", \"snt\": \"1.0\", \"device\": \"\", \"name\": \"CAMIA\", \"url\": \"http://mp.weixin.qq.com/s?__biz=MzAxNDIyNjAyOQ==&mid=2650202160&idx=1&sn=3939fc5b14e96f2aca65051d0ca8c541&chksm=8394c732b4e34e241b58bb4bbf7dbce5568bbd5d4494fd44dc443bf4cf02ee5eb88d32bb750c\", \"gender\": \"\", \"readnum\": 246, \"favorite\": \"\", \"birthdate\": \"\", \"citylevel\": \"\", \"platformtype\": \"微信\"}";

            TencentEntity entity = new Gson().fromJson(raw, TencentEntity.class);

            entity = mkMatchTagTmp(entity);
            System.out.println(entity);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static List<String> getMacherList(Matcher matcher) {
        List<String> rst = new ArrayList<String>();
        while (matcher.find()) {
            rst.add(matcher.group());
        }
        return rst;
    }

    /**
     * 事件分类,事件标签
     * 文件格式  : 事件分类^事件标签\t关键词
     *
     * @param entity
     * @throws IOException
     */
    public static void mkEventTag(TencentEntity entity) throws IOException {
        // make envent tag
        Tagger eventTagger = Tagger.get("event.txt");

        Pair<HashSet<String>, HashSet<String>> result = eventTagger.tag(entity.getContent());

        HashSet<String> tags = result.getFirst();

//        StringBuilder events = new StringBuilder();
//        StringBuilder eventtype = new StringBuilder();

        Set<String> events = new HashSet<>();
        Set<String> eventtype = new HashSet<>();

        for (String tag : tags) {
            String[] res = tag.split("\\^");

            eventtype.add(res[0]);
            events.add(res[1]);
        }

        entity.events = StringUtils.join(events, "|");
        entity.eventtype = StringUtils.join(eventtype, "|");
    }

    public static boolean getCompanyVs(String content) {
        try {
            Tagger tag = Tagger.get("tencent_company.txt");
            Pair<HashSet<String>, HashSet<String>> res = tag.tag(content);
            HashSet<String> companys = res.getFirst();
            if (companys.size() > 1) {
                content = content.toLowerCase();
                if (content.contains("vs") || content.contains("pk") || content.contains("比")) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }


    public static String getCompany(String s) {
        try {
            Tagger tag = Tagger.get("tag1-tag2.txt");
            Pair<HashSet<String>, HashSet<String>> j = tag.tag(s);
            if (j.getFirst().size() > 0) {
                for (String tt : j.getFirst()) {
                    return tt;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }

    public static String filterTag3(String s) {
        try {
            Tagger tag = Tagger.get("tag3_filter.txt");
            Pair<HashSet<String>, HashSet<String>> j = tag.tag(s);
            if (j.getFirst().size() > 0) {
                for (String tt : j.getFirst()) {
                    return tt;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }

    public static boolean filter(String s) {
        Matcher m1 = pattern1.matcher(s);
        Matcher m2 = pattern2.matcher(s);

        return m1.find() || m2.find();
    }


    public static boolean daigouFilter(String content) {
        return com.mysql.jdbc.StringUtils.isNullOrEmpty(content) || pattern1.matcher(content).find() ? true : false;
    }
}
