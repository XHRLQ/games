package com.datatub.scavenger.classifier;
import com.yeezhao.hornbill.analyz.common.util.Trie;
import scala.Char;

import java.util.*;


/**
 * com.datastory.banyan.tools.WordMatch
 *
 * @author lhfcws
 * @since 2017/3/1
 */
public class WordMatch {

    private static WordMatch wordMath;
    private Map<Character, WordMap> keywords;

    public static WordMatch getInstance(List<String> keywords) {
        if (null == wordMath) {
            synchronized (WordMatch.class) {
                if (null == wordMath) {
                    wordMath = new WordMatch(keywords);
                }
            }
        }
        return wordMath;
    }

    private WordMatch(List<String> keywords) {
        this.keywords = new HashMap<>();

        for (String keyword : keywords) {
            keyword = keyword.toLowerCase();
            int len = keyword.length();
            if (len > 0) {
                Character key = keyword.toCharArray()[0];
                if (this.keywords.containsKey(key)) {
                    WordMap wordMap = this.keywords.get(key);
                    if (!wordMap.containsKey(len))
                        wordMap.put(len, new ArrayList<String>());
                    wordMap.get(len).add(keyword);
                } else {
                    WordMap wordMap = new WordMap();
                    List<String> tmp = new ArrayList<>();
                    tmp.add(keyword);
                    wordMap.put(len, tmp);
                    this.keywords.put(key, wordMap);
                }
            }
        }
    }

    public List<String> getMatchedWords(String str) {
        char[] chars = str.toCharArray();
        List<String> res = new ArrayList();
        for (int i = 0; i < chars.length; i++) {
            Character key = chars[i];
            if (this.keywords.containsKey(key)) {
                WordMap wordMap = this.keywords.get(key);
                for (Map.Entry<Integer, List<String>> e : wordMap.entrySet()) {
                    String now = str.substring(i, i + e.getKey());
                    for (String w : e.getValue()) {
                        if (now.equals(w)) {
                            res.add(w);
                        }
                    }
                }
            }
        }
        return res;
    }


    private class WordMap extends HashMap<Integer, List<String>> {
    }

    /****************************
     * Test main
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        List<String> keywords = Arrays.asList(
                "天地", "玄黄", "宇宙", "洪荒", "千字文", "洪荒出"
        );
        WordMatch wm = WordMatch.getInstance(keywords);
        List<String> list = wm.getMatchedWords("天地不仁，以万物为刍狗。宇宙洪荒出自千字文");
        System.out.println(list);
    }
}
