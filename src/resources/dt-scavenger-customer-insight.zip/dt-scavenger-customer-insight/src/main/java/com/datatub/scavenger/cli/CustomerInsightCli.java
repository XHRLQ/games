//package com.datatub.scavenger.cli;
//
//import com.datatub.scavenger.util.KeyWordLoader;
//import com.datatub.scavenger.util.SparkUtil;
//import com.yeezhao.commons.util.AdvCli;
//import com.yeezhao.commons.util.CliRunner;
//import org.apache.commons.cli.CommandLine;
//import org.apache.commons.cli.Options;
//import org.apache.spark.api.java.JavaSparkContext;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Created by mou on 2016/10/26.
// */
//public class CustomerInsightCli implements CliRunner {
//    private static final String PARAM_IMPORT_CORE = "cores";
//    private static final String PARAM_KEYWORD_FILE = "keyword";
//    private static final String PARAM_FILTER_FILE = "filter";
//    private static final String PARAM_KOL_FILE = "kol";
//    private static final String PARAM_PROJECT_NAME = "project";
//    private static final String PARAM_IS_HBASE = "isHBase";
//
//    @Override
//    public Options initOptions() {
//        Options options = new Options();
//
//        options.addOption(PARAM_IMPORT_CORE, true, "核数");
//        options.addOption(PARAM_KEYWORD_FILE, true, "关键词列表");
//        options.addOption(PARAM_FILTER_FILE, true, "过滤词列表");
//        options.addOption(PARAM_KOL_FILE, true, "KOL列表");
//        options.addOption(PARAM_PROJECT_NAME, true, "TAG 名称");
//        options.addOption(PARAM_IS_HBASE, true, "是否从HBase读取数据");
//        return options;
//    }
//
//    @Override
//    public boolean validateOptions(CommandLine cmdLine) {
//        return cmdLine.hasOption(PARAM_IMPORT_CORE) &&
//                cmdLine.hasOption(PARAM_KEYWORD_FILE) &&
//                cmdLine.hasOption(PARAM_FILTER_FILE) &&
//                cmdLine.hasOption(PARAM_KOL_FILE) &&
//                cmdLine.hasOption(PARAM_PROJECT_NAME);
//    }
//
//    @Override
//    public void start(CommandLine cmdLine) {
//        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);
//        String keywordPath = cmdLine.getOptionValue(PARAM_KEYWORD_FILE);
//        String filterPath = cmdLine.getOptionValue(PARAM_FILTER_FILE);
//        String kolPath = cmdLine.getOptionValue(PARAM_KOL_FILE);
//        String projectName = cmdLine.getOptionValue(PARAM_PROJECT_NAME);
//
//        boolean isHBase = false;
//        if (cmdLine.hasOption(PARAM_IS_HBASE)) {
//            if (cmdLine.getOptionValue(PARAM_IS_HBASE).equals("1")) {
//                isHBase = true;
//            }
//        }
//
//        List<String> keyWords;
//        List<String> filterWords;
//        List<String> kols;
//
//        try {
//            keyWords = KeyWordLoader.getFile(keywordPath);
//            if (filterPath.equals("null")) {
//                filterWords = new ArrayList<>();
//            } else {
//                filterWords = KeyWordLoader.getFile(filterPath);
//            }
//            kols = KeyWordLoader.getFile(kolPath);
//
//        } catch (IOException e) {
//            throw new RuntimeException("", e);
//        }
//
//        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "消费者洞察-"+projectName);
//
//        InsightRunner.run(jsc, keyWords, filterWords, kols, projectName, isHBase);
//    }
//
//    public static void main(String[] args) {
//        AdvCli.initRunner(args, "customer insight", new CustomerInsightCli());
//    }
//}
