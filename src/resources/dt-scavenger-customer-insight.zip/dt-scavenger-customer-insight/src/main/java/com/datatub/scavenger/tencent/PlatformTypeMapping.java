package com.datatub.scavenger.tencent;

import com.datatub.scavenger.base.CustomeConfiguration;
import com.yeezhao.commons.util.AdvFile;

import com.yeezhao.commons.util.ILineParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by mou on 2017/3/21.
 */
public class PlatformTypeMapping {

    private static Map<String, String> map = null;
    private static Map<String, String> map1 = new HashMap<>();

    private synchronized static void load() throws IOException {

        InputStream in = CustomeConfiguration.getInstance().getConfResourceAsInputStream("platformtype_mapping.txt");


        AdvFile.loadFileInLines(in, new ILineParser() {
            @Override
            public void parseLine(String s) {
                s = s.toLowerCase();
                String[] arr = s.split("\t");
                String site = arr[0];
                String platform = arr[1];
                map1.put(site, platform);
            }
        });

        map = map1;

    }

    public static String getMap(String string) {
        if (map==null) {
            try {
                load();
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("mapping wrong");
            }
        }

        if (map.containsKey(string)) {
            return map.get(string);
        } else {
            return "新闻";
        }
    }

    public static void main(String[] args) {
        System.out.println(getMap("游侠网"));
    }
}
