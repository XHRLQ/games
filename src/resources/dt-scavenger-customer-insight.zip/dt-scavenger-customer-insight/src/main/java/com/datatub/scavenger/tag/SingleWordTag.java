package com.datatub.scavenger.tag;

import java.io.Serializable;

/**
 * com.datastory.banyan.tools.SingleWordTag
 *
 * @author lhfcws
 * @since 2017/3/3
 */
public class SingleWordTag implements Serializable {
    private String word;
    private String tag;

    public SingleWordTag(String word, String tag) {
        this.word = word;
        this.tag = tag;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    @Override
    public String toString() {
        return "SingleWordTag{" +
                "word='" + word + '\'' +
                ", tag='" + tag + '\'' +
                '}';
    }
}
