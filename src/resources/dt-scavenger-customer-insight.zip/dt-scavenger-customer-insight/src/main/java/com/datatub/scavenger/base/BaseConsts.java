package com.datatub.scavenger.base;

import com.yeezhao.commons.hbase.HBaseUtil;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.util.Pair;

import java.util.List;

/**
 * Created by mou on 2016/10/26.
 */
public class BaseConsts {

    public static final String WEIBO_HDFS_PATH = "/tmp/mouhao/PGWeibo";
    public static final String WEIBO_USER_HDFS_PATH = "/tmp/mouhao/weiboUser";



    public static final String COL_FP_CONTENT = "crawl:fp_content";
    public static final String COL_FP_FEATURE = "crawl:fp_feature";
    public static final String COL_FP_WEIBO_SOURCE = "crawl:fp_weibo_source";
    public static final String COL_FP_COMMENT = "crawl:fp_cm_total";
    public static final String COL_FP_REPOST = "crawl:fp_rp_total";

    public static enum USER_TYPE {
        UNK(-1),
        NORMAL(0),
        ORG(1),
        ROBOT(2);

        private final int code;

        private USER_TYPE(int v) {
            this.code = v;
        }

        public int getCode() {
            return this.code;
        }

        public static USER_TYPE fromType(int type) {
            return type == UNK.getCode()?UNK:(type == NORMAL.getCode()?NORMAL:(type == ORG.getCode()?ORG:(type == ROBOT.getCode()?ROBOT:NORMAL)));
        }
    }

    public static final List<Pair<byte[], byte[]>> UINFO_USR_FMLYCOLS = HBaseUtil.getColsInBytes(new String[]{
            COL_FP_CONTENT,
            COL_FP_FEATURE,
            COL_FP_WEIBO_SOURCE,
            COL_FP_COMMENT,
            COL_FP_REPOST
    });

    // hbase column
    public static final String HBASE_TABLE = "yeezhao.user.info";

    public static final byte[] FMLY_CARWL = Bytes.toBytes("crawl");
    public static final byte[] FMLY_ANALYZ = Bytes.toBytes("analyz");
    public static final byte[] FMLY_FOLLOW = Bytes.toBytes("follow");
    public static final byte[] QUA_HASFOLLOW = Bytes.toBytes("has_follow");
    public static final byte[] QUA_VERIFIEDTYPE = Bytes.toBytes("verified_type");
    public static final byte[] QUA_GENDER = Bytes.toBytes("gender");
    public static final byte[] QUA_LOCATION = Bytes.toBytes("location_format");
    public static final byte[] QUA_AGE = Bytes.toBytes("age");
    public static final byte[] QUA_GROUP = Bytes.toBytes("group_name");
    public static final byte[] QUA_FOLLOWNUM = Bytes.toBytes("followers_count");
    public static final byte[] QUA_NICKNAME = Bytes.toBytes("nickname");
    public static final byte[] QUA_USERTYPE = Bytes.toBytes("user_type");
    public static final byte[] QUA_FETCH = Bytes.toBytes("status_fetch");
    public static final byte[] QUA_METAGROUP = Bytes.toBytes("meta_group");
    public static final byte[] QUA_TAGDIST = Bytes.toBytes("tag_dist");
    public static final byte[] QUA_SOURCE = Bytes.toBytes("source");
    public static final byte[] QUA_ACTIVENESS = Bytes.toBytes("activeness");

    //hbase tag
    public static final String HBASE_TEST_TABLE = "yeezhao.user.tag.test";

    public static final byte[] FMLY_TAG = Bytes.toBytes("tag");
    public static final byte[] FMLY_TEST = Bytes.toBytes("test");
    public static final byte[] QUA_CHILD = Bytes.toBytes("child");
    public static final byte[] QUA_MAMA = Bytes.toBytes("mama");
    public static final byte[] QUA_MARRIAGE = Bytes.toBytes("marriage");
    public static final byte[] QUA_PET = Bytes.toBytes("pet");
}
