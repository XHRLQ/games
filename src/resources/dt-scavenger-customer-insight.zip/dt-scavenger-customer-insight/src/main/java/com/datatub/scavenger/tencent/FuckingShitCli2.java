package com.datatub.scavenger.tencent;

import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mou on 2017/8/1.
 */
public class FuckingShitCli2 implements CliRunner, Serializable {



    @Override
    public Options initOptions() {
        Options options = new Options();
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return true;
    }

    @Override
    public void start(CommandLine cmdLine) {
        mkSecicalTag();
    }

    public static void mkSecicalTag() {

        JavaSparkContext jsc = SparkUtil.createSparkContext("50", "tencent_public_opinion");

        JavaRDD<String> data = jsc.textFile("/tmp/tencent/result/middle/0717_usertype");

        data
                .map(new Function<String, TencentEntity>() {
                    @Override
                    public TencentEntity call(String s) throws Exception {
                        return new Gson().fromJson(s, TencentEntity.class);
                    }
                })
                .map(new Function<TencentEntity, TencentEntity>() {
                    @Override
                    public TencentEntity call(TencentEntity entity) throws Exception {
                        return mkIncAnalysis(entity);
                    }
                })
                .map(new Function<TencentEntity, String>() {
                    @Override
                    public String call(TencentEntity entity) throws Exception {
                        return new Gson().toJson(entity);
                    }
                })
                .saveAsTextFile("/tmp/tencent/result/middle/0801");



    }

    public static TencentEntity mkIncAnalysis(TencentEntity entity) {

        // clean all the dimension
        entity.dimension1 = "";
        entity.dimension2 = "";
        entity.description = "";
        entity.keywords = "";

        // make triple analysis
        entity = Analyzer.mkAnalysisTriple(entity);

        // make tag analysis
        entity = Analyzer.mkTag2(entity);


        return entity;
    }


    public static void main(String[] args) throws Exception {
        AdvCli.initRunner(args, "customer insight data prepare", new FuckingShitCli2());


//        String raw = "{\"tag4\": 0, \"commentnum\": 0, \"tag1\": 0, \"attentionnum\": 0, \"tag3\": 0, \"date\": \"20161108\", \"retweetnum\": 1, \"fansnum\": 0, \"uid\": \"\", \"city\": \"\", \"vtype\": \"\", \"tag2\": 0, \"writer\": \"CAMIA观察\", \"mid\": \"\", \"content\": \"产品好。2016年越南电子商务报告：一半网购用户曾进行FB购物,腾讯发展\", \"platform\": \"微信\", \"fanslevel\": \"\", \"province\": \"\", \"praisenum\": 3, \"company\": \"fb\", \"snt\": \"1.0\", \"device\": \"\", \"name\": \"CAMIA\", \"url\": \"http://mp.weixin.qq.com/s?__biz=MzAxNDIyNjAyOQ==&mid=2650202160&idx=1&sn=3939fc5b14e96f2aca65051d0ca8c541&chksm=8394c732b4e34e241b58bb4bbf7dbce5568bbd5d4494fd44dc443bf4cf02ee5eb88d32bb750c\", \"gender\": \"\", \"readnum\": 246, \"favorite\": \"\", \"birthdate\": \"\", \"citylevel\": \"\", \"platformtype\": \"微信\"}";
//
//        TencentEntity entity = mkIncAnalysis(new Gson().fromJson(raw, TencentEntity.class));
//        System.out.println(entity);
    }
}
