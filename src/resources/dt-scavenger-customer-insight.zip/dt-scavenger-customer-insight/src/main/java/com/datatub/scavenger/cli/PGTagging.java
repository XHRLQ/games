package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.Tag;
import com.datatub.scavenger.tag.Tagger;
import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by mou on 2017/3/3.
 */
public class PGTagging implements CliRunner, Serializable {

    private static final String PARAM_IMPORT_CORE = "cores";

    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {
        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "P&G tagging process");

        JavaRDD<String> data = jsc.textFile("/tmp/mouhao/PGWeibo");

        JavaRDD<String> parsed = data.flatMap(new FlatMapFunction<String, String>() {

            @Override
            public Iterable<String> call(String s) throws Exception {
                List<String> res = new ArrayList<String>();

                try {
                    Tag tag = mkTag(s);
                    if (tag.getHufutag().size() > 0) {
                        String t = new Gson().toJson(tag);
                        res.add(t);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return res;
            }
        });

        parsed.saveAsTextFile("/tmp/mouhao/PGtag");
        System.out.println("success!");
        jsc.stop();

    }

    public static Tag mkTag(String res) throws IOException {
        int i = res.indexOf(",");
        int j = res.indexOf(",", i+1);
        String uid = res.substring(0, i);
        String date = res.substring(i+1, j);
        String content = res.substring(j+1);

        Tagger gainianTagger = Tagger.get("gainian.txt");
        Tagger hufupinTagger = Tagger.get("hufupin.txt");

        Set<String> gainianTag = gainianTagger.tag(content).getFirst();
        Set<String> hufupinTag = hufupinTagger.tag(content).getFirst();

        return new Tag(uid, date, hufupinTag, gainianTag, content);
    }

    public static void main(String[] args) throws IOException {
//        String res = "99999,20110612,我的微博地址更化妆品新啦！http://可以吃的weibo.com/uc9防晒喷雾9999，精华水常来玩符合&孕妇&使用标准哦~";
//        mkTag(res);
        AdvCli.initRunner(args, "customer insight data prepare", new PGTagging());
    }






}
