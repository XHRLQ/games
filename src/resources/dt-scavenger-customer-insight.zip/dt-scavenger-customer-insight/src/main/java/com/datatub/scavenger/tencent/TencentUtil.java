package com.datatub.scavenger.tencent;

/**
 * Created by mou on 2017/5/22.
 */
public class TencentUtil {


}
