package com.datatub.scavenger.cli;

import com.datatub.scavenger.util.SparkUtil;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import scala.Tuple2;
import scala.Tuple3;

import java.io.Serializable;

/**
 * Created by mou on 2016/10/27.
 */
public class ResultWithdrawCli implements CliRunner, Serializable {
    private static final String PARAM_IMPORT_CORE = "cores";
    private static final String PARAM_KEYWORD_LIMIT = "keylimit";
    private static final String PARAM_KOL_LIMIT = "kollimit";
    private static final String PARAM_PROJECT_NAME = "project";


    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        options.addOption(PARAM_KEYWORD_LIMIT, true, "关键词满足个数");
        options.addOption(PARAM_KOL_LIMIT, true, "KOL满足个数");
        options.addOption(PARAM_PROJECT_NAME, true, "TAG 名称");

        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE)
                && cmdLine.hasOption(PARAM_KEYWORD_LIMIT)
                && cmdLine.hasOption(PARAM_KOL_LIMIT)
                && cmdLine.hasOption(PARAM_PROJECT_NAME);
    }

    @Override
    public void start(CommandLine cmdLine) {


        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);
        final int keyLimit = Integer.parseInt(cmdLine.getOptionValue(PARAM_KEYWORD_LIMIT));
        final int kolLimit = Integer.parseInt(cmdLine.getOptionValue(PARAM_KOL_LIMIT));
        String projectName = cmdLine.getOptionValue(PARAM_PROJECT_NAME);

        String path = "/tmp/mouhao/TAGRES/" + projectName + "-TAG";

        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, projectName+"获取数据");
        JavaRDD<String> inputRDD = jsc.textFile("/tmp/mouhao/" + projectName + "-finalResult");

        System.out.println("开始取出需要的"+projectName+" TAG用户");
        System.out.println("条件：\n满足关键词个数:" + keyLimit + "\n满足KOL条件数:" + kolLimit);

        inputRDD.map(new Function<String, Tuple3<String, Integer, Integer>>() {
            @Override
            public  Tuple3<String, Integer, Integer> call(String v1) throws Exception {
                // 解析v1， id,keywordSize,kolSize
                String[] tmp = v1.split(",");
                return new Tuple3<String, Integer, Integer>(tmp[0], Integer.parseInt(tmp[1]), Integer.parseInt(tmp[2]));
            }
        }).filter(new Function<Tuple3<String, Integer, Integer>, Boolean>() {
            @Override
            public Boolean call(Tuple3<String, Integer, Integer> v1) throws Exception {
                if (v1._2() >= keyLimit && v1._2() >= kolLimit) {
                    return true;
                } else {
                    return false;
                }
            }
        }).map(new Function<Tuple3<String,Integer,Integer>, String>() {
            @Override
            public String call(Tuple3<String, Integer, Integer> v1) throws Exception {
                return v1._1();
            }
        }).saveAsTextFile(path);

        jsc.stop();
    }

    public static void main(String[] args) {
        AdvCli.initRunner(args, "customer insight data prepare", new ResultWithdrawCli());
    }
}
