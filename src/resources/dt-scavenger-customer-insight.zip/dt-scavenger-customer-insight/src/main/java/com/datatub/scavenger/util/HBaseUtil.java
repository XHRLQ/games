package com.datatub.scavenger.util;

import com.datatub.scavenger.base.BaseConsts;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.protobuf.ProtobufUtil;
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos;
import org.apache.hadoop.hbase.util.Base64;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.io.IOException;

/**
 * Created by mou on 2016/10/26.
 */
public class HBaseUtil {

    private static String convertScanToString(Scan scan) {
        ClientProtos.Scan proto = null;
        try {
            proto = ProtobufUtil.toScan(scan);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Base64.encodeBytes(proto.toByteArray());
    }

    public static String createWeiboWeiboScan(){
        Scan scan = new Scan();
        scan.setCaching(500);
        scan.setCacheBlocks(false);
        com.yeezhao.commons.hbase.HBaseUtil.addScanColumns(scan, BaseConsts.UINFO_USR_FMLYCOLS);

        scan.setFilter(new RowFilter(CompareFilter.CompareOp.EQUAL,
                new RegexStringComparator("sn\\|[0-9]+\\|wb\\|[0-9]+\\|[0-9]+")));

        return convertScanToString(scan);
    }

    public static String createWeiboUserFollowScan() {

        Scan scan = new Scan();
        scan.setCaching(500);
        scan.setCacheBlocks(false);
        scan.addFamily(BaseConsts.FMLY_FOLLOW);
        scan.addColumn(BaseConsts.FMLY_ANALYZ, BaseConsts.QUA_USERTYPE);

        scan.setFilter(new RowFilter(CompareFilter.CompareOp.EQUAL,
                new RegexStringComparator("sn\\|[0-9]+\\|$")));
        return convertScanToString(scan);
    }

    public static JavaPairRDD<ImmutableBytesWritable, Result> getHbaseRdd(
            JavaSparkContext sc,
            Configuration conf
    ) {
        return sc.newAPIHadoopRDD(conf,
                TableInputFormat.class, ImmutableBytesWritable.class, Result.class);
    }
}
