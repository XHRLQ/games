package com.datatub.scavenger.base;

import java.io.Serializable;
import java.util.Set;

/**
 * Created by mou on 2017/3/6.
 */
public class AnaTag implements Serializable {

    private String uid;
    private String date;
    private String hufutag;
    private String gainiantag;
    private String content;
    private String yearMonth;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHufutag() {
        return hufutag;
    }

    public String getYearMonth() {
        return yearMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public void setHufutag(String hufutag) {
        this.hufutag = hufutag;
    }

    public String getGainiantag() {
        return gainiantag;
    }

    public void setGainiantag(String gainiantag) {
        this.gainiantag = gainiantag;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public AnaTag(String uid, String date, String hufutag, String gainiantag, String content) {
        this.uid = uid;
        this.date = date;
        this.hufutag = hufutag;
        this.gainiantag = gainiantag;
        this.content = content;

        this.yearMonth = date.substring(0, 6);
    }
}
