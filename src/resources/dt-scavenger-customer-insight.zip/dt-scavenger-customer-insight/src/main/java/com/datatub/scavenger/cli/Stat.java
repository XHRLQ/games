package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.AnaTag;
import com.datatub.scavenger.base.Tag;
import com.datatub.scavenger.tag.Tagger;
import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by mou on 2017/3/8.
 */
public class Stat implements CliRunner, Serializable {

    private static final String PARAM_IMPORT_CORE = "cores";


    @Override
    public Options initOptions() {
        Options options = new Options();
        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {

        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "P&G tagging process");

        JavaRDD<String> data = jsc.textFile("/apps/hive/warehouse/db_datastory_algo.db/pg_trend_text/");

        data.map(new Function<String, String>() {
            @Override
            public String call(String v1) throws Exception {
                return parse(v1);
            }
        }).mapToPair(new PairFunction<String, String, Integer>() {
            @Override
            public Tuple2<String, Integer> call(String s) throws Exception {
                return new Tuple2<String, Integer>(s, 1);
            }
        }).reduceByKey(new Function2<Integer, Integer, Integer>() {
            @Override
            public Integer call(Integer v1, Integer v2) throws Exception {
                return v1 + v2;
            }
        }).map(new Function<Tuple2<String,Integer>, String>() {
            @Override
            public String call(Tuple2<String, Integer> v1) throws Exception {
                return v1._1 + "\t" + String.valueOf(v1._2);
            }
        }).saveAsTextFile("/tmp/mouhao/pg_hufu_stat");
        

        System.out.println("success!");
        jsc.stop();

    }

    /**
     * 1583207973	20160228	面霜		ahc已经升级到了第四代更加轻薄 吸收更快 渗透力更强 滋润保湿效果更明显，抗皱效果也更加突出本品不仅是眼霜 代言的明星都说当面霜用。因可以缓解法令纹和颈纹最重要的是里边富含大量的骨胶原蛋白精华,可以有效的改善眼部松弛情况。敏感型的皮肤找不到合适的面霜，可以用此款眼霜擦全脸。💴138！	201602
     * @param s
     * @return
     */
    private static String parse(String s) {
        String[] res = s.split("\t");
        String hufutag = res[2];
        String yearmonth = res[5];
        return hufutag + "#" + yearmonth;
    }


    public static void main(String[] args) throws IOException {
        AdvCli.initRunner(args, "customer insight data prepare", new Stat());
//        String raw = "1583207973\t20160228\t面霜\t\tahc已经升级到了第四代更加轻薄 吸收更快 渗透力更强 滋润保湿效果更明显，抗皱效果也更加突出本品不仅是眼霜 代言的明星都说当面霜用。因可以缓解法令纹和颈纹最重要的是里边富含大量的骨胶原蛋白精华,可以有效的改善眼部松弛情况。敏感型的皮肤找不到合适的面霜，可以用此款眼霜擦全脸。\uD83D\uDCB4138！\t201602";
//        Tuple2<String, String> a = parse(raw);
//        System.out.println(a._1);
//        System.out.println(a._2);
    }
}
