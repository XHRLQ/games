package com.datatub.scavenger.util.es;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.ActionRequest;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.Requests;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.unit.ByteSizeUnit;
import org.elasticsearch.common.unit.ByteSizeValue;
import org.elasticsearch.common.unit.TimeValue;

import java.util.concurrent.TimeUnit;


/**
 * com.datastory.banyan.es.ESBulkProcessorClient
 */
public class ESBulkProcessorClient extends SimpleEsBulkClient {
    protected static Logger LOG =Logger.getLogger(ESBulkProcessorClient.class);
    protected TimeValue flushInterval = null;

    protected BulkProcessor bulkProcessor;

    public ESBulkProcessorClient(String clusterName, String indexName, String indexType,
                                 String[] hosts, int bulkActions) {
        this(ImmutableSettings.settingsBuilder()
                        .put("cluster.name", clusterName)
                        .put("client.transport.ping_timeout", "60s")
                        .build(),
                indexName, indexType, hosts, bulkActions, null);
    }

    public ESBulkProcessorClient(String clusterName, String indexName, String indexType,
                                 String[] hosts, int bulkActions, TimeValue flushInterval) {
        this(ImmutableSettings.settingsBuilder()
                        .put("cluster.name", clusterName)
                        .put("client.transport.ping_timeout", "60s")
                        .build(),
                indexName, indexType, hosts, bulkActions, flushInterval);
    }

    protected ESBulkProcessorClient(Settings settings, String indexName, String indexType,
                                    String[] esHosts, int bulkActions, TimeValue flushInterval) {
        super(settings, indexName, indexType, esHosts, bulkActions);
        this.flushInterval = flushInterval;
        bulkProcessor = createBulkProcessor(client, indexName + "." + indexType);

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                flush();
                try {
                    close();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }));
    }

    public BulkProcessor getBulkProcessor() {
        return bulkProcessor;
    }

    public void addDocWithoutID(YZDoc doc) {
        if (doc == null) {
            return;
        }

        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType);
        indexRequest.source(doc.toJson());
        bulkProcessor.add(indexRequest);
    }

    @Override
    public void addDoc(YZDoc doc, String parent) {
        if (doc == null || doc.getId() == null)
            return;

        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType);

        String id = doc.getId();
        if (null != id) {
            indexRequest.id(id);
        }

        if (!StringUtils.isEmpty(parent)) {
            indexRequest.parent(parent);
        }

        indexRequest.source(doc.toJson());
        bulkProcessor.add(indexRequest);
    }

    @Override
    public boolean deleteDoc(String id, String parent) {
        if (StringUtils.isEmpty(id))
            return false;

        DeleteRequest deleteRequest = Requests.deleteRequest(indexName).type(indexType).id(id);

        if (!StringUtils.isEmpty(parent)) {
            deleteRequest.parent(parent);
        }

        bulkProcessor.add(deleteRequest);
        return true;
    }

    @Override
    public void addDoc(YZDoc doc, IndexRequest.OpType opType, String parent) {
        if (doc == null || doc.getId() == null)
            return;
        IndexRequest indexRequest = Requests.indexRequest(indexName).type(indexType).opType(opType);
        String id = doc.getId();
        if (null != id) {
            indexRequest.id(id);
        }

        if (!StringUtils.isEmpty(parent)) {
            indexRequest.parent(parent);
        }
        indexRequest.source(doc.toJson());
        bulkProcessor.add(indexRequest);
    }

    @Override
    public void close() throws InterruptedException {
        boolean isClosed = false;
        while (!isClosed) {
            isClosed = bulkProcessor.awaitClose(2, TimeUnit.SECONDS);
        }
        bulkProcessor.close();
        client.close();
    }

    @Override
    public void flush() {
        bulkProcessor.flush();
    }

    @Override
    public void add(ActionRequest ar) {
        getBulkProcessor().add(ar);
    }

    protected BulkProcessor createBulkProcessor(Client client, String bulkName) {
        BulkProcessor.Listener listener = new BulkProcessor.Listener() {
            @Override
            public void beforeBulk(long l, BulkRequest bulkRequest) {

            }

            @Override
            public void afterBulk(long l, BulkRequest bulkRequest, BulkResponse bulkResponse) {
            }

            @Override
            public void afterBulk(long l, BulkRequest bulkRequest, Throwable throwable) {
                LOG.error(throwable.getMessage(), throwable);
            }
        };

        if (listener == null)
            return null;

        BulkProcessor.Builder builder = BulkProcessor.builder(
                client,
                listener
        );

        if (bulkActions != 0) {
            builder.setBulkActions(bulkActions);
        }
        if (flushInterval != null) {
            builder.setFlushInterval(flushInterval);
        }
//        else
//            builder.setFlushInterval(new TimeValue(20, TimeUnit.MINUTES));

        builder.setBulkSize(new ByteSizeValue(5, ByteSizeUnit.MB));
        return builder.build();
    }
}
