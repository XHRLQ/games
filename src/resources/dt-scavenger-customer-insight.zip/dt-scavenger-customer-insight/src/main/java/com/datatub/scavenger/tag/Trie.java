package com.datatub.scavenger.tag;

import gnu.trove.map.hash.THashMap;

import java.io.Serializable;
import java.util.*;

/**
 * com.datastory.banyan.tools.Trie
 * Trie Algorithm
 * @author lhfcws
 * @since 2017/3/3
 */
public class Trie<T> implements Serializable {

    protected TrieNode<T> root = null;

    public Trie() {
        root = new TrieNode<T>();
    }

    public Trie(Map<String, T> map) {
        root = new TrieNode<T>();

        for (Map.Entry<String, T> entry : map.entrySet()) {
            insert(entry.getKey(), entry.getValue());
        }
    }

    public TrieNode<T> getRoot() {
        return root;
    }

    public void insert(String key, T value) {
        char[] chars = key.toCharArray();
        TrieNode<T> now = root;
        for (char c : chars) {
            now = now.nextNBuild(c);
        }

        now.setValue(value);
    }

    /**
     * 如果不能整个key匹配，则按照从头开始的最长匹配
     * @param key
     * @return
     */
    public T findLongestMatch(String key) {
        char[] chars = key.toCharArray();
        TrieNode<T> now = root;
        TrieNode<T> cache = null;
        for (char c : chars) {
            if (now != null) {
                if (now.getValue() != null)
                    cache = now;
                now = now.next(c);
            } else if (cache != null)
                return cache.getValue();
            else
                return null;
        }

        if (now != null && now.getValue() != null)
            return now.getValue();
        else if (cache != null)
            return cache.getValue();
        else
            return null;
    }

    /**
     * 整个key匹配
     * @param key
     * @return
     */
    public T find(String key) {
        char[] chars = key.toCharArray();
        TrieNode<T> now = root;
        for (char c : chars) {
            if (now != null) {
                now = now.next(c);
            } else
                return null;
        }

        if (now != null)
            return now.getValue();
        else
            return null;
    }

    public List<T> greedyFind(String s, int startPos) {
        return greedyFind(s.toCharArray(), startPos);
    }

    public List<T> greedyFind(char[] s, int startPos) {
        int len = s.length;
        TrieNode<T> now = root;
        List<T> ret = new LinkedList<>();

        for (int i = startPos; i < len; i++) {
            if (now != null) {
                now = now.next(s[i]);
                if (now != null && now.getValue() != null) {
                    ret.add(now.getValue());
                }
            } else {
                return ret;
            }
        }

        return ret;
    }

    /******************************************************
     * Trie node
     * @param <T>
     */
    public static class TrieNode<T> implements Serializable {
        Map<Character, TrieNode<T>> children;
        T value;

        public TrieNode() {
            this.children = new THashMap<Character, TrieNode<T>>();
            value = null;
        }

        public void appendChild(char c, TrieNode<T> trieNode) {
            this.children.put(c, trieNode);
        }

        public TrieNode<T> nextNBuild(char c) {
            if (!this.children.containsKey(c)) {
                TrieNode<T> tn = new TrieNode<T>();
                children.put(c, tn);
                return tn;
            }
            return this.children.get(c);
        }

        public TrieNode<T> next(char c) {
            return this.children.get(c);
        }

        @Override
        public String toString() {
            return "TrieNode{" +
                    "children=" + children +
                    ", value=" + value +
                    '}';
        }

        public Map<Character, TrieNode<T>> getChildren() {
            return children;
        }

        public void setChildren(Map<Character, TrieNode<T>> children) {
            this.children = children;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }
    }
}
