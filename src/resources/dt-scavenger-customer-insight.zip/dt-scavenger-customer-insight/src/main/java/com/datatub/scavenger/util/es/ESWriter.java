package com.datatub.scavenger.util.es;


import com.datatub.scavenger.base.CustomeConfiguration;
import com.yeezhao.commons.util.CollectionUtil;

import com.yeezhao.commons.util.DateUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.log4j.Logger;
import org.elasticsearch.action.ActionRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.transport.TransportClient;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * com.datastory.banyan.es.ESWriter
 *
 * @author lhfcws
 * @since 16/11/24
 */

public class ESWriter implements ESWriterAPI {
    protected static Logger LOG = Logger.getLogger(ESWriter.class);

    public static final long MAX_IDLE_TIME = 30 * 60 * 1000;    // 30 min
    public static final int DFT_MAX_BULK_NUM = 2000;

    protected ESBulkProcessorClient esBulkClient;
    protected String clusterName;
    protected String indexName;
    protected String indexType;
    protected String[] esHosts;
    protected int bulkNum = DFT_MAX_BULK_NUM;

    protected static Configuration conf = new CustomeConfiguration();
    protected volatile long lastUpdateTime = System.currentTimeMillis();
    protected final AtomicBoolean alive = new AtomicBoolean(true);
    protected boolean enableIdleClose = false;

    private static volatile ESWriter _singleton = null;

    public static ESWriter getInstance(String indexName, String indexType) {
        if (_singleton == null) {
            synchronized (ESWriter.class) {
                if (_singleton == null) {
                    _singleton = new ESWriter(indexName, indexType);
                }
            }
        }
        return _singleton;
    }

    public ESWriter(String indexName, String indexType) {
        this(indexName, indexType, DFT_MAX_BULK_NUM);
    }

    public ESWriter(String indexName, String indexType, int bulkNum) {
        this(conf.getStrings("es.hosts"), indexName, indexType, bulkNum);
    }

    public ESWriter(String esHost, String indexName, String indexType) {
        this(new String[]{esHost}, indexName, indexType, DFT_MAX_BULK_NUM);
    }

    public ESWriter(String esHost, String indexName, String indexType, int bulkNum) {
        this(new String[]{esHost}, indexName, indexType, bulkNum);
    }

    public ESWriter(String[] esHosts, String indexName, String indexType, int bulkNum) {

        System.out.println("ESWriter : " + indexName + "." + indexType + " es.hosts=" + Arrays.toString(esHosts) + " , bulk size = " + bulkNum);
        this.clusterName = conf.get("es.cluster.name");
        this.indexName = indexName;
        this.indexType = indexType;
        this.bulkNum = bulkNum;
        // 打乱esHost，因为默认esclient是递增获取node，多进程同时写，会造成单点瓶颈
        this.esHosts = CollectionUtil.shuffleArray(esHosts);

        esBulkClient = new ESBulkProcessorClient(clusterName, indexName,
                indexType, esHosts, bulkNum);
        alive.set(true);
    }

    public boolean isEnableIdleClose() {
        return enableIdleClose;
    }

    public void setEnableIdleClose(boolean enableIdleClose) {
        this.enableIdleClose = enableIdleClose;
    }

    public boolean isAlive() {
        return alive.get();
    }

    public void initBulkClient() {
        if (esBulkClient != null)
            try {
                esBulkClient.close();
                esBulkClient = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        esBulkClient = new ESBulkProcessorClient(clusterName, indexName,
                indexType, esHosts, bulkNum);

        alive.set(true);
        LOG.info(String.format("Reinitiallized EsWriter[%s] at %s", this.getClass().getSimpleName(), DateUtils.getCurrentPrettyTimeStr()));
        LOG.error(String.format("[INFO] Reinitiallized EsWriter[%s] at %s", this.getClass().getSimpleName(), DateUtils.getCurrentPrettyTimeStr()));
    }

    public ESBulkProcessorClient getEsBulkClient() {
        return esBulkClient;
    }

    public void updateLastUpdateTime() {
        lastUpdateTime = System.currentTimeMillis();
    }

    @Override
    public int getCurrentSize() {
        return -1;
    }

    public void update(Map<String, Object> doc) {
        if (doc == null || doc.isEmpty())
            return;
        if (enableIdleClose) {
            synchronized (alive) {
                updateLastUpdateTime();
            }
            if (!isAlive()) {
                synchronized (alive) {
                    if (!isAlive()) {
                        initBulkClient();
                    }
                }
            }
        }

        String parent = (String) doc.get("_parent");

        if (parent != null) {
            YZDoc yzDoc = new YZDoc(doc);
            yzDoc.remove("_parent");
            esBulkClient.updateDoc(yzDoc, parent);
        } else {
            YZDoc yzDoc = new YZDoc(doc);
            esBulkClient.updateDoc(yzDoc);
        }
    }

    public void write(Map<String, Object> doc) {
        if (doc == null || doc.isEmpty())
            return;
        if (enableIdleClose) {
            synchronized (alive) {
                updateLastUpdateTime();
            }
            if (!isAlive()) {
                synchronized (alive) {
                    if (!isAlive()) {
                        initBulkClient();
                    }
                }
            }
        }

        String parent = (String) doc.get("_parent");

        if (parent != null) {
            YZDoc yzDoc = new YZDoc(doc);
            yzDoc.remove("_parent");
            esBulkClient.addDoc(yzDoc, parent);
        } else {
            YZDoc yzDoc = new YZDoc(doc);
            if (yzDoc.getId()==null) {
                esBulkClient.addDocWithoutID(yzDoc);
            } else {
                esBulkClient.addDoc(yzDoc);
            }

        }
    }

    public void write(Map<String, Object> doc, IndexRequest.OpType opType) {
        if (doc == null || doc.isEmpty())
            return;
        if (enableIdleClose) {
            synchronized (alive) {
                updateLastUpdateTime();
            }
            if (!isAlive()) {
                synchronized (alive) {
                    if (!isAlive()) {
                        initBulkClient();
                    }
                }
            }
        }

        String parent = (String) doc.get("_parent");
        if (parent != null) {
            YZDoc yzDoc = new YZDoc(doc);
            yzDoc.remove("_parent");
            esBulkClient.addDoc(yzDoc, opType, parent);
        } else {
            YZDoc yzDoc = new YZDoc(doc);
            esBulkClient.addDoc(yzDoc, opType);
        }
    }

    public void write(BulkRequest bulkRequest) {
        if (bulkRequest == null || bulkRequest.requests().isEmpty())
            return;

        if (enableIdleClose) {
            synchronized (alive) {
                updateLastUpdateTime();
            }
            if (!isAlive()) {
                synchronized (alive) {
                    if (!isAlive()) {
                        initBulkClient();
                    }
                }
            }
        }

        if (CollectionUtils.isNotEmpty(bulkRequest.requests())) {
            for (ActionRequest ar : bulkRequest.requests()) {
                this.getEsBulkClient().add(ar);
            }
        }
    }

    public int getCurrentAvailableNodes() {
        TransportClient transportClient = esBulkClient.client;
        if (transportClient != null) {
            try {
                return transportClient.connectedNodes().size();
            } catch (NullPointerException ignore) {
                return 0;
            }
        } else
            return 0;
    }

    public void closeIfIdle() {
        if (enableIdleClose) {
            boolean needClose = false;
            if (isAlive())
                synchronized (alive) {
                    if (isAlive()) {
                        int connectedNodesNum = getCurrentAvailableNodes();
                        if (connectedNodesNum < esHosts.length / 2) {
                            LOG.error("Too many nodes failed, current nodes num : " + connectedNodesNum + ", expected total: " + esHosts.length);
                            LOG.info("Too many nodes failed, current nodes num : " + connectedNodesNum + ", expected total: " + esHosts.length);
                            needClose = true;
                        }
                    }
                }

            long now = System.currentTimeMillis();
            if (isAlive() && (needClose || now - lastUpdateTime > MAX_IDLE_TIME)) {
                try {
                    synchronized (alive) {
                        if (isAlive() && (needClose || now - lastUpdateTime > MAX_IDLE_TIME)) {
                            alive.set(false);
                            close();
                            if (needClose)
                                LOG.error(String.format("[INFO] Closed EsWriter[%s] at %s", this.getClass().getSimpleName(), DateUtils.getCurrentPrettyTimeStr()));
                            else
                                LOG.error(String.format("[INFO] Closed idle EsWriter[%s] at %s", this.getClass().getSimpleName(), DateUtils.getCurrentPrettyTimeStr()));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public String getIndexName() {
        return esBulkClient.getIndexName();
    }

    public String getIndexType() {
        return esBulkClient.getIndexType();
    }

    public void flush() {
        esBulkClient.flush();
    }

    public void close() {
        try {
            if (esBulkClient != null) {
                esBulkClient.flushNClose();
                esBulkClient = null;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
