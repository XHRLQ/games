package com.datatub.scavenger.tencent;

import com.google.gson.Gson;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.protobuf.ProtobufUtil;
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos;
import org.apache.hadoop.hbase.util.Base64;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.FlatMapFunction;
import scala.Tuple2;

import java.io.IOException;
import java.util.*;

/**
 * Created by mou on 2017/5/25.
 */
public class HBaseUtils {

    public static final byte[] RAW_FAMILY = Bytes.toBytes("raw");

    public static String createHBaseScan(String prefix){


        Scan scan = new Scan();
        scan.setCaching(500);
        scan.setCacheBlocks(false);
//        HBaseUtil.addScanColumns(scan, INFO_FMLYCOLS);
        scan.addFamily(RAW_FAMILY);

        scan.setFilter(new RowFilter(CompareFilter.CompareOp.EQUAL,
                new RegexStringComparator(prefix)));

        return convertScanToString(scan);
    }

    public static String convertScanToString(Scan scan) {
        ClientProtos.Scan proto = null;
        try {
            proto = ProtobufUtil.toScan(scan);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Base64.encodeBytes(proto.toByteArray());
    }

    public static JavaRDD<String> scanAllToJson(JavaPairRDD<ImmutableBytesWritable, Result> data) {

        return data.
                flatMap(new FlatMapFunction<Tuple2<ImmutableBytesWritable,Result>, String>() {
            @Override
            public Iterable<String> call(Tuple2<ImmutableBytesWritable, Result> immutableBytesWritableResultTuple2) throws Exception {

                List<String> res = new ArrayList<String>();

                Result row = immutableBytesWritableResultTuple2._2();

                String rowkey = Bytes.toString(row.getRow());

                Map<String, String> maps = new HashMap<>();
                maps.put("pk", rowkey);


                NavigableMap<byte[], byte[]> familyMap = row.getFamilyMap(RAW_FAMILY);


                for(byte[] qualifier : familyMap.keySet())
                {
                    String value = Bytes.toString(row.getValue(RAW_FAMILY, qualifier));
                    maps.put(Bytes.toString(qualifier), value);
                }



                res.add(new Gson().toJson(maps));
                return res;
            }
        });




    }
}
