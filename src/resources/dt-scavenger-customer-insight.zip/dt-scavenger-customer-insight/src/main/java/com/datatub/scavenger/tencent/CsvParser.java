package com.datatub.scavenger.tencent;

import com.alibaba.fastjson.JSONObject;
import com.datatub.scavenger.tag.Tagger;
import com.datatub.scavenger.util.CsvUtil;
import com.mysql.jdbc.StringUtils;
import com.yeezhao.commons.util.Pair;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

/**
 * Created by mou on 2017/5/22.
 */
public class CsvParser {


    /**
     * read from hbase, a json map
     *
     dislike_count 9957
     publish_date 46552431
     sourceCrawlerId 46693529
     other_data 393922
     content 46160292
     view_count 4409811
     city 232858
     pk 46693529
     _0 46693529
     is_main_post 46670269
     author 45776147
     category 46693529
     update_date 46693251
     review_count 6639683
     site 44337264
     guess_date 2500
     title 46648481
     keyword 46693529
     url 46693251
     item_id 46693251
     province 233892
     like_count 52158
     *
     *
     *  这份数据有个问题，爬虫爬取数据是通过相应的平台的搜索结果，不一定包括了搜索关键词
     *
     *  {
     *  "site":"天涯网论坛",
     *  "content":"　　@天天捞面123 2017-02-03 15:21:41 　　在微信叫几句老公你就逼他离了，你儿子以后怎么办？你为他想过没有？微信骚聊的其实是嫖妓行为，他不一定是出轨。身为男人我告诉你，现在十个男人九个嫖过，只是深藏不露。你应该先查清楚再离，离婚其实伤害最大的是孩子 　　----------------------------- 　　虽然很难面对这样的事实，但这位兄弟说的确实是实话，这年头只要有人际交往的正常男人，能把持住没嫖过娼的的确是凤毛麟角。但是，男人嫖娼真的没必要上纲上线，绝大多数男人都不会因为有嫖娼而丢掉家庭的，无非就是逢场作戏，酒后乱性而已。当然，我相信大多数女人都不会接受这种论调的，然而事实和真相就是那么丑陋和残酷…… 　　",
     *  "sourceCrawlerId":"150",
     *  "author":"job_com",
     *  "title":"这会在民政局门口等着离婚",
     *  "category":"百度",
     *  "publish_date":"20170204175809",
     *  "item_id":"883e09aaff487be37e8fa3edd4d1a543",
     *  "keyword":"Hao123",
     *  "update_date":"20170521035815",
     *  "is_main_post": "0",
     *  "_0":"",
     *  "url":"http://bbs.tianya.cn/post-feeling-4222192-2.shtml?st\u003d390",
     *  "pk":"2f7|tx_pinpai_20170520145457_218_62_百度_Hao123_883e09aaff487be37e8fa3edd4d1a543"
     *  }
     *
     * @param string
     * @return
     */
    public static TencentEntity zhihangNewsForumSection2(String string) {
        JSONObject map = JSONObject.parseObject(string);
        TencentEntity entity = new TencentEntity();

        entity.date = map.containsKey("publish_date") ? map.getString("publish_date").substring(0,8) : "";
//        entity.content = map.containsKey("content") ? map.getString("content") : "";
        entity.readnum = map.containsKey("view_count") ? Integer.parseInt(map.getString("view_count")) : 0;
        entity.writer = map.containsKey("author") ? map.getString("author") : "";
        entity.commentnum = map.containsKey("review_count") ? Integer.parseInt(map.getString("review_count")) : 0;
        entity.id = map.containsKey("pk") ? map.getString("pk") : "";
        entity.platform = map.containsKey("site") ? map.getString("site") : "";
        entity.setPlatformtype(PlatformTypeMapping.getMap(entity.getPlatform()));

        // content to title
        entity.content = map.containsKey("title") ? map.getString("title") : "";

        entity.url = map.containsKey("url") ? map.getString("url") : "";
        entity.ismainpost = map.containsKey("is_main_post") ? map.getString("is_main_post") : "0";

        return entity;
    }




    /**
     * 关键词	链接	标题	正文	来源	发布时间	是否主贴	作者
     * @param string
     * @return
     */
    public static TencentEntity zhihangForumParse(String string) {
        List<String> res = new ArrayList<>();

        String[] t = string.split("\\t", -1);
        for (String s : t) {
            res.add(s);
        }
        TencentEntity entity = new TencentEntity();



        entity.setUrl(res.get(1));
        entity.setPlatform(res.get(4));
//        entity.setTitle(res.get(2));
        entity.setContent(res.get(2));
        entity.setPlatformtype("论坛");

        try {
            entity.setDate(parseDate(res.get(5)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        entity.setIsmainpost(res.get(6));

        try {
            entity.setRetweetnum((int) Double.parseDouble(res.get(6)));
        } catch (Exception e) {

        }
        entity.setWriter(res.get(7));

        return entity;
    }


    /**
     * 关键词	链接	标题	来源	发布时间	是否主贴	作者
     * @param string
     * @return
     */
    public static TencentEntity zhihangnewsParse(String string) {
        List<String> res = new ArrayList<>();

        String[] t = string.split("\\t", -1);
        for (String s : t) {
            res.add(s);
        }
        TencentEntity entity = new TencentEntity();

        entity.setUrl(res.get(1));
//        entity.setTitle(res.get(2));
        entity.setContent(res.get(2));
        entity.setPlatform(res.get(3));
        entity.setPlatformtype("新闻");
        try {
            entity.setDate(parseDate(res.get(4)));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (res.get(5).equals("1")) {
            entity.setRetweetnum(0);
        } else {
            entity.setRetweetnum(1);
        }
        entity.setWriter(res.get(6));

        entity.setIsmainpost(res.get(5));

        return entity;
    }

    /**
     * "﻿""分析对象"""	关键词	过滤词	标题	主贴内容	主贴日期	URL	数据源	子域名	作者
     * @param string
     * @return
     */
    public static TencentEntity newforumsParse(String string) {
        List<String> res = new ArrayList<>();

        String[] t = string.split("\\t", -1);
        for (String s : t) {
            res.add(s);
        }
        TencentEntity entity = new TencentEntity();


//        entity.setTitle(res.get(3));
        entity.setContent(res.get(3));
        entity.setUrl(res.get(6));
        try {
            entity.setDate(parseDate(res.get(5)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        entity.setPlatform(res.get(7));
        entity.setPlatformtype(PlatformTypeMapping.getMap(entity.getPlatform()));

        entity.setWriter(res.get(9));


        return entity;
    }


    /**
     * "﻿""点赞数"""	互粉数	出生日期	省份	具体城市	城市级别	评论数	发表日期	文章类型	粉丝数级别	关注数	性别	微博唯一标识	搜索关键词	爱好	用户id	用户名	文章链接	粉丝数	转发数	微博数	发布终端	内容	认证类型
     *
     * @param string
     * @return
     */
    public static TencentEntity weiboParse(String string) {
        List<String> res = new ArrayList<>();

        String[] t = string.split("\\t", -1);
        for (String s : t) {
            res.add(s);
        }

        TencentEntity entity = new TencentEntity();

        entity.setPraisenum(Integer.parseInt(res.get(0)));
        entity.setBirthdate(res.get(2));
        entity.setProvince(res.get(3));
        entity.setCity(res.get(4));
        entity.setCitylevel(res.get(5));
        entity.setCommentnum(Integer.parseInt(res.get(6)));
        try {
            entity.setDate(parseDate(res.get(7)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        entity.setMid(res.get(12));
        entity.setFanslevel(res.get(9));
        entity.setAttentionnum(Integer.parseInt(res.get(10)));
        entity.setGender(res.get(11));
        entity.setId(res.get(12));
        entity.setFavorite(res.get(14));
        entity.setUid(res.get(15));
        entity.setName(res.get(16));
        entity.setUrl(res.get(17));
        entity.setFansnum(Integer.parseInt(res.get(18)));
        entity.setRetweetnum(Integer.parseInt(res.get(19)));
        entity.setDevice(res.get(21));
        entity.setVtype(res.get(23));
        entity.setPlatform("微博");
        entity.setPlatformtype("微博");

        entity.setContent(res.get(22));

        return entity;
    }


    /**
     * wxId	wxBiz	标题	url	发表时间	公众号作者	内容	阅读数	点赞数	是否原帖	是否广告	文章作者	情感	原文链接
     * @param string
     * @return
     */
    public static TencentEntity wechatParse(String string){
        List<String> res = new ArrayList<>();

        String[] t = string.split("\\t", -1);
        for (String s : t) {
            res.add(s);
        }

        TencentEntity entity = new TencentEntity();
        entity.setContent(res.get(2));
        entity.setUrl(res.get(3));

        try {
            entity.setDate(parseDate(res.get(4)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        entity.setWriter(res.get(5));
        entity.setName(res.get(11));
        entity.readnum = !StringUtils.isNullOrEmpty(res.get(7)) ? Integer.parseInt(res.get(7)) : 0;

        entity.setPraisenum(Integer.parseInt(res.get(8)));
        entity.setPlatform("微信");
        entity.setPlatformtype("微信");

        String i = res.get(9);
        if (i.equals("否")) {
            entity.setRetweetnum(0);
        } else {
            entity.setRetweetnum(1);
        }


        return entity;
    }

    /**
     * date
     * @return
     */
    public static String parseDate(String d) throws ParseException {
        Date date = null;
        try {
            SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            date = dt.parse(d);
        } catch (Exception e) {
            try {
                SimpleDateFormat dt = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
                date = dt.parse(d);
            } catch (Exception ex) {
                SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-ddhh:mm:ss");
                date = dt.parse(d);
            }
        }

        // *** same for the format String below
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyyMMdd");
        return dt1.format(date);
    }

    public static void main(String[] args) {
        String contenet = "wxId\twxBiz\t标题\turl\t发表时间\t公众号作者\t内容\t阅读数\t点赞数\t是否原帖\t\t文章作者\t情感\t原文链接";
        String[] a = contenet.split("\t");
        System.out.println(a);
    }
}
