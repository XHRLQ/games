package com.datatub.scavenger.cli;

import com.datatub.scavenger.base.BaseConsts;
import com.datatub.scavenger.base.CustomeConfiguration;
import com.datatub.scavenger.util.DataReader;
import com.datatub.scavenger.util.HBaseUtil;
import com.datatub.scavenger.util.SparkUtil;
import com.google.gson.Gson;
import com.yeezhao.commons.util.AdvCli;
import com.yeezhao.commons.util.CliRunner;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;

/**
 * Created by mou on 2016/10/27.
 */
public class DataPrepapreCli implements CliRunner, Serializable {


    private static final String PARAM_IMPORT_CORE = "cores";

    @Override
    public Options initOptions() {
        Options options = new Options();

        options.addOption(PARAM_IMPORT_CORE, true, "核数");
        return options;
    }

    @Override
    public boolean validateOptions(CommandLine cmdLine) {
        return cmdLine.hasOption(PARAM_IMPORT_CORE);
    }

    @Override
    public void start(CommandLine cmdLine) {
        String cores = cmdLine.getOptionValue(PARAM_IMPORT_CORE);

        // 将全部微博写入HDFS
        JavaSparkContext jsc = SparkUtil.createSparkContext(cores, "消费者洞察-数据准备");

        CustomeConfiguration conf = CustomeConfiguration.getInstance();
        String HBASE_TABLE = "yeezhao.user.info";

        // 扫微博
        conf.set(TableInputFormat.INPUT_TABLE, HBASE_TABLE);
        conf.set(TableInputFormat.SCAN, HBaseUtil.createWeiboWeiboScan());
        conf.setLong(HConstants.HBASE_CLIENT_SCANNER_TIMEOUT_PERIOD, 600000);

        System.out.println("\n扫描微博开始");
        JavaPairRDD<ImmutableBytesWritable, Result> hBaseRDD = HBaseUtil.getHbaseRdd(jsc, conf);
        DataReader.getWeiboFromHBase(hBaseRDD)
                .saveAsTextFile(BaseConsts.WEIBO_HDFS_PATH);

        System.out.println("Success!!");
        jsc.stop();
    }

    public static void main(String[] args) {
        AdvCli.initRunner(args, "customer insight data prepare", new DataPrepapreCli());
    }
}
