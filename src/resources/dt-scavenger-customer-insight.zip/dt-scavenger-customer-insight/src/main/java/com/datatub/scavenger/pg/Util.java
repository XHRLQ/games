package com.datatub.scavenger.pg;


import com.mysql.jdbc.StringUtils;
import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.ClassUtil;
import com.yeezhao.commons.util.ILineParser;


import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mou on 2017/5/4.
 */
public class Util {

    public static Map<String, String> kolUtil() throws Exception {

        InputStream in = ClassUtil.getResourceAsInputStream("pg_kol_list.txt");
        final Map<String, String> map = new HashMap<>();

        AdvFile.loadFileInLines(in, new ILineParser() {
            @Override
            public void parseLine(String s) {
                if (!StringUtils.isNullOrEmpty(s)) {
                    String[] t = s.split("##");
                    String name = t[0];
                    String uid = t[1];

                    map.put(name, uid);
                }
            }
        });

        return map;
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> map = kolUtil();
        System.out.println(map.size());
    }
}
