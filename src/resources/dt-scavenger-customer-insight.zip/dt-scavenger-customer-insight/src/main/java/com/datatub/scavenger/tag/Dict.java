package com.datatub.scavenger.tag;

import com.yeezhao.commons.util.AdvFile;
import com.yeezhao.commons.util.ClassUtil;
import com.yeezhao.commons.util.ILineParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * com.datastory.banyan.tools.Dict
 *
 * @author lhfcws
 * @since 2017/3/3
 */
public class Dict {

    public static TagModel load1(String resouceName) throws IOException{
        InputStream inputStream = ClassUtil.getResourceAsInputStream(resouceName);

        final TagModel model = new TagModel();
        AdvFile.loadFileInLines(inputStream, new ILineParser() {
            @Override
            public void parseLine(String s) {
                s = s.toLowerCase();
                String[] arr = s.split("\t");
                String tag = arr[0];
                String[] kws = arr[1].split("\\|");
                String[] filters = null;
                if (arr.length > 2) {
                    filters = arr[2].split("\\|");
                }

                for (String kw : kws) {
                    String[] ands = kw.split("&");
                    setDefault(model.getWord(), tag);
                    model.getWord().get(tag).add(
                            new HashSet<>(Arrays.asList(
                                    ands
                            ))
                    );
                }

                if (filters != null && filters.length > 0) {
                    for (String kw : filters) {
                        String[] ands = kw.split("&");
                        setDefault(model.getFilter(), tag);
                        model.getFilter().get(tag).add(
                                new HashSet<>(Arrays.asList(
                                        ands
                                ))
                        );
                    }
                }
            }
        });
        return model;
    }

    public static TagModel load(String resouceName) throws IOException {
        InputStream inputStream = ClassUtil.getResourceAsInputStream(resouceName);

        final HashMap<String, List<SingleWordTag>> singleWordMap = new HashMap<>();
        final HashMap<String, List<SingleWordTag>> singleFilterMap = new HashMap<>();

        final TagModel model = new TagModel();

        AdvFile.loadFileInLines(inputStream, new ILineParser() {
            @Override
            public void parseLine(String s) {
                s = s.toLowerCase();
                String[] arr = s.split("\t");
                String tag = arr[0];
                String[] kws = arr[1].split("\\|");
                String[] filters = null;
                if (arr.length > 2) {
                    filters = arr[2].split("\\|");
                }

                for (String kw : kws) {
                    if (!kw.contains("&")) {
                        setDefault(singleWordMap, kw);
                        singleWordMap.get(kw).add(new SingleWordTag(kw, tag));
                    } else {
                        String[] ands = kw.split("&");
                        setDefault(model.getAndWord(), tag);
                        model.getAndWord().get(tag).add(
                                new HashSet<>(Arrays.asList(
                                        ands
                                ))
                        );
                    }
                }

                if (filters != null && filters.length > 0) {
                    model.getHasFilterTags().add(tag);
                    for (String kw : filters) {
                        if (!kw.contains("&")) {
                            setDefault(singleFilterMap, kw);
                            singleFilterMap.get(kw).add(new SingleWordTag(kw, tag));
                        } else {
                            String[] ands = kw.split("&");
                            setDefault(model.getAndFilter(), tag);
                            model.getAndFilter().get(tag).add(
                                    new HashSet<>(Arrays.asList(
                                            ands
                                    ))
                            );
                        }
                    }
                }
            }
        });

        model.setSingleWord(new Trie<>(singleWordMap));
        model.setSingleFilter(new Trie<>(singleFilterMap));

        return model;
    }

    private static <T> void setDefault(Map<String, List<T>> mp, String key) {
        if (!mp.containsKey(key)) {
            mp.put(key, new ArrayList<T>());
        }
    }
}
