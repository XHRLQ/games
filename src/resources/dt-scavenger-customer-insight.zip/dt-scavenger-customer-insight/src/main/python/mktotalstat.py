# -*- coding: utf-8 -*-
# __author__ = Mou Hao



import os

files = filter(lambda x: "csvsntres" in x, os.listdir("./"))


def getData(files):
    for i in files:
        with open(i, "rb") as f:
            for line in f:
                yield line.strip()

def parse(line):
    '''
    阿里20160614,287,96
    '''
    t = line.split(",")
    company = t[0][:-8]
    date = t[0][-8:]
    pos = t[1]
    neg = t[2]
    return (date, company), pos, neg

poskeys = {}
negkeys = {}

for i in getData(files):
    key, pos, neg = parse(i)
    if key not in poskeys:
        poskeys[key] = 0
    if key not in negkeys:
        negkeys[key] = 0
        
    poskeys[key] += int(pos)
    negkeys[key] += int(neg)

with open("res.txt", "wb") as f:
    
    for i in poskeys:
        t = ",".join([ i[0], i[1] , str(poskeys[i]), str(negkeys[i]) ]) + "\n"
        f.write(t)