# -*- coding: utf-8 -*-
# __author__ = Mou Hao


import json
import re


def read():
	with open("./offline-res", "rb") as f:
		for line in f:
			line = line.strip()
			data = json.loads(line)
			try:
				yield parse(data)
			except:
				continue

def parse(data):
	a = [data[u"company"],
	data[u"dimension1"],
	data[u"dimension2"],
	data[u"keywords"],
	data[u"date"],
	data[u"platform"],
	data[u"platformType"],
	data[u"snt"],
	data[u"writer"],
	data[u"readNum"],
	data[u"praiseNum"],
	data[u"retweetNum"],
	data[u"commentNum"],
	data[u"birthdate"],
	data[u"province"],
	data[u"city"],
	data[u"cityLevel"],
	data[u"fansLevel"],
	data[u"attentionNum"],
	data[u"gender"],
	data[u"id"],
	data[u"favorite"],
	data[u"uid"],
	data[u"name"],
	data[u"fansNum"],
	data[u"device"],
	data[u"vtype"],
	data[u"content"]]
	b = []
	for i in a:
		try:
			res = re.sub(r"\t|\n|,|\"", "", i)
			b.append(res)
		except:
			b.append(str(i))
	
	return ",".join(b)

count = 0
with open("./result.csv", "wb") as f:
	title = u"company,dimension1,dimension2,keywords,date,platform,platformType,snt,writer,readNum,praiseNum,retweetNum,commentNum,birthdate,province,city,cityLevel,fansLevel,attentionNum,gender,id,favorite,uid,name,fansNum,device,vtype,content\n" 
	f.write(title.encode("gb18030"))
	for i in read():
		count += 1
		if count % 100000 == 0:
			print count
		line = i + "\n"
		f.write(line.encode("gb18030"))