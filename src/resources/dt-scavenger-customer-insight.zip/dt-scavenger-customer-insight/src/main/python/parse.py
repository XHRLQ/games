# coding: utf-8

import pandas as pd
import json

save_size = 1000000

def get_df_from_json(d):
    res = {}

    for i in d:
        for key in i:
            res.setdefault(key, []).append(i[key])
    return pd.DataFrame(res)

cache = []
with open(u"./tencnt_out_0605/tencent_out_0605.json", "rb") as f:

    count = 0
    for line in f:

        if len(cache) == save_size:
            df = get_df_from_json(cache)
            df.to_csv("./0605/tencent_out_0605"+str(count)+".csv", encoding="gb18030", index=False)
            count += 1
            print count
            cache = []

        cache.append(json.loads(line.strip()))

if len(cache) > 0:
    df = get_df_from_json(cache)
    df.to_csv("./0605/tencent_out_0605"+str(count)+".csv", encoding="gb18030", index=False)